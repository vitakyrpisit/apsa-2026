# APSA-2026 Post-Deploy Security Audit Required

This archive has been patched so paid generic x402 routes do not release a result
from payer balance or a claimed header alone. They require facilitator verify,
facilitator settle, a returned transaction hash, and independent Base receipt
verification of payer -> operator for the required USDC amount.

SentinelShield now points at the external facilitator URL rather than a local
relayer endpoint. The facilitator default is PayAI.

The repository still cannot prove production deployment. Before calling the
system operational, verify the deployed URL externally and perform a real
third-party x402 call. Do not use operator funds for testing.

The on-chain watcher is fail-closed: RPC errors are UNKNOWN, not zero. A wallet
balance is not counted as revenue without transaction-level evidence.
