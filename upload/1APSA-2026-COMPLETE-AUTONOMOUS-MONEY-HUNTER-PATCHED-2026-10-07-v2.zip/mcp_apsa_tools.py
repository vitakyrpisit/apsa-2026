#!/usr/bin/env python3
"""
APSA-2026 Model Context Protocol (MCP) Server
Allows external AI Agents (Claude Desktop, Cursor, ElizaOS, LangChain)
to discover and invoke APSA x402 tools with on-chain Base USDC settlement.
Target Operator Wallet: 0x829f877daAb94D766BB2b8511ad486C40f2C2BDA
"""

import json
import sys
import urllib.request
import urllib.error

BASE_URL = "https://apsa-2026.vercel.app"
OPERATOR_WALLET = "0x829f877daAb94D766BB2b8511ad486C40f2C2BDA"

TOOLS_MANIFEST = [
    {
        "name": "get_crypto_price_free",
        "description": "Free cryptocurrency price snapshot (Loss Leader). Returns spot price and 24h change.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "symbol": {"type": "string", "description": "Ticker symbol (BTC, ETH, SOL)", "default": "BTC"}
            }
        }
    },
    {
        "name": "get_market_signal",
        "description": "Quantitative market signal snapshot ($0.001 USDC on Base). Returns confidence score, RSI, MACD, and key levels.",
        "priceUSD": 0.001,
        "inputSchema": {
            "type": "object",
            "properties": {
                "symbol": {"type": "string", "default": "BTC"},
                "timeframe": {"type": "string", "default": "1h"}
            }
        }
    },
    {
        "name": "get_market_analysis",
        "description": "In-depth macro and on-chain intelligence analysis ($0.05 USDC on Base).",
        "priceUSD": 0.05,
        "inputSchema": {
            "type": "object",
            "properties": {
                "symbol": {"type": "string", "default": "BTC"}
            }
        }
    },
    {
        "name": "audit_website",
        "description": "Deterministic site security headers and health audit ($0.25 USDC on Base).",
        "priceUSD": 0.25,
        "inputSchema": {
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "Target website URL"}
            },
            "required": ["url"]
        }
    },
    {
        "name": "get_company_intel",
        "description": "B2B company intelligence and risk scoring ($0.50 USDC on Base).",
        "priceUSD": 0.50,
        "inputSchema": {
            "type": "object",
            "properties": {
                "domain": {"type": "string", "description": "Company domain (e.g. stripe.com)"}
            },
            "required": ["domain"]
        }
    },
    {
        "name": "audit_smart_contract",
        "description": "SentinelShield AST smart contract vulnerability assessment ($9.50 USDC on Base).",
        "priceUSD": 9.50,
        "inputSchema": {
            "type": "object",
            "properties": {
                "sourceCode": {"type": "string", "description": "Solidity source code"}
            },
            "required": ["sourceCode"]
        }
    }
]

def handle_call_tool(tool_name: str, arguments: dict):
    if tool_name == "get_crypto_price_free":
        sym = arguments.get("symbol", "BTC")
        req = urllib.request.Request(f"{BASE_URL}/api/price?symbol={sym}")
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read().decode())
    
    endpoint_map = {
        "get_market_signal": "/api/market-signal",
        "get_market_analysis": "/api/market-analysis",
        "audit_website": "/api/site-audit",
        "get_company_intel": "/api/company-intel",
        "audit_smart_contract": "/sentinelshield"
    }
    
    endpoint = endpoint_map.get(tool_name)
    if not endpoint:
        return {"error": f"Unknown tool {tool_name}"}
    
    # Request without payment header returns x402 specifications
    req = urllib.request.Request(
        f"{BASE_URL}{endpoint}",
        data=json.dumps(arguments).encode(),
        headers={"Content-Type": "application/json"}
    )
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        if e.code == 402:
            return {
                "status": "HTTP_402_PAYMENT_REQUIRED",
                "paymentRequirements": json.loads(e.read().decode()),
                "payTo": OPERATOR_WALLET,
                "instructions": f"Agent must settle required USDC on Base Mainnet to {OPERATOR_WALLET} to retrieve output."
            }
        return {"error": str(e)}

if __name__ == "__main__":
    print(json.dumps({"tools": TOOLS_MANIFEST}, indent=2))
