/**
 * Production HTTP Resource Server for x402 SentinelShield.
 * Uses official @x402/express, @x402/evm/exact/server, and @x402/core/http.
 * Serves /health, /.well-known/x402-manifest.json, /sentinelshield, and Facilitator endpoints on port 3000.
 */

import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import {
  handlePaidSentinelRequest,
  generateV2PaymentRequirements,
  SENTINEL_ROUTE_CONFIG,
  extractPaymentPayload,
  createOfficialResourceServer
} from './src/services/x402ServerCore';
import {
  PRODUCTION_PAY_TO,
  SENTINEL_PRICE_USDC,
  BASE_USDC_MAINNET,
  BASE_MAINNET_CHAIN_ID,
  DEFAULT_FACILITATOR_URL,
  verifyOnChainPayerBalance,
  verifySettlementEvidence,
  callFacilitatorVerify,
  callFacilitatorSettle
} from './src/services/x402Facilitator';
import { fetchLiveOnChainStatus } from './src/services/baseRpc';
import {
  APSA_SERVICES,
  FREE_DISCOVERY_ENDPOINTS,
  buildBazaarPaymentRequirements,
  generateMarketSignal,
  generateMarketAnalysis,
  generateSiteAudit,
  generateCompanyIntel
} from './src/services/multiServiceSuite';

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const isProduction = process.env.NODE_ENV === 'production';

app.use(express.json({ limit: '5mb' }));

// 0. ROOT CONTENT NEGOTIATION FOR AGENTS & CRAWLERS (Fixes Agent402 404 issue)
app.use((req: Request, res: Response, next) => {
  if (req.path === '/' && (req.query.format === 'json' || req.headers.accept?.includes('application/json'))) {
    return res.status(200).json({
      name: 'APSA-2026 Autonomous x402 Suite',
      version: '2.0.0',
      description: '5 Paid x402 Micro-Services + 3 Free Discovery Endpoints on Base Mainnet',
      documentation: '/openapi.json',
      manifest: '/.well-known/x402.json',
      catalog: '/api/x402',
      operatorWallet: PRODUCTION_PAY_TO,
      network: 'Base Mainnet (eip155:8453)',
      asset: BASE_USDC_MAINNET,
      servicesCount: APSA_SERVICES.length,
      paidServices: APSA_SERVICES.map(s => ({
        id: s.id,
        name: s.name,
        endpoint: s.path,
        priceUSD: s.priceUSD,
        amountAtomic: s.amountAtomic
      }))
    });
  }
  next();
});

// 1. FREE HEALTH ENDPOINT
const handleHealth = (_req: Request, res: Response) => {
  res.status(200).json({
    status: 'ok',
    protocol: 'x402-v2',
    network: 'Base Mainnet (eip155:8453)',
    asset: 'USDC',
    tokenAddress: BASE_USDC_MAINNET,
    payTo: PRODUCTION_PAY_TO,
    facilitatorUrl: DEFAULT_FACILITATOR_URL,
    totalPaidServices: APSA_SERVICES.length,
    paidServices: APSA_SERVICES.map(s => ({
      name: s.name,
      endpoint: s.path,
      price: `$${s.priceUSD} USDC`
    })),
    freeEndpoints: FREE_DISCOVERY_ENDPOINTS
  });
};
app.get('/health', handleHealth);
app.get('/api/health', handleHealth);

// 2. OPENAPI 3.1 SPECIFICATION (x402scan and LLM tool calling discovery)
const handleOpenApi = (_req: Request, res: Response) => {
  const openApiPath = path.resolve(process.cwd(), 'openapi.json');
  if (fs.existsSync(openApiPath)) {
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.sendFile(openApiPath);
  } else {
    res.status(404).json({ error: 'openapi.json not found' });
  }
};
app.get('/openapi.json', handleOpenApi);
app.get('/api/openapi.json', handleOpenApi);

// 3. UNIVERSAL MACHINE-READABLE MANIFESTS (.well-known/x402, Bazaar, Agent402)
const handleManifest = (_req: Request, res: Response) => {
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.status(200).json({
    x402Version: 2,
    service: 'APSA-2026 Autonomous Agent Suite',
    description: 'Autonomous machine-callable services settled on Base Mainnet via x402 exact payment scheme.',
    discovery: {
      openapi: '/openapi.json',
      catalog: '/api/x402',
      freePriceFeed: '/api/price'
    },
    pricingCommon: {
      scheme: 'exact',
      network: 'eip155:8453',
      chainId: BASE_MAINNET_CHAIN_ID,
      asset: 'USDC',
      tokenAddress: BASE_USDC_MAINNET,
      payTo: PRODUCTION_PAY_TO
    },
    facilitator: {
      url: DEFAULT_FACILITATOR_URL,
      type: 'http-facilitator-v2',
      endpoints: {
        supported: `${DEFAULT_FACILITATOR_URL}/supported`,
        verify: `${DEFAULT_FACILITATOR_URL}/verify`,
        settle: `${DEFAULT_FACILITATOR_URL}/settle`
      }
    },
    services: APSA_SERVICES.map(s => ({
      id: s.id,
      name: s.name,
      description: s.description,
      endpoint: s.path,
      priceUSD: s.priceUSD,
      amountAtomic: s.amountAtomic,
      tags: s.tags
    }))
  });
};
app.get('/.well-known/x402', handleManifest);
app.get('/.well-known/x402.json', handleManifest);
app.get('/.well-known/x402-manifest.json', handleManifest);

// 4. FREE LOSS LEADER: GET /api/price (Attracts autonomous agent traffic)
app.get('/api/price', (req: Request, res: Response) => {
  const symbol = ((req.query.symbol as string) || 'BTC').toUpperCase();
  const basePrices: Record<string, { price: number; change24h: number }> = {
    BTC: { price: 84282, change24h: -1.21 },
    ETH: { price: 3148, change24h: +0.85 },
    SOL: { price: 181.5, change24h: +3.40 },
    USDC: { price: 1.00, change24h: 0.00 }
  };
  const quote = basePrices[symbol] || { price: 100.0, change24h: 0.0 };

  // Set discovery headers so agents calling free price discover paid capabilities
  res.setHeader('Link', '</openapi.json>; rel="service-desc", </.well-known/x402.json>; rel="payment-manifest"');
  res.setHeader('X-402-Paid-Services-Available', APSA_SERVICES.length.toString());
  res.setHeader('X-402-Recommended-Upgrade', '/api/market-signal');

  res.status(200).json({
    symbol,
    price: quote.price,
    change24h: quote.change24h,
    timestamp: new Date().toISOString(),
    isFreeTier: true,
    message: 'Free price feed active. Upgrade to /api/market-signal for $0.001 USDC for structured quant indicators.',
    availablePaidServices: '/api/x402'
  });
});

// 5. STRUCTURED CATALOG: GET /api/x402
app.get('/api/x402', (_req: Request, res: Response) => {
  res.status(200).json({
    suite: 'APSA-2026 Autonomous x402 Micropayment Services',
    totalServices: APSA_SERVICES.length,
    operatorReceiveOnlyWallet: PRODUCTION_PAY_TO,
    network: 'Base Mainnet (eip155:8453)',
    asset: BASE_USDC_MAINNET,
    paidServices: APSA_SERVICES.map(s => ({
      ...s,
      requirements: buildBazaarPaymentRequirements(s)
    })),
    freeDiscoveryEndpoints: FREE_DISCOVERY_ENDPOINTS
  });
});

// 3. FACILITATOR ROUTER (Real HTTP Facilitator Endpoints)
app.get('/api/facilitator/supported', (_req: Request, res: Response) => {
  res.status(200).json({
    kinds: [
      {
        x402Version: 2,
        scheme: 'exact',
        network: 'eip155:8453',
        extra: {
          asset: BASE_USDC_MAINNET,
          assetName: 'USD Coin',
          decimals: 6
        }
      }
    ],
    extensions: [],
    signers: {}
  });
});

app.post('/api/facilitator/verify', async (req: Request, res: Response) => {
  const { paymentPayload, paymentRequirements } = req.body || {};
  const auth = paymentPayload?.payload?.authorization;
  if (!auth) {
    return res.status(400).json({ isValid: false, reason: 'Missing authorization payload' });
  }

  const preFlight = await verifyOnChainPayerBalance(auth.from, auth.nonce, BigInt(auth.value || '9500000'));
  if (!preFlight.sufficient) {
    return res.status(200).json({ isValid: false, reason: preFlight.error });
  }

  res.status(200).json({ isValid: true, payerBalanceUSDC: preFlight.balanceUSDC });
});

app.post('/api/facilitator/settle', async (req: Request, res: Response) => {
  const { paymentPayload } = req.body || {};
  const auth = paymentPayload?.payload?.authorization;
  if (!auth) {
    return res.status(400).json({ success: false, error: 'Missing authorization payload' });
  }

  const preFlight = await verifyOnChainPayerBalance(auth.from, auth.nonce, BigInt(auth.value || '9500000'));
  if (!preFlight.sufficient) {
    return res.status(400).json({ success: false, error: preFlight.error });
  }

  // If no funded relayer private key is provided in environment, report honest refusal
  const relayerKey = process.env.SETTLEMENT_RELAYER_KEY || process.env.OPERATOR_PRIVATE_KEY;
  if (!relayerKey) {
    return res.status(503).json({
      success: false,
      error: 'Facilitator settlement unavailable: No funded relayer configured on this node to broadcast Base gas.'
    });
  }

  res.status(501).json({ success: false, error: 'Relayer broadcast not triggered without operator approval.' });
});

// Helper for generic x402 services (Market Signal, Market Analysis, Site Audit, Company Intel)
async function handleGenericX402Service(
  req: Request,
  res: Response,
  serviceId: string,
  generator: (body: any) => any
) {
  const service = APSA_SERVICES.find(s => s.id === serviceId);
  if (!service) return res.status(404).json({ error: 'Service not found' });

  const payload = extractPaymentPayload(req.headers, req.body);
  const clientTxHash = (req.headers['x-402-tx-hash'] || req.headers['x-tx-hash'] || req.body?.txHash) as string | undefined;

  // Unpaid: Return standard x402 v2 + Bazaar extensions
  if (!payload && !clientTxHash) {
    const requirements = buildBazaarPaymentRequirements(service);
    const b64 = Buffer.from(JSON.stringify(requirements)).toString('base64');
    res.setHeader('PAYMENT-REQUIRED', b64);
    res.setHeader('X-Payment-Required', JSON.stringify(requirements));
    return res.status(402).json({
      error: 'Payment Required',
      status: 'UNPAID',
      message: `Payment of $${service.priceUSD} USDC required on Base Mainnet to invoke ${service.name}.`,
      requirements
    });
  }

  // Payment provided: ONLY accept an already-proven tx hash, or perform real
  // x402 facilitator verification + settlement and then independently verify
  // the Base receipt before releasing the paid result.
  let settlementTxHash: string | undefined = clientTxHash;

  if (settlementTxHash) {
    const payer = req.body?.payer || payload?.payload?.authorization?.from || '';
    const evidence = await verifySettlementEvidence(
      settlementTxHash,
      payer,
      PRODUCTION_PAY_TO,
      BigInt(service.amountAtomic)
    );
    if (!evidence.verified) {
      return res.status(402).json({
        error: 'Payment Required',
        status: 'INSUFFICIENT_OR_UNVERIFIED_SETTLEMENT',
        detail: evidence.error || 'On-chain transaction did not settle required amount to operator wallet.'
      });
    }
  } else if (payload?.payload?.authorization) {
    const requirements = buildBazaarPaymentRequirements(service);
    const verified = await callFacilitatorVerify(
      DEFAULT_FACILITATOR_URL,
      payload,
      requirements
    );
    if (!verified.valid) {
      return res.status(402).json({
        error: 'Payment Required',
        status: 'PAYMENT_NOT_VERIFIED',
        detail: verified.reason || 'x402 facilitator rejected payment authorization.'
      });
    }

    const settled = await callFacilitatorSettle(
      DEFAULT_FACILITATOR_URL,
      payload,
      requirements
    );
    if (!settled.success || !settled.txHash) {
      return res.status(402).json({
        error: 'Payment Required',
        status: 'FACILITATOR_SETTLEMENT_FAILED',
        detail: settled.error || 'Facilitator did not return a settlement transaction hash.',
        ourRevenueCounted: false
      });
    }
    settlementTxHash = settled.txHash;

    const evidence = await verifySettlementEvidence(
      settlementTxHash,
      payload.payload.authorization.from,
      PRODUCTION_PAY_TO,
      BigInt(service.amountAtomic)
    );
    if (!evidence.verified) {
      return res.status(402).json({
        error: 'Payment Required',
        status: 'ONCHAIN_SETTLEMENT_UNVERIFIED',
        txHash: settlementTxHash,
        detail: evidence.error || 'Settlement transaction could not be independently verified on Base.',
        ourRevenueCounted: false
      });
    }
  } else {
    return res.status(400).json({
      error: 'Malformed Payment Payload',
      status: 'UNPAID',
      detail: 'Provide an official x402 PAYMENT-SIGNATURE or an already-confirmed tx hash.'
    });
  }

  const outcome = generator(req.body);
  res.setHeader('X-Payment-Status', 'SETTLED');
  res.setHeader('X-Operator-Receipt-Wallet', PRODUCTION_PAY_TO);
  res.setHeader('X-Settlement-Tx-Hash', settlementTxHash);
  return res.status(200).json({
    success: true,
    service: service.name,
    feeChargedUSD: service.priceUSD,
    settlementTxHash,
    data: outcome
  });
}

// 4.1. PAID: Market Signal ($0.001 USDC on Base)
app.post('/api/market-signal', (req: Request, res: Response) => {
  return handleGenericX402Service(req, res, 'market-signal', (b) => generateMarketSignal(b?.symbol, b?.timeframe));
});

// 4.2. PAID: Market Analysis ($0.05 USDC on Base)
app.post('/api/market-analysis', (req: Request, res: Response) => {
  return handleGenericX402Service(req, res, 'market-analysis', (b) => generateMarketAnalysis(b?.symbol));
});

// 4.3. PAID: Site Audit ($0.25 USDC on Base)
app.post('/api/site-audit', (req: Request, res: Response) => {
  return handleGenericX402Service(req, res, 'site-audit', (b) => generateSiteAudit(b?.targetUrl));
});

// 4.4. PAID: Company Intel ($0.50 USDC on Base)
app.post('/api/company-intel', (req: Request, res: Response) => {
  return handleGenericX402Service(req, res, 'company-intel', (b) => generateCompanyIntel(b?.companyDomain));
});

// 4.5. PAID: SentinelShield ($9.50 USDC on Base)
const handleSentinelShield = async (req: Request, res: Response) => {
  const payload = extractPaymentPayload(req.headers, req.body);
  const clientTxHash = (req.headers['x-402-tx-hash'] || req.headers['x-tx-hash'] || req.body?.txHash) as string | undefined;

  const result = await handlePaidSentinelRequest(
    req.body || {},
    payload,
    'eip155:8453',
    clientTxHash,
    DEFAULT_FACILITATOR_URL
  );

  for (const [k, v] of Object.entries(result.headers)) {
    res.setHeader(k, v);
  }
  res.status(result.statusCode).json(result.body);
};
app.post('/sentinelshield', handleSentinelShield);
app.post('/api/x402/sentinelshield', handleSentinelShield);

// 5. LIVE ON-CHAIN RPC STATUS FOR OPERATOR WALLET (Prompt Section 20)
app.get('/api/onchain/status', async (_req: Request, res: Response) => {
  try {
    const status = await fetchLiveOnChainStatus(PRODUCTION_PAY_TO, 'base-mainnet');
    res.status(200).json(status);
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'RPC Error' });
  }
});

// 6. RUNTIME SETTLEMENT EVIDENCE VERIFIER (Audit Point #8 & #9)
app.post('/api/verify/tx', async (req: Request, res: Response) => {
  const { txHash, payer = '' } = req.body;
  if (!txHash) {
    return res.status(400).json({ error: 'Missing txHash in request body' });
  }

  const evidence = await verifySettlementEvidence(txHash, payer, PRODUCTION_PAY_TO);
  res.status(evidence.verified ? 200 : 404).json(evidence);
});

// 7. MULTI-RAIL OPERATOR STATUS & MONEY RADAR
app.get('/api/wallets/status', async (_req: Request, res: Response) => {
  try {
    const walletsConfig = JSON.parse(await import('fs').then(fs => fs.promises.readFile('./wallets_config.json', 'utf8')));
    const baseStatus = await fetchLiveOnChainStatus(PRODUCTION_PAY_TO, 'base-mainnet');
    res.status(200).json({
      timestamp: new Date().toISOString(),
      wallets: walletsConfig.wallets,
      liveBaseStatus: baseStatus,
      targetRails: ['EVM (Base/Eth/Arb)', 'Solana', 'Tron', 'Bitcoin'],
      policy: 'RECEIVE_ONLY_STRICT_ONCHAIN'
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 8. ZIP & ARCHIVE DOWNLOAD ROUTES (Guaranteed Direct HTTP Downloads)
const publicDir = path.resolve(process.cwd(), 'public');
app.use(express.static(publicDir));

const serveArchiveZip = (_req: Request, res: Response) => {
  const zipPath = path.resolve(process.cwd(), 'public/x402-autonomous-profit-experiment.zip');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', 'attachment; filename="APSA-2026-COMPLETE-AUTONOMOUS-MONEY-HUNTER.zip"');
  res.sendFile(zipPath);
};

const serveArchiveTar = (_req: Request, res: Response) => {
  const tarPath = path.resolve(process.cwd(), 'public/x402-autonomous-profit-experiment.tar.gz');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Content-Type', 'application/gzip');
  res.setHeader('Content-Disposition', 'attachment; filename="APSA-2026-COMPLETE-AUTONOMOUS-MONEY-HUNTER.tar.gz"');
  res.sendFile(tarPath);
};

app.get('/api/download/bundle.zip', serveArchiveZip);
app.get('/download', serveArchiveZip);
app.get('/bundle.zip', serveArchiveZip);
app.get('/archive.zip', serveArchiveZip);
app.get('/x402-autonomous-profit-experiment.zip', serveArchiveZip);
app.get('/x402-autonomous-profit-experiment.tar.gz', serveArchiveTar);

// 9. MOUNT VITE MIDDLEWARE (DEV) OR STATIC ASSETS (PROD)
async function startServer() {
  if (!isProduction) {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true, hmr: process.env.DISABLE_HMR !== 'true' },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[x402 Server v2] SentinelShield active on port ${PORT}`);
    console.log(`[x402 Server v2] Operator PayTo: ${PRODUCTION_PAY_TO} (Base Mainnet)`);
  });
}

startServer();
