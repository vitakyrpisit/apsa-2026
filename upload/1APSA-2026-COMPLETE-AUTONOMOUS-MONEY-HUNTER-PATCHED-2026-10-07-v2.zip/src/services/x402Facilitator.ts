/**
 * Production x402 v2 Facilitator & EVM On-Chain Settlement Engine.
 * Strictly adheres to x402 v2 specification (PaymentPayload, /verify, /settle),
 * unified post-settlement receipt verifier (Transfer.from == payer, Transfer.to == payTo, amount >= 9500000),
 * and live Base Mainnet RPC integration.
 */

import {
  createPublicClient,
  createWalletClient,
  http,
  isAddressEqual,
  decodeEventLog,
  verifyTypedData
} from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import { base } from 'viem/chains';

export const BASE_MAINNET_RPC = 'https://mainnet.base.org';
export const BASE_MAINNET_CHAIN_ID = 8453;
export const BASE_USDC_MAINNET = '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913';
export const PRODUCTION_PAY_TO = '0x829f877daAb94D766BB2b8511ad486C40f2C2BDA';
export const SENTINEL_PRICE_USDC = 9.50;
export const SENTINEL_PRICE_ATOMIC = '9500000'; // 6 decimals ($9.50)

// Official Facilitator URL (configurable via env)
export const DEFAULT_FACILITATOR_URL =
  process.env.FACILITATOR_URL ||
  process.env.VITE_FACILITATOR_URL ||
  'https://facilitator.payai.network';

// USDC EIP-3009 ABI
export const USDC_EIP3009_ABI = [
  {
    name: 'balanceOf',
    type: 'function',
    stateMutability: 'view',
    inputs: [{ name: 'account', type: 'address' }],
    outputs: [{ name: '', type: 'uint256' }]
  },
  {
    name: 'authorizationState',
    type: 'function',
    stateMutability: 'view',
    inputs: [
      { name: 'authorizer', type: 'address' },
      { name: 'nonce', type: 'bytes32' }
    ],
    outputs: [{ name: '', type: 'bool' }]
  },
  {
    name: 'transferWithAuthorization',
    type: 'function',
    stateMutability: 'nonpayable',
    inputs: [
      { name: 'from', type: 'address' },
      { name: 'to', type: 'address' },
      { name: 'value', type: 'uint256' },
      { name: 'validAfter', type: 'uint256' },
      { name: 'validBefore', type: 'uint256' },
      { name: 'nonce', type: 'bytes32' },
      { name: 'v', type: 'uint8' },
      { name: 'r', type: 'bytes32' },
      { name: 's', type: 'bytes32' }
    ],
    outputs: []
  },
  {
    name: 'Transfer',
    type: 'event',
    inputs: [
      { indexed: true, name: 'from', type: 'address' },
      { indexed: true, name: 'to', type: 'address' },
      { indexed: false, name: 'value', type: 'uint256' }
    ]
  }
] as const;

export interface V2PaymentPayload {
  x402Version: number;
  resource?: {
    url?: string;
    description?: string;
    mimeType?: string;
  };
  accepted?: {
    scheme: string;
    network: string;
    amount: string;
    payTo: string;
  };
  payload: {
    authorization: {
      from: string;
      to: string;
      value: string;
      validAfter: number;
      validBefore: number;
      nonce: string;
    };
    signature: string;
  };
  extensions?: Record<string, unknown>;
}

export interface V2PaymentRequirements {
  x402Version: number;
  scheme: 'exact';
  network: 'eip155:8453';
  amount: string; // '9500000'
  payTo: string;  // PRODUCTION_PAY_TO
  asset: string;  // BASE_USDC_MAINNET
  maxTimeoutSeconds?: number;
  extra?: Record<string, unknown>;
}

export interface SettlementEvidence {
  verified: boolean;
  chain: 'Base Mainnet (8453)';
  receiptStatus: 'success' | 'failed' | 'not_found';
  txHash: string;
  blockNumber?: number;
  gasUsed?: string;
  fromVerified: boolean;
  toVerified: boolean;
  amountVerified: boolean;
  payer: string;
  payTo: string;
  amountUSDC: string;
  tokenContract: string;
  error?: string;
}

export function getBasePublicClient() {
  return createPublicClient({
    chain: base,
    transport: http(BASE_MAINNET_RPC)
  });
}

/**
 * 1. UNIFIED POST-SETTLEMENT EVIDENCE VERIFIER (Audit Point #8 & #9)
 * Strictly verifies on Base Mainnet RPC:
 * - receipt.status == 'success'
 * - token contract == Base USDC (0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913)
 * - Transfer.from == payer (Prevents accepting unlinked/third-party transfers!)
 * - Transfer.to == operator PAY_TO
 * - Transfer.value >= 9500000 ($9.50 USDC)
 */
export async function verifySettlementEvidence(
  txHash: string,
  expectedPayer: string,
  expectedPayTo: string = PRODUCTION_PAY_TO,
  minimumAtomicValue: bigint = BigInt(SENTINEL_PRICE_ATOMIC)
): Promise<SettlementEvidence> {
  const defaultEvidence: SettlementEvidence = {
    verified: false,
    chain: 'Base Mainnet (8453)',
    receiptStatus: 'not_found',
    txHash,
    fromVerified: false,
    toVerified: false,
    amountVerified: false,
    payer: expectedPayer,
    payTo: expectedPayTo,
    amountUSDC: '0.00',
    tokenContract: BASE_USDC_MAINNET
  };

  if (!txHash || !txHash.startsWith('0x') || txHash.length !== 66) {
    return { ...defaultEvidence, error: 'Invalid transaction hash format' };
  }

  const client = getBasePublicClient();

  try {
    const receipt = await client.getTransactionReceipt({ hash: txHash as `0x${string}` });

    if (receipt.status !== 'success') {
      return {
        ...defaultEvidence,
        receiptStatus: 'failed',
        blockNumber: Number(receipt.blockNumber),
        error: `Transaction reverted on-chain in block #${receipt.blockNumber}`
      };
    }

    let transferFound = false;
    let actualFromVerified = false;
    let actualToVerified = false;
    let actualAmountVerified = false;
    let actualAmount = BigInt(0);

    for (const log of receipt.logs) {
      if (isAddressEqual(log.address, BASE_USDC_MAINNET as `0x${string}`)) {
        try {
          const decoded = decodeEventLog({
            abi: USDC_EIP3009_ABI,
            eventName: 'Transfer',
            data: log.data,
            topics: log.topics
          });

          // Check Transfer.to == expectedPayTo
          if (isAddressEqual(decoded.args.to, expectedPayTo as `0x${string}`)) {
            actualToVerified = true;

            // Check Transfer.from == expectedPayer
            if (isAddressEqual(decoded.args.from, expectedPayer as `0x${string}`)) {
              actualFromVerified = true;
            }

            // Check amount >= minimumAtomicValue
            if (decoded.args.value >= minimumAtomicValue) {
              actualAmountVerified = true;
            }

            actualAmount = decoded.args.value;

            if (actualFromVerified && actualToVerified && actualAmountVerified) {
              transferFound = true;
              break;
            }
          }
        } catch {
          // Continue scanning logs
        }
      }
    }

    if (!transferFound) {
      let failureReason = 'No matching USDC Transfer event found.';
      if (actualToVerified && !actualFromVerified) {
        failureReason = `USDC transfer detected to payTo, but Transfer.from does NOT match payer ${expectedPayer}. Unlinked payment rejected!`;
      } else if (actualToVerified && !actualAmountVerified) {
        failureReason = `USDC transfer detected, but amount ${Number(actualAmount) / 1e6} USDC < ${Number(minimumAtomicValue) / 1e6} USDC. Underpayment rejected!`;
      }

      return {
        ...defaultEvidence,
        receiptStatus: 'success',
        blockNumber: Number(receipt.blockNumber),
        fromVerified: actualFromVerified,
        toVerified: actualToVerified,
        amountVerified: actualAmountVerified,
        amountUSDC: (Number(actualAmount) / 1e6).toFixed(2),
        error: failureReason
      };
    }

    return {
      verified: true,
      chain: 'Base Mainnet (8453)',
      receiptStatus: 'success',
      txHash,
      blockNumber: Number(receipt.blockNumber),
      gasUsed: receipt.gasUsed.toString(),
      fromVerified: true,
      toVerified: true,
      amountVerified: true,
      payer: expectedPayer,
      payTo: expectedPayTo,
      amountUSDC: (Number(actualAmount) / 1e6).toFixed(2),
      tokenContract: BASE_USDC_MAINNET
    };
  } catch (err: any) {
    return {
      ...defaultEvidence,
      error: `Base RPC receipt query error: ${err?.message || 'Transaction not found or pending'}`
    };
  }
}

/**
 * 2. REAL ON-CHAIN PRE-FLIGHT VERIFIER
 * Checks payer's actual USDC balance on Base Mainnet and on-chain authorizationState.
 */
export async function verifyOnChainPayerBalance(
  authorizer: string,
  nonce: string,
  requiredAtomic: bigint = BigInt(SENTINEL_PRICE_ATOMIC)
): Promise<{
  sufficient: boolean;
  balanceUSDC: string;
  nonceAlreadyUsedOnChain: boolean;
  error?: string;
}> {
  const client = getBasePublicClient();

  try {
    const [balance, nonceUsed] = await Promise.all([
      client.readContract({
        address: BASE_USDC_MAINNET as `0x${string}`,
        abi: USDC_EIP3009_ABI,
        functionName: 'balanceOf',
        args: [authorizer as `0x${string}`]
      }) as Promise<bigint>,
      client.readContract({
        address: BASE_USDC_MAINNET as `0x${string}`,
        abi: USDC_EIP3009_ABI,
        functionName: 'authorizationState',
        args: [authorizer as `0x${string}`, nonce as `0x${string}`]
      }).catch(() => false) as Promise<boolean>
    ]);

    const balanceUSDC = (Number(balance) / 1e6).toFixed(2);
    const sufficient = balance >= requiredAtomic;

    if (!sufficient) {
      return {
        sufficient: false,
        balanceUSDC,
        nonceAlreadyUsedOnChain: nonceUsed,
        error: `Payer ${authorizer} has ${balanceUSDC} USDC on Base Mainnet, but ${Number(requiredAtomic) / 1e6} USDC is required.`
      };
    }

    if (nonceUsed) {
      return {
        sufficient: true,
        balanceUSDC,
        nonceAlreadyUsedOnChain: true,
        error: `Authorization nonce ${nonce} has already been consumed on Base blockchain.`
      };
    }

    return {
      sufficient: true,
      balanceUSDC,
      nonceAlreadyUsedOnChain: false
    };
  } catch (err: any) {
    return {
      sufficient: false,
      balanceUSDC: '0.00',
      nonceAlreadyUsedOnChain: false,
      error: `Base Mainnet RPC query failed: ${err?.message || 'RPC Timeout'}`
    };
  }
}

/**
 * 3. EXECUTE FACILITATOR CALLS (VERIFY & SETTLE)
 * Implements real HTTP communication with x402 Facilitator.
 */
export async function callFacilitatorVerify(
  facilitatorUrl: string,
  paymentPayload: V2PaymentPayload,
  paymentRequirements: V2PaymentRequirements
): Promise<{ valid: boolean; reason?: string }> {
  try {
    const res = await fetch(`${facilitatorUrl.replace(/\/$/, '')}/verify`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        x402Version: 2,
        paymentPayload,
        paymentRequirements
      })
    });

    if (!res.ok) {
      const text = await res.text();
      return { valid: false, reason: `Facilitator verify HTTP ${res.status}: ${text.slice(0, 150)}` };
    }

    const data = await res.json();
    return { valid: data.isValid !== false, reason: data.reason };
  } catch (err: any) {
    return { valid: false, reason: `Facilitator verify network error: ${err?.message}` };
  }
}

export async function callFacilitatorSettle(
  facilitatorUrl: string,
  paymentPayload: V2PaymentPayload,
  paymentRequirements: V2PaymentRequirements
): Promise<{ success: boolean; txHash?: string; error?: string }> {
  try {
    const res = await fetch(`${facilitatorUrl.replace(/\/$/, '')}/settle`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        x402Version: 2,
        paymentPayload,
        paymentRequirements
      })
    });

    if (!res.ok) {
      const text = await res.text();
      return { success: false, error: `Facilitator settle HTTP ${res.status}: ${text.slice(0, 150)}` };
    }

    const data = await res.json();
    const hash = data.txHash || data.transactionHash;
    if (!hash) {
      return { success: false, error: 'Facilitator returned success without transaction hash' };
    }

    return { success: true, txHash: hash };
  } catch (err: any) {
    return { success: false, error: `Facilitator settle network error: ${err?.message}` };
  }
}
