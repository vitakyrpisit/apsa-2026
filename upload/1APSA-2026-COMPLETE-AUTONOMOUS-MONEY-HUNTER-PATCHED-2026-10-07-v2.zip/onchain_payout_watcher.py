#!/usr/bin/env python3
"""APSA-2026 fail-closed Base USDC receipt watcher.

Revenue is recorded only from confirmed ERC-20 Transfer logs on Base where:
  token == Base USDC
  Transfer.to == operator wallet
  receipt is in a mined block

RPC errors are UNKNOWN, never zero. Wallet balance is informational only.
This process is intentionally receive-only: it never signs or broadcasts.
"""
import json, os, time, datetime, urllib.request

OPERATOR = "0x829f877daAb94D766BB2b8511ad486C40f2C2BDA"
BASE_RPC = "https://mainnet.base.org"
USDC = "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913"
TRANSFER_TOPIC = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628cd4f523b3ef"
STATE_FILE = "ONCHAIN_WATCH_STATE.json"
LEDGER_FILE = "ONCHAIN_CONFIRMED_RECEIPTS.json"
CHUNK = 1500

def rpc(method, params):
    body=json.dumps({"jsonrpc":"2.0","id":1,"method":method,"params":params}).encode()
    req=urllib.request.Request(BASE_RPC,data=body,headers={"Content-Type":"application/json"})
    with urllib.request.urlopen(req,timeout=15) as r:
        data=json.loads(r.read().decode())
    if "error" in data:
        raise RuntimeError(data["error"])
    return data["result"]

def hexint(v): return int(v,16)

def load_state():
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE) as f: return json.load(f)
    latest=hexint(rpc("eth_blockNumber",[]))
    return {"next_block": max(0, latest-5)}

def save_state(s):
    with open(STATE_FILE,"w") as f: json.dump(s,f,indent=2)

def load_ledger():
    if os.path.exists(LEDGER_FILE):
        with open(LEDGER_FILE) as f:
            x=json.load(f)
            return x if isinstance(x,dict) else {"receipts":[]}
    return {"receipts":[]}

def scan_once():
    state=load_state()
    ledger=load_ledger()
    latest=hexint(rpc("eth_blockNumber",[]))
    start=int(state["next_block"])
    receipts=ledger.setdefault("receipts",[])
    seen={r.get("txHash")+":"+str(r.get("logIndex")) for r in receipts if r.get("txHash")}

    if start > latest:
        return {"status":"OK","latest_block":latest,"new_receipts":[],"confirmed_revenue_usd":0.0}

    end=min(latest,start+CHUNK-1)
    topic_to="0x"+"0"*24+OPERATOR[2:].lower()
    logs=rpc("eth_getLogs",[{
        "address":USDC,
        "fromBlock":hex(start),
        "toBlock":hex(end),
        "topics":[TRANSFER_TOPIC,None,topic_to]
    }])

    new=[]
    for log in logs:
        tx=log["transactionHash"]
        idx=hexint(log["logIndex"])
        key=tx+":"+str(idx)
        if key in seen: continue
        amount=hexint(log["data"])/1e6
        if amount <= 0: continue
        item={
            "timestamp":datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "network":"Base Mainnet (8453)",
            "asset":"USDC",
            "token":USDC,
            "txHash":tx,
            "logIndex":idx,
            "blockNumber":hexint(log["blockNumber"]),
            "from":"0x"+log["topics"][1][-40:],
            "to":"0x"+log["topics"][2][-40:],
            "amountUSDC":amount,
            "evidence":"CONFIRMED_BASE_USDC_TRANSFER_LOG"
        }
        receipts.append(item); new.append(item); seen.add(key)

    state["next_block"]=end+1
    save_state(state)
    ledger["operator_wallet"]=OPERATOR
    ledger["receipts"]=receipts
    ledger["confirmed_revenue_usd"]=sum(float(r["amountUSDC"]) for r in receipts)
    ledger["last_scan"]={
        "status":"OK","from_block":start,"to_block":end,"latest_block":latest,
        "new_receipts":len(new),
        "revenue_evidence":"TRANSACTION_LEVEL_BASE_USDC_TRANSFER_LOGS_ONLY"
    }
    with open(LEDGER_FILE,"w") as f: json.dump(ledger,f,indent=2)
    return ledger["last_scan"] | {"new_receipts":new,"confirmed_revenue_usd":ledger["confirmed_revenue_usd"]}

def main():
    interval=int(os.getenv("WATCH_INTERVAL_SECONDS","15"))
    while True:
        try:
            result=scan_once()
            print(json.dumps(result,indent=2),flush=True)
        except Exception as e:
            print(json.dumps({
                "status":"UNKNOWN_RPC_FAILURE",
                "timestamp":datetime.datetime.now(datetime.timezone.utc).isoformat(),
                "confirmed_revenue_usd":None,
                "error":str(e),
                "warning":"No revenue conclusion is allowed while RPC evidence is unavailable."
            }),flush=True)
        time.sleep(interval)

if __name__=="__main__":
    main()
