"""Референсный детерминированный policy gate (учебный каркас, без зависимостей).

Не production-компонент: правила и инструменты задаются в ТЗ конкретного агента.
Принципы: allowlist, проверка путей и доменов, подтверждения, лимиты, fail-closed.
"""
from __future__ import annotations

import posixpath
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional
from urllib.parse import urlparse


class Status(str, Enum):
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    ESCALATE = "ESCALATE_TO_HUMAN"


class Risk(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


@dataclass(frozen=True)
class ToolPolicy:
    name: str
    risk: Risk
    reversible: bool = True
    external_effect: bool = False
    required_args: tuple[str, ...] = ()
    path_args: tuple[str, ...] = ()     # аргументы-пути, проверяются на scope
    url_args: tuple[str, ...] = ()      # аргументы-URL, проверяются на домены
    needs_idempotency_key: bool = False


@dataclass
class Policy:
    tools: dict[str, ToolPolicy]
    allowed_roots: tuple[str, ...] = ("/workspace",)
    allowed_domains: tuple[str, ...] = ()
    max_steps: int = 20
    max_cost_usd: float = 5.0
    max_repeat_same_action: int = 2


@dataclass
class RunState:
    steps: int = 0
    cost_usd: float = 0.0
    history: list[str] = field(default_factory=list)  # отпечатки исполненных действий
    rejected: list[str] = field(default_factory=list)  # отпечатки отклонённых действий


@dataclass(frozen=True)
class ActionProposal:
    action_id: str
    tool_name: str
    arguments: dict[str, Any]
    purpose: str
    idempotency_key: Optional[str] = None
    approval_id: Optional[str] = None   # выдаётся человеком; подлинность проверяет вызывающий код


@dataclass
class Decision:
    status: Status
    violations: list[str] = field(default_factory=list)
    directive: Optional[str] = None


def _fingerprint(p: ActionProposal) -> str:
    return f"{p.tool_name}:{sorted(p.arguments.items(), key=lambda kv: kv[0])!r}"


def _path_in_scope(path: Any, roots: tuple[str, ...]) -> bool:
    if not isinstance(path, str) or "\x00" in path or not path.startswith("/"):
        return False
    norm = posixpath.normpath(path)
    if ".." in path.split("/"):
        return False
    return any(norm == r or norm.startswith(r.rstrip("/") + "/") for r in roots)


def _url_in_scope(url: Any, domains: tuple[str, ...]) -> bool:
    if not isinstance(url, str):
        return False
    parsed = urlparse(url)
    host = (parsed.hostname or "").lower()
    if parsed.scheme not in ("https",) or not host:
        return False
    return any(host == d or host.endswith("." + d) for d in domains)


def check(
    p: ActionProposal,
    policy: Policy,
    state: RunState,
    human_approved_ids: frozenset[str] = frozenset(),
) -> Decision:
    """Проверяет предложение. Любое исключение -> REJECTED (fail-closed)."""
    try:
        return _check(p, policy, state, human_approved_ids)
    except Exception as exc:  # noqa: BLE001 - намеренно ловим всё: fail-closed
        return Decision(Status.REJECTED, [f"gate_error:{type(exc).__name__}"],
                        "Проверка не удалась; действие не выполнено.")


def _check(p: ActionProposal, policy: Policy, state: RunState, approved: frozenset[str]) -> Decision:
    v: list[str] = []

    # 1. Лимиты
    if state.steps >= policy.max_steps:
        return Decision(Status.REJECTED, ["max_steps_exceeded"], "Остановиться и сообщить пользователю.")
    if state.cost_usd >= policy.max_cost_usd:
        return Decision(Status.REJECTED, ["budget_exceeded"], "Остановиться и сообщить пользователю.")
    fp = _fingerprint(p)
    if state.history.count(fp) >= policy.max_repeat_same_action:
        return Decision(Status.REJECTED, ["loop_detected"], "Сменить подход или запросить уточнение.")
    # повтор уже отклонённого действия = попытка обхода блокировки -> стоп/эскалация
    if state.rejected.count(fp) >= 1:
        return Decision(Status.ESCALATE, ["repeat_after_rejection"],
                        "Не повторять отклонённое действие; остановиться и сообщить человеку.")

    # 2. Allowlist инструментов
    tool = policy.tools.get(p.tool_name)
    if tool is None:
        return Decision(Status.REJECTED, ["tool_not_allowed"], "Использовать только разрешённые инструменты.")

    # 3. Схема
    for name in tool.required_args:
        if name not in p.arguments:
            v.append(f"missing_arg:{name}")
    if not p.purpose.strip():
        v.append("missing_purpose")

    # 4. Scope путей и доменов
    for name in tool.path_args:
        if name in p.arguments and not _path_in_scope(p.arguments[name], policy.allowed_roots):
            v.append(f"path_out_of_scope:{name}")
    for name in tool.url_args:
        if name in p.arguments and not _url_in_scope(p.arguments[name], policy.allowed_domains):
            v.append(f"url_out_of_scope:{name}")

    # 5. Идемпотентность
    if tool.needs_idempotency_key and not p.idempotency_key:
        v.append("missing_idempotency_key")

    if v:
        return Decision(Status.REJECTED, v, "Исправить аргументы внутри разрешённого scope.")

    # 6. Подтверждение человеком
    needs_human = (
        tool.risk in (Risk.HIGH, Risk.CRITICAL)
        or tool.external_effect
        or not tool.reversible
    )
    if needs_human:
        if p.approval_id and p.approval_id in approved:
            return Decision(Status.APPROVED)
        return Decision(Status.ESCALATE, ["human_approval_required"],
                        "Показать человеку точное действие, объект, данные и последствия.")

    return Decision(Status.APPROVED)


def note_rejection(p: ActionProposal, state: RunState) -> None:
    """Вызывать, когда действие отклонено gate или человеком."""
    state.rejected.append(_fingerprint(p))


def record(p: ActionProposal, state: RunState, cost_usd: float = 0.0) -> None:
    """Вызывать после исполнения одобренного действия."""
    state.steps += 1
    state.cost_usd += cost_usd
    state.history.append(_fingerprint(p))
