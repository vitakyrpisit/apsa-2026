import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from policy_gate import (ActionProposal, Policy, Risk, RunState, Status,  # noqa: E402
                         ToolPolicy, check, note_rejection, record)

POLICY = Policy(
    tools={
        "read_file": ToolPolicy("read_file", Risk.LOW, required_args=("path",), path_args=("path",)),
        "write_file": ToolPolicy("write_file", Risk.MEDIUM, required_args=("path", "content"),
                                 path_args=("path",), needs_idempotency_key=True),
        "fetch": ToolPolicy("fetch", Risk.LOW, required_args=("url",), url_args=("url",)),
        "send_email": ToolPolicy("send_email", Risk.HIGH, external_effect=True, reversible=False,
                                 required_args=("to", "body")),
    },
    allowed_roots=("/workspace",),
    allowed_domains=("example.com",),
    max_steps=3,
    max_cost_usd=1.0,
)


def P(tool, args, **kw):
    return ActionProposal("a1", tool, args, kw.pop("purpose", "по ТЗ"), **kw)


class GateTests(unittest.TestCase):
    def setUp(self):
        self.state = RunState()

    def test_read_in_scope_approved(self):
        self.assertEqual(check(P("read_file", {"path": "/workspace/a.txt"}), POLICY, self.state).status,
                         Status.APPROVED)

    def test_unknown_tool_rejected(self):
        self.assertEqual(check(P("shell", {"cmd": "ls"}), POLICY, self.state).status, Status.REJECTED)

    def test_path_traversal_rejected(self):
        for bad in ("/workspace/../etc/passwd", "/etc/passwd", "relative.txt", "/workspace\x00/x"):
            d = check(P("read_file", {"path": bad}), POLICY, self.state)
            self.assertEqual(d.status, Status.REJECTED, bad)

    def test_prefix_trick_rejected(self):
        d = check(P("read_file", {"path": "/workspace-evil/a"}), POLICY, self.state)
        self.assertEqual(d.status, Status.REJECTED)

    def test_domain_allowlist(self):
        ok = check(P("fetch", {"url": "https://api.example.com/x"}), POLICY, self.state)
        self.assertEqual(ok.status, Status.APPROVED)
        for bad in ("https://evil.com/x", "http://example.com/x", "https://example.com.evil.com/"):
            self.assertEqual(check(P("fetch", {"url": bad}), POLICY, self.state).status,
                             Status.REJECTED, bad)

    def test_write_needs_idempotency_key(self):
        a = {"path": "/workspace/o.txt", "content": "x"}
        self.assertEqual(check(P("write_file", a), POLICY, self.state).status, Status.REJECTED)
        self.assertEqual(check(P("write_file", a, idempotency_key="k1"), POLICY, self.state).status,
                         Status.APPROVED)

    def test_external_action_escalates_then_approved_with_human_id(self):
        a = {"to": "x@y.z", "body": "hi"}
        self.assertEqual(check(P("send_email", a), POLICY, self.state).status, Status.ESCALATE)
        self.assertEqual(check(P("send_email", a, approval_id="h1"), POLICY, self.state,
                               frozenset({"h1"})).status, Status.APPROVED)
        # подделанный approval_id не проходит
        self.assertEqual(check(P("send_email", a, approval_id="fake"), POLICY, self.state,
                               frozenset({"h1"})).status, Status.ESCALATE)

    def test_step_limit(self):
        for i in range(3):
            p = P("read_file", {"path": f"/workspace/{i}"})
            self.assertEqual(check(p, POLICY, self.state).status, Status.APPROVED)
            record(p, self.state)
        self.assertEqual(check(P("read_file", {"path": "/workspace/9"}), POLICY, self.state).status,
                         Status.REJECTED)

    def test_loop_detection(self):
        p = P("read_file", {"path": "/workspace/same"})
        for _ in range(2):
            record(p, self.state)
        self.assertIn("loop_detected", check(p, POLICY, self.state).violations)

    def test_repeat_after_rejection_escalates(self):
        p = P("read_file", {"path": "/etc/passwd"})
        self.assertEqual(check(p, POLICY, self.state).status, Status.REJECTED)
        note_rejection(p, self.state)
        d = check(p, POLICY, self.state)
        self.assertEqual(d.status, Status.ESCALATE)
        self.assertIn("repeat_after_rejection", d.violations)

    def test_budget(self):
        self.state.cost_usd = 1.0
        self.assertEqual(check(P("read_file", {"path": "/workspace/a"}), POLICY, self.state).status,
                         Status.REJECTED)

    def test_fail_closed_on_internal_error(self):
        bad = ActionProposal("a", "read_file", {"path": "/workspace/a"}, purpose=None)  # type: ignore[arg-type]
        self.assertEqual(check(bad, POLICY, self.state).status, Status.REJECTED)

    def test_missing_purpose_rejected(self):
        d = check(P("read_file", {"path": "/workspace/a"}, purpose="  "), POLICY, self.state)
        self.assertEqual(d.status, Status.REJECTED)


if __name__ == "__main__":
    unittest.main()
