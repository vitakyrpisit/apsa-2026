# Источники и история версий

Дата сборки: 2026-10-09.

## 1. Источники, прочитанные напрямую
**OpenAI**
- System Card GPT-6 Astra: https://deploymentsafety.openai.com/gpt-6-astra/sec%3Aappendix-sol-luna (разделы 1–9)
- Safety overview: https://openai.com/index/safety-overview-gpt-6-astra/
- Анонс: https://openai.com/index/gpt-6-astra/
- API guide «Using GPT-6»: https://developers.openai.com/api/docs/guides/latest-model
- GPT-6 Sol/Luna: TechCrunch https://techcrunch.com/2026/09/22/openai-launches-gpt-6-sol-and-luna/ · GitHub Changelog https://github.blog/changelog/2026-09-22-openais-gpt-6-sol-and-gpt-6-luna-now-available/
- «dots»: https://www.datacamp.com/blog/openai-dots (вторичный источник)

**ARC Prize**
- https://arcprize.org/arc-agi · https://arcprize.org/arc-agi/3 · https://docs.arcprize.org/ (methodology, agents-quickstart, llm_agents)
- ARC-AGI-2 technical report: https://arcprize.org/blog/arc-agi-2-technical-report
- ARC-AGI-3 technical report: https://arcprize.org/media/ARC_AGI_3_Technical_Report.pdf
- Chollet, On the Measure of Intelligence: https://arxiv.org/abs/1911.01547

## 2. Что не удалось прочитать
Тело приложения «GPT-6 Sol, GPT-6 Luna» и «dots», разделы Preparedness, Safeguards, Threat Modeling, Trust-based Access, Security Controls (в доступном тексте страницы — только оглавление); таблицы и графики, представленные картинками. Не проверялись независимо цифры OpenAI и ARC Prize. Подробно — `09`, п. 0.

## 3. История версий
| Версия | Что было | Проблемы |
|---|---|---|
| Пакеты 1–3 (загружены пользователем) | Пересказы принципов Astra/ARC, роли Sol–Luna, шаблоны | Пересказы без первоисточника; Sol/Luna как «спецификация OpenAI»; логирование CoT как обязательное; в числе «приоров» — счёт (для ARC-AGI-3 неверно) |
| v4.0 | Консолидация 1–3 без чтения источников | Источники не проверены; Sol–Luna оставлены как роли |
| **v5.0** | Пересборка по первоисточникам | Sol/Luna убраны из ролей (это модели); добавлены проверенные находки и требования (`09`); мониторинг переработан (full-context, CoT недостаточен); приоры ARC исправлены; добавлены тесты обхода блокировок, ложных отчётов, межагентных указаний, матрица разрешений, явный scope |

## 4. Принципы пакета
явный authorized scope + gate в коде · политика подтверждений · не обходить блокировки · недоверенные данные включая сообщения других агентов · мониторинг всех прогонов full-context, CoT недостаточен · честные отчёты, проверка заявлений · honeypot/невыполнимые задачи · осознание теста ≠ надёжность · обобщение вместо заучивания, эффективность действий · релиз по блокирующей оценке и ограниченному запуску.
