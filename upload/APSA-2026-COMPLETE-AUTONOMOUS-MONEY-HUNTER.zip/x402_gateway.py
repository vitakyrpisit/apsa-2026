#!/usr/bin/env python3
"""
APSA-2026: Python x402 Micropayment Gateway
Enforces strict x402 v2 payment requirements and on-chain receipt verification.
Zero free access: Merely presenting an unverified header is strictly rejected.
"""
import json
import logging
import urllib.request
from http.server import HTTPServer, BaseHTTPRequestHandler

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] [x402-PY-GATEWAY] %(message)s')

OPERATOR_WALLET = "0x829f877daAb94D766BB2b8511ad486C40f2C2BDA"
MEMO_TAG = "578354"
PRICE_USDC = 9.50
PRICE_ATOMIC = "9500000"
BASE_USDC_CONTRACT = "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913"

class X402GatewayHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/" or self.path == "/health":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            resp = {
                "status": "ACTIVE",
                "protocol": "x402-v2",
                "network": "Base Mainnet (eip155:8453)",
                "pay_to": OPERATOR_WALLET,
                "asset": "USDC",
                "contract": BASE_USDC_CONTRACT,
                "price": f"${PRICE_USDC} USDC"
            }
            self.wfile.write(json.dumps(resp).encode())
            return
        
        self.send_response(404)
        self.end_headers()

    def do_POST(self):
        if self.path == "/api/v1/agent-query":
            content_length = int(self.headers.get('Content-Length', 0))
            body_bytes = self.rfile.read(content_length) if content_length > 0 else b'{}'
            
            # Check for x402 payment authorization / receipt
            sig_header = self.headers.get("PAYMENT-SIGNATURE") or self.headers.get("X-Payment-Receipt")
            
            if not sig_header:
                # 402 Payment Required
                requirements = {
                    "x402Version": 2,
                    "scheme": "exact",
                    "network": "eip155:8453",
                    "amount": PRICE_ATOMIC,
                    "payTo": OPERATOR_WALLET,
                    "asset": BASE_USDC_CONTRACT,
                    "priceUSD": PRICE_USDC
                }
                self.send_response(402)
                self.send_header("Content-Type", "application/json")
                self.send_header("PAYMENT-REQUIRED", json.dumps(requirements))
                self.end_headers()
                err_resp = {
                    "error": "Payment Required",
                    "status": "UNPAID",
                    "message": "Payment authorization of 9.50 USDC on Base Mainnet required to execute query.",
                    "requirements": requirements
                }
                self.wfile.write(json.dumps(err_resp).encode())
                return
            
            # CRITICAL SECURITY RULE:
            # We must never grant paid outcome merely because a header exists.
            # Must verify on Base node via local Express x402 server or RPC.
            try:
                # Forward to production x402 server on port 3000
                req = urllib.request.Request(
                    "http://127.0.0.1:3000/sentinelshield",
                    data=body_bytes,
                    headers={
                        "Content-Type": "application/json",
                        "PAYMENT-SIGNATURE": sig_header
                    }
                )
                with urllib.request.urlopen(req, timeout=5) as node_resp:
                    res_data = node_resp.read()
                    self.send_response(node_resp.status)
                    self.send_header("Content-Type", "application/json")
                    self.end_headers()
                    self.wfile.write(res_data)
                    return
            except urllib.error.HTTPError as he:
                self.send_response(he.code)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(he.read())
                return
            except Exception as e:
                self.send_response(503)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({"error": f"Settlement backend verification unavailable: {str(e)}"}).encode())
                return

        self.send_response(404)
        self.end_headers()

def run_gateway(port=8001):
    logging.info(f"Starting APSA x402 Python Gateway on port {port}...")
    server = HTTPServer(("0.0.0.0", port), X402GatewayHandler)
    server.serve_forever()

if __name__ == "__main__":
    run_gateway()
