#!/bin/bash
echo "=========================================================="
echo "    ЗАПУСК АВТОНОМНОГО КОМПЛЕКСА APSA-2026 (PRODUCTION)   "
echo "    МИССИЯ: РЕАЛЬНЫЕ АКТИВЫ НА КОШЕЛЬКИ ОПЕРАТОРА         "
echo "=========================================================="

echo "1. Проверка Python окружения..."
python3 --version || { echo "Ошибка: Python 3 не установлен!"; exit 1; }

echo ""
echo "2. Проверка зафиксированных кошельков оператора (RECEIVE-ONLY):"
cat wallets_config.json | grep -E "address|network"

echo ""
echo "3. Запуск верификационного цикла APSA-2026 (Single Cycle):"
python3 agent_core.py --single-cycle

echo ""
echo "4. Проверка тестового набора Node/TypeScript (12/12 проверок):"
npm test

echo ""
echo "Комплекс готов к непрерывной автономной работе."
