/**
 * Complete project file bundler for offline distribution.
 * Packages all actual source code, tests, schemas, and reports into a genuine ZIP Blob
 * directly in browser memory using Vite ?raw imports.
 * Completely immune to proxy cookie checks and offline drops.
 */

import { createZipArchive, triggerDownload, ZipFileInput } from './zipGenerator';

// Use Vite's native ?raw loader to bundle the exact, live repository files
import reportMd from '../../REPORT.md?raw';
import finalEvidenceMd from '../../FINAL_EVIDENCE_REPORT.md?raw';
import serverTs from '../../server.ts?raw';
import testSuiteTs from '../../test-suite.ts?raw';
import walletsConfigJson from '../../wallets_config.json?raw';
import agentCorePy from '../../agent_core.py?raw';
import bountyScannerPy from '../../bounty_scanner.py?raw';
import x402GatewayPy from '../../x402_gateway.py?raw';
import requirementsTxt from '../../requirements.txt?raw';
import runSh from '../../run.sh?raw';
import protocolApsaMd from '../../PROTOCOL_APSA_2026.md?raw';
import masterProtocolMd from '../../MASTER_PROTOCOL_AI_MONEY_HUNTER.md?raw';
import activationAuditMd from '../../ACTIVATION_AUDIT_2026-10-06.md?raw';
import aiMoneyStoriesMd from '../../AI_MONEY_STORIES_ANALYSIS.md?raw';
import instructionsForAiAgentMd from '../../INSTRUCTIONS_FOR_AI_AGENT.md?raw';
import facilitatorTs from '../services/x402Facilitator.ts?raw';
import serverCoreTs from '../services/x402ServerCore.ts?raw';
import sentinelShieldCoreTs from '../services/sentinelShieldCore.ts?raw';
import baseRpcTs from '../services/baseRpc.ts?raw';
import x402SimulatorTs from '../services/x402Simulator.ts?raw';
import typesTs from '../types/x402.ts?raw';
import empiricalDataTs from '../data/empiricalData.ts?raw';
import packageJson from '../../package.json?raw';
import metadataJson from '../../metadata.json?raw';
import tsconfigJson from '../../tsconfig.json?raw';
import viteConfigTs from '../../vite.config.ts?raw';

export function generateFullProjectZip(): Blob {
  const files: ZipFileInput[] = [
    { path: 'REPORT.md', content: reportMd },
    { path: 'FINAL_EVIDENCE_REPORT.md', content: finalEvidenceMd },
    { path: 'PROTOCOL_APSA_2026.md', content: protocolApsaMd },
    { path: 'MASTER_PROTOCOL_AI_MONEY_HUNTER.md', content: masterProtocolMd },
    { path: 'ACTIVATION_AUDIT_2026-10-06.md', content: activationAuditMd },
    { path: 'INSTRUCTIONS_FOR_AI_AGENT.md', content: instructionsForAiAgentMd },
    { path: 'AI_MONEY_STORIES_ANALYSIS.md', content: aiMoneyStoriesMd },
    { path: 'wallets_config.json', content: walletsConfigJson },
    { path: 'agent_core.py', content: agentCorePy },
    { path: 'bounty_scanner.py', content: bountyScannerPy },
    { path: 'x402_gateway.py', content: x402GatewayPy },
    { path: 'requirements.txt', content: requirementsTxt },
    { path: 'run.sh', content: runSh },
    { path: 'package.json', content: packageJson },
    { path: 'metadata.json', content: metadataJson },
    { path: 'server.ts', content: serverTs },
    { path: 'test-suite.ts', content: testSuiteTs },
    { path: 'tsconfig.json', content: tsconfigJson },
    { path: 'vite.config.ts', content: viteConfigTs },
    { path: 'src/types/x402.ts', content: typesTs },
    { path: 'src/data/empiricalData.ts', content: empiricalDataTs },
    { path: 'src/services/x402Facilitator.ts', content: facilitatorTs },
    { path: 'src/services/x402ServerCore.ts', content: serverCoreTs },
    { path: 'src/services/sentinelShieldCore.ts', content: sentinelShieldCoreTs },
    { path: 'src/services/baseRpc.ts', content: baseRpcTs },
    { path: 'src/services/x402Simulator.ts', content: x402SimulatorTs }
  ];

  return createZipArchive(files);
}

export function downloadProjectZip(): void {
  const blob = generateFullProjectZip();
  triggerDownload(blob, 'x402-autonomous-profit-experiment.zip');
}
