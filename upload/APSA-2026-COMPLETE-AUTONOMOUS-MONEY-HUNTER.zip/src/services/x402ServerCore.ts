/**
 * Production x402 v2 Resource Server Core for SentinelShield.
 * Uses official @x402/express, @x402/evm/exact/server, and @x402/core/http.
 * Implements strict Nonce State Machine (SEEN -> VERIFIED -> SETTLEMENT_PENDING -> SETTLED),
 * official v2 PAYMENT-REQUIRED / PAYMENT-SIGNATURE wire protocol,
 * and unified on-chain post-settlement verification.
 */

import { verifyTypedData, isAddressEqual } from 'viem';
import { x402ResourceServer, paymentMiddleware } from '@x402/express';
import { registerExactEvmScheme } from '@x402/evm/exact/server';
import { HTTPFacilitatorClient } from '@x402/core/http';
import { analyzeContractRisk } from './sentinelShieldCore';
import {
  BASE_MAINNET_RPC,
  BASE_MAINNET_CHAIN_ID,
  BASE_USDC_MAINNET,
  PRODUCTION_PAY_TO,
  SENTINEL_PRICE_USDC,
  SENTINEL_PRICE_ATOMIC,
  DEFAULT_FACILITATOR_URL,
  V2PaymentPayload,
  V2PaymentRequirements,
  verifyOnChainPayerBalance,
  verifySettlementEvidence,
  callFacilitatorVerify,
  callFacilitatorSettle,
  SettlementEvidence
} from './x402Facilitator';
export { PRODUCTION_PAY_TO, SENTINEL_PRICE_USDC, BASE_USDC_MAINNET, BASE_MAINNET_CHAIN_ID, SENTINEL_PRICE_ATOMIC };
import { SentinelShieldInput, SentinelShieldOutput } from '../types/x402';

// 1. NONCE STATE MACHINE (Audit Point #10)
export type NonceState = 'SEEN' | 'VERIFIED' | 'SETTLEMENT_PENDING' | 'SETTLED' | 'SETTLEMENT_FAILED';

export interface NonceRecord {
  state: NonceState;
  timestamp: number;
  payer: string;
  amount: string;
  txHash?: string;
  failureReason?: string;
}

const nonceRegistry = new Map<string, NonceRecord>();

export function getNonceState(payer: string, nonce: string): NonceRecord | undefined {
  return nonceRegistry.get(`${payer.toLowerCase()}-${nonce.toLowerCase()}`);
}

export function setNonceState(
  payer: string,
  nonce: string,
  state: NonceState,
  amount: string = SENTINEL_PRICE_ATOMIC,
  extra: { txHash?: string; failureReason?: string } = {}
): NonceRecord {
  const key = `${payer.toLowerCase()}-${nonce.toLowerCase()}`;
  const record: NonceRecord = {
    state,
    timestamp: Date.now(),
    payer: payer.toLowerCase(),
    amount,
    txHash: extra.txHash,
    failureReason: extra.failureReason
  };
  nonceRegistry.set(key, record);
  return record;
}

// 2. OFFICIAL X402 V2 ROUTE SPECIFICATION
export const SENTINEL_ROUTE_CONFIG = {
  "POST /sentinelshield": {
    accepts: [
      {
        scheme: "exact",
        network: "eip155:8453",
        price: "$9.50",
        payTo: PRODUCTION_PAY_TO,
        asset: BASE_USDC_MAINNET
      }
    ]
  }
};

/**
 * Creates the official x402ResourceServer using @x402 packages.
 */
export function createOfficialResourceServer(facilitatorUrl: string = DEFAULT_FACILITATOR_URL): x402ResourceServer {
  const facilitatorClient = new HTTPFacilitatorClient({ url: facilitatorUrl });
  const server = new x402ResourceServer(facilitatorClient);
  registerExactEvmScheme(server, { networks: ['eip155:8453'] });
  return server;
}

/**
 * Generates official x402 v2 payment requirements.
 */
export function generateV2PaymentRequirements(resourceUri: string = '/sentinelshield'): V2PaymentRequirements {
  return {
    x402Version: 2,
    scheme: 'exact',
    network: 'eip155:8453',
    amount: SENTINEL_PRICE_ATOMIC,
    payTo: PRODUCTION_PAY_TO,
    asset: BASE_USDC_MAINNET,
    maxTimeoutSeconds: 3600,
    extra: {
      name: 'USD Coin',
      version: '2',
      chainId: BASE_MAINNET_CHAIN_ID,
      priceUSD: SENTINEL_PRICE_USDC,
      resource: resourceUri,
      description: 'SentinelShield Smart Contract Vulnerability Triage & SARIF Report'
    }
  };
}

/**
 * Parses payment payload from HTTP headers or request body.
 * Supports official v2 `PAYMENT-SIGNATURE` header or JSON body.
 */
export function extractPaymentPayload(reqHeaders: Record<string, any>, reqBody: any): V2PaymentPayload | null {
  // 1. Official v2 PAYMENT-SIGNATURE header
  const sigHeader =
    reqHeaders['payment-signature'] ||
    reqHeaders['Payment-Signature'] ||
    reqHeaders['PAYMENT-SIGNATURE'];

  if (typeof sigHeader === 'string' && sigHeader.trim()) {
    try {
      const decoded = Buffer.from(sigHeader.trim(), 'base64').toString('utf8');
      return JSON.parse(decoded);
    } catch {
      try {
        return JSON.parse(sigHeader);
      } catch {
        // Fall through
      }
    }
  }

  // 2. Body payload envelope
  if (reqBody && typeof reqBody === 'object') {
    if (reqBody.paymentPayload) return reqBody.paymentPayload;
    if (reqBody.payload && reqBody.x402Version) return reqBody as V2PaymentPayload;
    // Backward compatibility with authorization payload
    if (reqBody.paymentAuthorization || (reqBody.from && reqBody.signature)) {
      const auth = reqBody.paymentAuthorization || reqBody;
      return {
        x402Version: 2,
        payload: {
          authorization: {
            from: auth.from,
            to: auth.to || PRODUCTION_PAY_TO,
            value: auth.value || SENTINEL_PRICE_ATOMIC,
            validAfter: Number(auth.validAfter || 0),
            validBefore: Number(auth.validBefore || Math.floor(Date.now() / 1000) + 3600),
            nonce: auth.nonce
          },
          signature: auth.signature
        }
      };
    }
  }

  return null;
}

export interface PaidRequestHandlerResponse {
  statusCode: number;
  headers: Record<string, string>;
  body: any;
}

/**
 * Production handler for POST /sentinelshield.
 * Strictly executes:
 * 1) 402 challenge if payment signature is absent
 * 2) Nonce state machine (SEEN -> VERIFIED -> SETTLEMENT_PENDING -> SETTLED)
 * 3) EIP-712 signature verification
 * 4) Base Mainnet on-chain payer balance check
 * 5) Facilitator / Settlement execution
 * 6) Unified Base Mainnet RPC evidence verification (Transfer.from == payer, Transfer.to == payTo)
 * 7) Outcome production ONLY when payment is fully verified on-chain!
 */
export async function handlePaidSentinelRequest(
  input: SentinelShieldInput,
  rawPayload?: any,
  network: 'eip155:8453' = 'eip155:8453',
  clientTxHash?: string,
  facilitatorUrl: string = DEFAULT_FACILITATOR_URL
): Promise<PaidRequestHandlerResponse> {
  const reqs = generateV2PaymentRequirements('/sentinelshield');
  const encodedReqs = Buffer.from(JSON.stringify(reqs)).toString('base64');

  // STEP 1: Unpaid Request -> HTTP 402 with official v2 PAYMENT-REQUIRED header
  if (!rawPayload) {
    return {
      statusCode: 402,
      headers: {
        'Content-Type': 'application/json',
        'PAYMENT-REQUIRED': encodedReqs,
        'payment-required': encodedReqs,
        'x402-version': '2'
      },
      body: {
        error: 'Payment Required',
        message: 'Access to SentinelShield requires x402 payment authorization.',
        paymentRequirements: reqs
      }
    };
  }

  // Parse payload
  const paymentPayload: V2PaymentPayload =
    typeof rawPayload === 'object' && rawPayload.payload
      ? rawPayload
      : extractPaymentPayload({}, rawPayload) || rawPayload;

  const auth = paymentPayload?.payload?.authorization;
  const signature = paymentPayload?.payload?.signature;

  // STEP 2: Malformed payload checks
  if (!auth || !auth.from || !auth.to || !auth.value || !auth.nonce || !signature) {
    return {
      statusCode: 400,
      headers: { 'Content-Type': 'application/json' },
      body: {
        error: 'Malformed Payment Payload',
        reason: 'Missing required EIP-712 authorization fields: from, to, value, nonce, or signature.'
      }
    };
  }

  // STEP 3: Wrong Recipient Check
  try {
    if (!isAddressEqual(auth.to as `0x${string}`, PRODUCTION_PAY_TO as `0x${string}`)) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: {
          error: 'Invalid Recipient',
          reason: `Payment rejected: payTo must be ${PRODUCTION_PAY_TO}, received ${auth.to}`
        }
      };
    }
  } catch {
    return {
      statusCode: 400,
      headers: { 'Content-Type': 'application/json' },
      body: { error: 'Invalid Recipient', reason: 'Malformed recipient address format' }
    };
  }

  // STEP 4: Wrong Amount Check
  try {
    const valueBig = BigInt(auth.value);
    const requiredBig = BigInt(SENTINEL_PRICE_ATOMIC);
    if (valueBig < requiredBig) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: {
          error: 'Insufficient Payment Amount',
          reason: `Required ${SENTINEL_PRICE_ATOMIC} ($9.50 USDC), received ${auth.value}`
        }
      };
    }
  } catch {
    return {
      statusCode: 400,
      headers: { 'Content-Type': 'application/json' },
      body: { error: 'Invalid Amount Format', reason: 'Malformed value string' }
    };
  }

  // STEP 5: Time window checks
  const now = Math.floor(Date.now() / 1000);
  if (auth.validBefore && Number(auth.validBefore) < now) {
    return {
      statusCode: 400,
      headers: { 'Content-Type': 'application/json' },
      body: { error: 'Authorization Expired', reason: `validBefore (${auth.validBefore}) is in the past` }
    };
  }

  // STEP 6: Nonce State Machine Check (Audit Point #10)
  const existingNonceRecord = getNonceState(auth.from, auth.nonce);
  if (existingNonceRecord?.state === 'SETTLED') {
    return {
      statusCode: 400,
      headers: { 'Content-Type': 'application/json' },
      body: {
        error: 'Nonce Already Settled',
        reason: 'Payment nonce has already been finalized on-chain (Replay Protection Active)'
      }
    };
  }

  if (existingNonceRecord?.state === 'SETTLEMENT_PENDING') {
    return {
      statusCode: 409,
      headers: { 'Content-Type': 'application/json' },
      body: {
        error: 'Settlement In Progress',
        reason: 'This payment authorization is currently undergoing settlement.'
      }
    };
  }

  // Mark nonce as SEEN
  setNonceState(auth.from, auth.nonce, 'SEEN', auth.value);

  // STEP 7: Cryptographic EIP-712 typed signature verification
  try {
    const verified = await verifyTypedData({
      address: auth.from as `0x${string}`,
      domain: {
        name: 'USD Coin',
        version: '2',
        chainId: BigInt(BASE_MAINNET_CHAIN_ID),
        verifyingContract: BASE_USDC_MAINNET as `0x${string}`
      },
      types: {
        TransferWithAuthorization: [
          { name: 'from', type: 'address' },
          { name: 'to', type: 'address' },
          { name: 'value', type: 'uint256' },
          { name: 'validAfter', type: 'uint256' },
          { name: 'validBefore', type: 'uint256' },
          { name: 'nonce', type: 'bytes32' }
        ]
      },
      primaryType: 'TransferWithAuthorization',
      message: {
        from: auth.from as `0x${string}`,
        to: PRODUCTION_PAY_TO as `0x${string}`,
        value: BigInt(auth.value),
        validAfter: BigInt(auth.validAfter || 0),
        validBefore: BigInt(auth.validBefore || now + 3600),
        nonce: auth.nonce as `0x${string}`
      },
      signature: signature as `0x${string}`
    });

    if (!verified) {
      setNonceState(auth.from, auth.nonce, 'SETTLEMENT_FAILED', auth.value, {
        failureReason: 'Cryptographic signature mismatch'
      });
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: { error: 'Invalid Signature', reason: 'Recovered signer address does not match from address.' }
      };
    }
  } catch (err: any) {
    setNonceState(auth.from, auth.nonce, 'SETTLEMENT_FAILED', auth.value, {
      failureReason: err?.message
    });
    return {
      statusCode: 400,
      headers: { 'Content-Type': 'application/json' },
      body: { error: 'Signature Verification Error', reason: err?.message || 'Malformed signature bytes' }
    };
  }

  // Mark nonce as VERIFIED
  setNonceState(auth.from, auth.nonce, 'VERIFIED', auth.value);

  // STEP 8: On-Chain Pre-Flight Payer Balance Check (Audit Point #10)
  // CRITICAL: verifyTypedData() != settlement! A $0 balance payer cannot pay!
  const payerBalanceCheck = await verifyOnChainPayerBalance(
    auth.from,
    auth.nonce,
    BigInt(SENTINEL_PRICE_ATOMIC)
  );

  if (!payerBalanceCheck.sufficient) {
    setNonceState(auth.from, auth.nonce, 'SETTLEMENT_FAILED', auth.value, {
      failureReason: payerBalanceCheck.error
    });
    return {
      statusCode: 402,
      headers: {
        'Content-Type': 'application/json',
        'PAYMENT-REQUIRED': encodedReqs,
        'payment-required': encodedReqs
      },
      body: {
        error: 'Payment Settlement Incomplete',
        status: 'INSUFFICIENT_PAYER_BALANCE',
        signatureValid: true,
        settledOnChain: false,
        payer: auth.from,
        payerBalanceUSDC: payerBalanceCheck.balanceUSDC,
        requiredUSDC: `${SENTINEL_PRICE_USDC} USDC`,
        reason: payerBalanceCheck.error,
        ourRevenueCounted: false
      }
    };
  }

  if (payerBalanceCheck.nonceAlreadyUsedOnChain) {
    setNonceState(auth.from, auth.nonce, 'SETTLED', auth.value, {
      failureReason: 'Nonce consumed in earlier on-chain transaction'
    });
    return {
      statusCode: 400,
      headers: { 'Content-Type': 'application/json' },
      body: {
        error: 'Nonce Already Used On-Chain',
        reason: payerBalanceCheck.error
      }
    };
  }

  // STEP 9: Settlement Execution
  // Mark nonce as SETTLEMENT_PENDING
  setNonceState(auth.from, auth.nonce, 'SETTLEMENT_PENDING', auth.value);

  let settlementTxHash = clientTxHash;

  // If no client-provided transaction hash, invoke Facilitator /settle
  if (!settlementTxHash) {
    const settleResult = await callFacilitatorSettle(facilitatorUrl, paymentPayload, reqs);
    if (settleResult.success && settleResult.txHash) {
      settlementTxHash = settleResult.txHash;
    } else {
      setNonceState(auth.from, auth.nonce, 'SETTLEMENT_FAILED', auth.value, {
        failureReason: settleResult.error
      });
      return {
        statusCode: 402,
        headers: {
          'Content-Type': 'application/json',
          'PAYMENT-REQUIRED': encodedReqs,
          'payment-required': encodedReqs
        },
        body: {
          error: 'Payment Settlement Incomplete',
          status: 'FACILITATOR_SETTLEMENT_FAILED',
          signatureValid: true,
          settledOnChain: false,
          payer: auth.from,
          reason: settleResult.error || 'Facilitator could not broadcast settlement transaction to Base Mainnet.',
          ourRevenueCounted: false
        }
      };
    }
  }

  // STEP 10: UNIFIED POST-SETTLEMENT EVIDENCE VERIFICATION (Audit Point #8 & #9)
  // Must verify Transfer.from == payer, Transfer.to == payTo, amount >= 9500000 on Base Mainnet
  const evidence: SettlementEvidence = await verifySettlementEvidence(
    settlementTxHash,
    auth.from,
    PRODUCTION_PAY_TO,
    BigInt(SENTINEL_PRICE_ATOMIC)
  );

  if (!evidence.verified) {
    setNonceState(auth.from, auth.nonce, 'SETTLEMENT_FAILED', auth.value, {
      txHash: settlementTxHash,
      failureReason: evidence.error
    });
    return {
      statusCode: 402,
      headers: {
        'Content-Type': 'application/json',
        'PAYMENT-REQUIRED': encodedReqs,
        'payment-required': encodedReqs
      },
      body: {
        error: 'Settlement Evidence Verification Failed',
        status: 'UNVERIFIED_ON_CHAIN',
        txHash: settlementTxHash,
        settledOnChain: false,
        payer: auth.from,
        reason: evidence.error,
        evidenceDetails: evidence,
        ourRevenueCounted: false
      }
    };
  }

  // STEP 11: Mark nonce as SETTLED! Real money has been confirmed on Base Mainnet!
  setNonceState(auth.from, auth.nonce, 'SETTLED', auth.value, {
    txHash: settlementTxHash
  });

  // STEP 12: Deliver proprietary SentinelShield outcome
  const outcome: SentinelShieldOutput = await analyzeContractRisk(input);

  const paymentResponseData = {
    status: 'SETTLED',
    x402Version: 2,
    txHash: settlementTxHash,
    blockNumber: evidence.blockNumber,
    gasUsed: evidence.gasUsed,
    payer: auth.from,
    payTo: PRODUCTION_PAY_TO,
    token: BASE_USDC_MAINNET,
    amountUSDC: SENTINEL_PRICE_USDC,
    verifiedOnRpc: true
  };

  const encodedPaymentResponse = Buffer.from(JSON.stringify(paymentResponseData)).toString('base64');

  return {
    statusCode: 200,
    headers: {
      'Content-Type': 'application/json',
      'PAYMENT-RESPONSE': encodedPaymentResponse,
      'payment-response': encodedPaymentResponse,
      'x402-settlement': 'confirmed',
      'x402-tx-hash': settlementTxHash,
      'x402-block-number': String(evidence.blockNumber || '')
    },
    body: {
      success: true,
      service: 'SentinelShield Contract Risk Triage',
      payment: paymentResponseData,
      outcome
    }
  };
}
