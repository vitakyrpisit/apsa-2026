/**
 * Production HTTP Resource Server for x402 SentinelShield.
 * Uses official @x402/express, @x402/evm/exact/server, and @x402/core/http.
 * Serves /health, /.well-known/x402-manifest.json, /sentinelshield, and Facilitator endpoints on port 3000.
 */

import express, { Request, Response } from 'express';
import path from 'path';
import {
  handlePaidSentinelRequest,
  generateV2PaymentRequirements,
  SENTINEL_ROUTE_CONFIG,
  extractPaymentPayload,
  createOfficialResourceServer
} from './src/services/x402ServerCore';
import {
  PRODUCTION_PAY_TO,
  SENTINEL_PRICE_USDC,
  BASE_USDC_MAINNET,
  BASE_MAINNET_CHAIN_ID,
  DEFAULT_FACILITATOR_URL,
  verifyOnChainPayerBalance,
  verifySettlementEvidence
} from './src/services/x402Facilitator';
import { fetchLiveOnChainStatus } from './src/services/baseRpc';

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const isProduction = process.env.NODE_ENV === 'production';

app.use(express.json({ limit: '5mb' }));

// 1. FREE HEALTH ENDPOINT (Prompt Section 9)
app.get('/health', (_req: Request, res: Response) => {
  res.status(200).json({
    status: 'ok',
    protocol: 'x402-v2',
    service: 'SentinelShield Contract Risk Triage',
    network: 'Base Mainnet (eip155:8453)',
    asset: 'USDC',
    tokenAddress: BASE_USDC_MAINNET,
    price: `${SENTINEL_PRICE_USDC.toFixed(2)} USDC`,
    payTo: PRODUCTION_PAY_TO,
    facilitatorUrl: DEFAULT_FACILITATOR_URL
  });
});

// 2. OFFICIAL MACHINE-READABLE DISCOVERY MANIFEST (Prompt Section 27)
app.get('/.well-known/x402-manifest.json', (_req: Request, res: Response) => {
  res.status(200).json({
    x402Version: 2,
    service: 'SentinelShield Contract Risk Triage',
    description: 'Deterministic smart contract security audit, AST vulnerability matrix, and SARIF report generation.',
    pricing: {
      scheme: 'exact',
      network: 'eip155:8453',
      chainId: BASE_MAINNET_CHAIN_ID,
      asset: 'USDC',
      tokenAddress: BASE_USDC_MAINNET,
      amount: '9500000',
      amountUSDC: SENTINEL_PRICE_USDC,
      payTo: PRODUCTION_PAY_TO
    },
    facilitator: {
      url: DEFAULT_FACILITATOR_URL,
      type: 'http-facilitator-v2',
      endpoints: {
        supported: `${DEFAULT_FACILITATOR_URL}/supported`,
        verify: `${DEFAULT_FACILITATOR_URL}/verify`,
        settle: `${DEFAULT_FACILITATOR_URL}/settle`
      }
    },
    endpoint: '/sentinelshield',
    healthEndpoint: '/health',
    expectedLatencyMs: 1250,
    inputSchema: {
      type: 'object',
      properties: {
        contractAddress: { type: 'string', description: 'Base or Ethereum contract address (0x...)' },
        chain: { type: 'string', enum: ['base', 'ethereum'], default: 'base' },
        bytecode: { type: 'string', description: 'Runtime bytecode hex string' },
        sourceCode: { type: 'string', description: 'Solidity source code string' }
      }
    },
    outputSchema: {
      type: 'object',
      properties: {
        riskLevel: { type: 'string', enum: ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'SECURE'] },
        overallScore: { type: 'number', minimum: 0, maximum: 100 },
        summary: { type: 'string' },
        exploitability: { type: 'string' },
        findings: { type: 'array' },
        sarif: { type: 'object' }
      }
    }
  });
});

// 3. FACILITATOR ROUTER (Real HTTP Facilitator Endpoints)
app.get('/api/facilitator/supported', (_req: Request, res: Response) => {
  res.status(200).json({
    kinds: [
      {
        x402Version: 2,
        scheme: 'exact',
        network: 'eip155:8453',
        extra: {
          asset: BASE_USDC_MAINNET,
          assetName: 'USD Coin',
          decimals: 6
        }
      }
    ],
    extensions: [],
    signers: {}
  });
});

app.post('/api/facilitator/verify', async (req: Request, res: Response) => {
  const { paymentPayload, paymentRequirements } = req.body || {};
  const auth = paymentPayload?.payload?.authorization;
  if (!auth) {
    return res.status(400).json({ isValid: false, reason: 'Missing authorization payload' });
  }

  const preFlight = await verifyOnChainPayerBalance(auth.from, auth.nonce, BigInt(auth.value || '9500000'));
  if (!preFlight.sufficient) {
    return res.status(200).json({ isValid: false, reason: preFlight.error });
  }

  res.status(200).json({ isValid: true, payerBalanceUSDC: preFlight.balanceUSDC });
});

app.post('/api/facilitator/settle', async (req: Request, res: Response) => {
  const { paymentPayload } = req.body || {};
  const auth = paymentPayload?.payload?.authorization;
  if (!auth) {
    return res.status(400).json({ success: false, error: 'Missing authorization payload' });
  }

  const preFlight = await verifyOnChainPayerBalance(auth.from, auth.nonce, BigInt(auth.value || '9500000'));
  if (!preFlight.sufficient) {
    return res.status(400).json({ success: false, error: preFlight.error });
  }

  // If no funded relayer private key is provided in environment, report honest refusal
  const relayerKey = process.env.SETTLEMENT_RELAYER_KEY || process.env.OPERATOR_PRIVATE_KEY;
  if (!relayerKey) {
    return res.status(503).json({
      success: false,
      error: 'Facilitator settlement unavailable: No funded relayer configured on this node to broadcast Base gas.'
    });
  }

  res.status(501).json({ success: false, error: 'Relayer broadcast not triggered without operator approval.' });
});

// 4. PRODUCTION PAID ENDPOINT: POST /sentinelshield (x402 v2 Protected)
app.post('/sentinelshield', async (req: Request, res: Response) => {
  // Extract payment payload from v2 headers or body
  const payload = extractPaymentPayload(req.headers, req.body);
  const clientTxHash = (req.headers['x-402-tx-hash'] || req.headers['x-tx-hash'] || req.body?.txHash) as string | undefined;

  const result = await handlePaidSentinelRequest(
    req.body || {},
    payload,
    'eip155:8453',
    clientTxHash,
    `http://127.0.0.1:${PORT}/api/facilitator`
  );

  for (const [k, v] of Object.entries(result.headers)) {
    res.setHeader(k, v);
  }
  res.status(result.statusCode).json(result.body);
});

// 5. LIVE ON-CHAIN RPC STATUS FOR OPERATOR WALLET (Prompt Section 20)
app.get('/api/onchain/status', async (_req: Request, res: Response) => {
  try {
    const status = await fetchLiveOnChainStatus(PRODUCTION_PAY_TO, 'base-mainnet');
    res.status(200).json(status);
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'RPC Error' });
  }
});

// 6. RUNTIME SETTLEMENT EVIDENCE VERIFIER (Audit Point #8 & #9)
app.post('/api/verify/tx', async (req: Request, res: Response) => {
  const { txHash, payer = '' } = req.body;
  if (!txHash) {
    return res.status(400).json({ error: 'Missing txHash in request body' });
  }

  const evidence = await verifySettlementEvidence(txHash, payer, PRODUCTION_PAY_TO);
  res.status(evidence.verified ? 200 : 404).json(evidence);
});

// 7. MULTI-RAIL OPERATOR STATUS & MONEY RADAR
app.get('/api/wallets/status', async (_req: Request, res: Response) => {
  try {
    const walletsConfig = JSON.parse(await import('fs').then(fs => fs.promises.readFile('./wallets_config.json', 'utf8')));
    const baseStatus = await fetchLiveOnChainStatus(PRODUCTION_PAY_TO, 'base-mainnet');
    res.status(200).json({
      timestamp: new Date().toISOString(),
      wallets: walletsConfig.wallets,
      liveBaseStatus: baseStatus,
      targetRails: ['EVM (Base/Eth/Arb)', 'Solana', 'Tron', 'Bitcoin'],
      policy: 'RECEIVE_ONLY_STRICT_ONCHAIN'
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 8. ZIP & ARCHIVE DOWNLOAD ROUTES (Guaranteed Direct HTTP Downloads)
const publicDir = path.resolve(process.cwd(), 'public');
app.use(express.static(publicDir));

const serveArchiveZip = (_req: Request, res: Response) => {
  const zipPath = path.resolve(process.cwd(), 'public/x402-autonomous-profit-experiment.zip');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', 'attachment; filename="APSA-2026-COMPLETE-AUTONOMOUS-MONEY-HUNTER.zip"');
  res.sendFile(zipPath);
};

const serveArchiveTar = (_req: Request, res: Response) => {
  const tarPath = path.resolve(process.cwd(), 'public/x402-autonomous-profit-experiment.tar.gz');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Content-Type', 'application/gzip');
  res.setHeader('Content-Disposition', 'attachment; filename="APSA-2026-COMPLETE-AUTONOMOUS-MONEY-HUNTER.tar.gz"');
  res.sendFile(tarPath);
};

app.get('/api/download/bundle.zip', serveArchiveZip);
app.get('/download', serveArchiveZip);
app.get('/bundle.zip', serveArchiveZip);
app.get('/archive.zip', serveArchiveZip);
app.get('/x402-autonomous-profit-experiment.zip', serveArchiveZip);
app.get('/x402-autonomous-profit-experiment.tar.gz', serveArchiveTar);

// 9. MOUNT VITE MIDDLEWARE (DEV) OR STATIC ASSETS (PROD)
async function startServer() {
  if (!isProduction) {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true, hmr: process.env.DISABLE_HMR !== 'true' },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[x402 Server v2] SentinelShield active on port ${PORT}`);
    console.log(`[x402 Server v2] Operator PayTo: ${PRODUCTION_PAY_TO} (Base Mainnet)`);
  });
}

startServer();
