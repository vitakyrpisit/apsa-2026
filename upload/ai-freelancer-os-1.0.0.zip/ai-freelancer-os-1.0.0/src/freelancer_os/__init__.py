"""AI Freelancer OS — real agent runtime (v1.0.0)."""
__version__ = "1.0.0"
