"""Central configuration. Safe by default: mock mode, dry-run, tiny spend caps."""
from __future__ import annotations

from decimal import Decimal
from pathlib import Path
from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore", case_sensitive=False)

    # --- run mode -------------------------------------------------------
    mode: Literal["mock", "live"] = "mock"
    # In live mode dry_run=True still discovers/scores/works locally but NEVER claims,
    # pushes, opens PRs or delivers. Flip to false only after `fos doctor` is green.
    dry_run: bool = True
    data_dir: Path = Path("./data")

    # --- LLM ---------------------------------------------------------------
    llm_provider: Literal["anthropic", "gemini", "zai", "openai_compat", "none"] = "anthropic"
    llm_model: str = "claude-sonnet-5-5"
    qa_llm_provider: Literal["anthropic", "gemini", "zai", "openai_compat", "none", "same"] = "same"
    qa_llm_model: str = ""  # empty => same as llm_model (use a different model for stronger independence)
    anthropic_api_key: str = ""
    gemini_api_key: str = ""
    zai_api_key: str = ""                                   # Z.ai (GLM) via its OpenAI-compatible API
    zai_base_url: str = "https://api.z.ai/api/paas/v4"      # Coding-Plan subscribers: use the coding endpoint from Z.ai docs
    openai_compat_api_key: str = ""
    openai_compat_base_url: str = ""
    llm_extra_body: str = ""                                # JSON merged into the request body, e.g. {"thinking":{"type":"disabled"}}
    llm_price_in_per_mtok: Decimal = Decimal("3")    # USD, override for your model
    llm_price_out_per_mtok: Decimal = Decimal("15")
    max_llm_cost_per_job_usd: Decimal = Decimal("4.00")
    compute_cost_per_hour_usd: Decimal = Decimal("0.10")  # sandbox cost accounting
    keep_workspaces: bool = False

    # --- sandbox -----------------------------------------------------------
    sandbox_backend: Literal["docker", "local"] = "docker"
    sandbox_image: str = "freelancer-os-sandbox:latest"
    sandbox_cpus: float = 2.0
    sandbox_memory_mb: int = 4096
    sandbox_timeout_s: int = 900
    allow_unsafe_local_sandbox: bool = False  # local backend runs untrusted code on your host

    # --- git / github ------------------------------------------------------
    github_token: str = ""
    allow_local_repos: bool = False  # only for evals/tests
    git_author_name: str = "AI Freelancer OS"
    git_author_email: str = "agent@users.noreply.github.com"

    # --- marketplaces ------------------------------------------------------
    enabled_marketplaces: str = "mock"  # comma list: mock,basedagents,taskbounty
    basedagents_api_url: str = "https://api.basedagents.ai"
    basedagents_keypair_path: Path = Path("./data/keys/basedagents.json")
    basedagents_fee_rate: Decimal = Decimal("0.00")  # VERIFIED 2026-10-08: 0% marketplace fee, full bounty to agent (BasedAgents skill.md §6)
    taskbounty_mcp_url: str = ""
    taskbounty_api_key: str = ""
    taskbounty_agent_id: str = ""
    taskbounty_fee_rate: Decimal = Decimal("0.20")
    # PUBLIC payout addresses only. The agent never holds a spending key.
    wallet_evm: str = ""        # ETH / Arbitrum / Base / any EVM chain
    wallet_solana: str = ""
    wallet_tron: str = ""
    wallet_bitcoin: str = ""
    # Networks the operator has VERIFIED can receive deposits at the address above (comma list: base,ethereum,arbitrum,solana,tron,bitcoin).
    wallet_confirmed_networks: str = ""
    basedagents_keypair_json: str = ""   # CI runners: JSON of the agent keypair (stored as a secret); written to keypair path on start
    payment_timeout_days: int = 14

    # --- agent skills (what we honestly claim to be able to do) -------------
    supported_languages: str = "python"
    skill_proficiency: str = "python:0.9,pytest:0.9,fastapi:0.8,sqlalchemy:0.7,django:0.6,flask:0.75,pydantic:0.85,asyncio:0.75,docker:0.5,git:0.9"

    # --- treasury / policy -------------------------------------------------
    max_daily_spend_usd: Decimal = Decimal("10")
    max_job_spend_usd: Decimal = Decimal("5")
    human_approval_threshold_usd: Decimal = Decimal("100")
    first_n_jobs_require_approval: int = 3
    min_budget_usd: Decimal = Decimal("5")
    min_expected_profit_usd: Decimal = Decimal("2")
    min_roi: Decimal = Decimal("2.0")          # expected_profit / expected_cost
    min_p_success_auto: float = 0.65
    min_p_success_hard: float = 0.45
    max_concurrent_jobs: int = 1
    breaker_window: int = 20                 # circuit breaker looks at the last N finished jobs
    breaker_min_jobs: int = 8
    breaker_min_lower_bound: float = 0.30    # Wilson lower bound of success rate must stay above this
    breaker_max_net_loss_usd: Decimal = Decimal("15")  # rolling 30-day net loss that trips the breaker
    kill_switch_file: Path = Path("./data/KILL")

    # --- agent loop ---------------------------------------------------------
    agent_max_steps: int = 30
    agent_max_fix_rounds: int = 3
    max_patch_bytes: int = 200_000
    require_llm_qa_in_live: bool = True

    # --- api ------------------------------------------------------------------
    api_token: str = Field(default="")
    api_host: str = "127.0.0.1"
    api_port: int = 8000

    @property
    def db_path(self) -> Path:
        return self.data_dir / "freelancer_os.sqlite3"

    @property
    def workspaces_dir(self) -> Path:
        return self.data_dir / "workspaces"

    @property
    def artifacts_dir(self) -> Path:
        return self.data_dir / "artifacts"

    def proficiency_map(self) -> dict[str, float]:
        out: dict[str, float] = {}
        for part in self.skill_proficiency.split(","):
            if ":" in part:
                k, v = part.split(":", 1)
                try:
                    out[k.strip().lower()] = max(0.0, min(1.0, float(v)))
                except ValueError:
                    continue
        return out

    def languages(self) -> set[str]:
        return {x.strip().lower() for x in self.supported_languages.split(",") if x.strip()}

    def marketplaces(self) -> list[str]:
        return [x.strip().lower() for x in self.enabled_marketplaces.split(",") if x.strip()]

    def ensure_dirs(self) -> None:
        for p in (self.data_dir, self.workspaces_dir, self.artifacts_dir, self.basedagents_keypair_path.parent):
            p.mkdir(parents=True, exist_ok=True)


def load_settings(**overrides) -> Settings:
    return Settings(**overrides)
