"""
Structured JSON logging with per-job correlation IDs.

Replaces ad-hoc print() calls in pipeline.py and marketplace adapters.
Every log line carries:
  - timestamp (ISO 8601 UTC)
  - level (INFO/WARNING/ERROR/DEBUG)
  - event (free-text, snake_case)
  - job_key (when applicable — every line within a job's lifecycle)
  - marketplace (when applicable)
  - extra fields (free-form, JSON-serializable)

Output is JSON-lines format — one log object per line — directly ingestible
by standard log shippers (Loki, Datadog, CloudWatch, ELK).

Per Anthropic's published principle of "transparency" (engineering blog,
"Building effective agents"): every agent decision and tool call should be
auditable after the fact.
"""

from __future__ import annotations
import json
import logging
import sys
import time
import uuid
from contextvars import ContextVar
from typing import Any

# ContextVar so any code inside a job's lifecycle can attach the job_key
# without threading it through every function signature.
_job_key: ContextVar[str | None] = ContextVar("fos_job_key", default=None)
_marketplace: ContextVar[str | None] = ContextVar("fos_marketplace", default=None)


class JSONFormatter(logging.Formatter):
    """One JSON object per line. Fail-safe on non-serialisable extras."""

    def format(self, record: logging.LogRecord) -> str:
        obj: dict[str, Any] = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(record.created)),
            "level": record.levelname,
            "logger": record.name,
            "event": record.getMessage(),
        }
        # Attach correlation IDs from ContextVar.
        jk = _job_key.get()
        if jk:
            obj["job_key"] = jk
        mp = _marketplace.get()
        if mp:
            obj["marketplace"] = mp

        # Attach extra fields the caller passed via logger.info(..., extra={...}).
        for k, v in record.__dict__.items():
            if k.startswith("_") or k in {
                "args", "asctime", "created", "exc_info", "exc_text",
                "filename", "funcName", "levelname", "levelno", "lineno",
                "module", "msecs", "message", "msg", "name", "pathname",
                "process", "processName", "relativeCreated", "stack_info",
                "thread", "threadName", "taskName",
            }:
                continue
            try:
                json.dumps(v)  # probe serialisability
                obj[k] = v
            except (TypeError, ValueError):
                obj[k] = repr(v)

        if record.exc_info:
            obj["exc"] = self.formatException(record.exc_info)

        return json.dumps(obj, ensure_ascii=False, default=str)


def setup_logging(level: str = "INFO") -> None:
    """Configure root logger to emit JSON-lines to stdout."""
    root = logging.getLogger()
    root.setLevel(getattr(logging, level.upper(), logging.INFO))
    # Remove pre-existing handlers (e.g. uvicorn's) so we get clean JSON.
    for h in list(root.handlers):
        root.removeHandler(h)
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(JSONFormatter())
    root.addHandler(handler)


def set_job_context(job_key: str | None, marketplace: str | None = None) -> None:
    """Bind a job_key + marketplace to the current async task's context."""
    _job_key.set(job_key)
    _marketplace.set(marketplace)


def new_correlation_id() -> str:
    """Generate a fresh correlation ID for events not tied to a job."""
    return uuid.uuid4().hex
