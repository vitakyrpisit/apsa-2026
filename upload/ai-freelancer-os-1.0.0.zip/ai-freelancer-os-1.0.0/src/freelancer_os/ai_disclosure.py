"""
Canonical AI disclosure text. Used in every PR body and delivery note
where the marketplace requires it. See docs/AI_DISCLOSURE.md for the
full policy.
"""

DISCLOSURE_TEXT = """This work was produced with the assistance of an AI coding agent
(ai-freelancer-os v1.0.0, LLM: GLM-5.1 via Z.ai Open API).

Method:
1. Reproduced the reported issue from a clean checkout.
2. Wrote a regression test capturing the buggy behaviour.
3. Implemented a minimal fix.
4. Ran the full pytest suite in an isolated Docker sandbox
   (--network none, --cap-drop ALL, non-root user).
5. An independent QA pass re-applied the patch to a fresh checkout at
   the base SHA and ran hidden validator tests plus deterministic
   anti-cheat checks (no deleted tests, no weakened assertions, no
   protected files touched, no secrets in diff). The QA verdict can
   only DOWNGRADE — never upgrade — the agent's self-assessment.
6. Opened this pull request with the patch, the regression test, and
   this disclosure.

No secrets, credentials, or private data were used or exfiltrated.
The agent never saw this PR's review feedback while working on it.
"""


def disclosure_for_marketplace(marketplace: str) -> str:
    """Return disclosure with marketplace-specific prefix."""
    prefixes = {
        "taskbounty": "[AI Disclosure — required by TaskBounty ToS]\n",
        "basedagents": "[AI Disclosure]\n",
        "agentpact": "[AI Disclosure — transparency]\n",
        "toku": "[AI Disclosure — transparency]\n",
        "mercatai": "[AI Disclosure — EU AI Act Art. 52]\n",
    }
    return prefixes.get(marketplace.lower(), "[AI Disclosure]\n") + DISCLOSURE_TEXT
