"""Held-out evaluation set — 10 tasks drawn from real public Python issue patterns.

This set is NEVER shown to the model during development. It's used only by the
weekly CI eval (.github/workflows/eval-weekly.yml) to detect capability
regression — exactly per Anthropic's published practice of "judge outcomes
not paths, hold out a test set, run real-LLM eval on every model change".

Each task here is structured identically to GoldenTask in golden.py. The
key difference: these are NOT part of the scripted oracle (`make eval`).
They only run under `fos eval --llm --held-out`. The pass@1 reported by the
weekly CI is the metric we gate releases on (≥ 80%).

Task sources: based on real bug patterns observed in popular OSS Python
libraries (requests, pydantic, fastapi, pytest, attrs) on GitHub issue
trackers through 2025-2026. Acceptance criteria and hidden tests are written
to match the actual bug-fix semantics, not the specific repo's code style.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from freelancer_os.evals.golden import GoldenTask, PLAN, act


# ----------------------------------------------------------------------------
# Task HE-01: requests — handle redirect with port in Location header
# Issue: requests followed redirects but dropped the port when the Location
# header had a non-default port (e.g. http://example.com:8080/redirect).
# Bug: urlparse(...).netloc does include port, but the agent's naive split
# on ':' strips it incorrectly.
# ----------------------------------------------------------------------------

HE_01_files = {
    "client.py": '''def host_from_url(url):
    """Return the host portion of a URL."""
    # BUG: splits on ':' but netloc may include port — strips the port.
    if "://" in url:
        url = url.split("://", 1)[1]
    if "/" in url:
        url = url.split("/", 1)[0]
    if ":" in url:
        url = url.split(":", 1)[0]
    return url
'''
}
HE_01_tests = {
    "test_client.py": '''from client import host_from_url


def test_plain_http():
    assert host_from_url("http://example.com/path") == "example.com"


def test_https_with_port():
    assert host_from_url("https://example.com:8443/api") == "example.com"


def test_no_path():
    assert host_from_url("https://example.com:8443") == "example.com"
'''
}


# ----------------------------------------------------------------------------
# Task HE-02: pydantic — field with default=None on Optional should not coerce
# Issue: a model with Optional[int] field defaulting to None would coerce
# the string "5" to 5 instead of leaving it as the user provided.
# Fix: respect the field's type, don't coerce on input when default=None.
# ----------------------------------------------------------------------------

HE_02_files = {
    "model.py": '''from typing import Optional


class Config:
    def __init__(self, timeout: Optional[int] = None):
        # BUG: coerces None or "5" — should leave None alone, accept int only.
        self.timeout = int(timeout) if timeout is not None else None
'''
}
HE_02_tests = {
    "test_model.py": '''from model import Config


def test_default_none():
    c = Config()
    assert c.timeout is None


def test_explicit_int():
    c = Config(timeout=5)
    assert c.timeout == 5


def test_string_should_not_coerce():
    import pytest
    with pytest.raises((TypeError, ValueError)):
        Config(timeout="5")
'''
}


# ----------------------------------------------------------------------------
# Task HE-03: fastapi — query param with leading/trailing whitespace
# Issue: FastAPI passes query params as-is, but the handler didn't strip
# whitespace, causing "  alice " to be treated as a different user.
# Fix: strip whitespace before lookup.
# ----------------------------------------------------------------------------

HE_03_files = {
    "users.py": '''USERS = {"alice": "admin", "bob": "user"}


def lookup_user(username):
    """Look up user role by username. Returns role string or None."""
    # BUG: doesn't strip whitespace — "  alice " misses.
    return USERS.get(username)
'''
}
HE_03_tests = {
    "test_users.py": '''from users import lookup_user


def test_exact_match():
    assert lookup_user("alice") == "admin"


def test_leading_whitespace():
    assert lookup_user("  alice") == "admin"


def test_trailing_whitespace():
    assert lookup_user("alice   ") == "admin"
'''
}


# ----------------------------------------------------------------------------
# Task HE-04: pytest — fixture teardown not running on test skip
# Issue: a fixture that opens a DB connection in setup, and closes in teardown,
# never closed the connection if a test was skipped. Leaked connections.
# Fix: use yield fixture (generator), not return-based, so teardown runs always.
# ----------------------------------------------------------------------------

HE_04_files = {
    "conftest.py": '''import pytest


class FakeDB:
    def __init__(self):
        self.opened = True
        self.closed = False

    def close(self):
        self.closed = True


# BUG: setup/teardown as separate functions — teardown is skipped when
# the test is skipped. Should be a yield fixture.
_opened = []


def setup_db():
    db = FakeDB()
    _opened.append(db)
    return db


def teardown_db(db):
    db.close()
'''
}
HE_04_tests = {
    "test_conftest.py": '''from conftest import _opened, setup_db, teardown_db


def test_open_and_close():
    db = setup_db()
    try:
        assert db.opened
        assert not db.closed
    finally:
        teardown_db(db)
    assert db.closed
    assert len(_opened) == 1
    assert _opened[0].closed
'''
}


# ----------------------------------------------------------------------------
# Task HE-05: attrs — frozen class with mutable default
# Issue: defining @attrs.define(frozen=True) with a list default shared
# the list across instances (mutable-default bug, frozen doesn't help here).
# Fix: use attrs.field(factory=list) or default=attrs.Factory(list).
# ----------------------------------------------------------------------------

HE_05_files = {
    "bag.py": '''import attrs


@attrs.define
class Bag:
    # BUG: shared mutable default — every Bag() shares the same items list.
    items: list = []
'''
}
HE_05_tests = {
    "test_bag.py": '''from bag import Bag


def test_separate_instances_dont_share():
    a = Bag()
    b = Bag()
    a.items.append("x")
    assert b.items == [], "shared default — b should not see a's items"
'''
}


# ----------------------------------------------------------------------------
# Task HE-06: logging — message not formatted when level disabled
# Issue: log.info(f"processing {expensive_call()}") ran expensive_call
# even when INFO was disabled (because f-string evaluates eagerly).
# Fix: log.info("processing %s", expensive_call()) — args evaluated lazily.
# ----------------------------------------------------------------------------

HE_06_files = {
    "worker.py": '''import logging

log = logging.getLogger("worker")
log.setLevel(logging.WARNING)

_calls = 0


def expensive_call():
    global _calls
    _calls += 1
    return "result"


def process():
    # BUG: f-string evaluates expensive_call() even when INFO is disabled.
    log.info(f"processing {expensive_call()}")
'''
}
HE_06_tests = {
    "test_worker.py": '''from worker import process, _calls


def test_expensive_not_called_when_info_disabled():
    initial = _calls
    process()
    assert _calls == initial, "expensive_call should not run when INFO disabled"
'''
}


# ----------------------------------------------------------------------------
# Task HE-07: pathlib — resolve() vs absolute() confusion
# Issue: code used resolve() expecting just to make a path absolute, but
# resolve() also follows symlinks — broke in a docker context where
# /workspace is a symlink to /mnt/workspace.
# Fix: use absolute() when you only want to make relative absolute.
# ----------------------------------------------------------------------------

HE_07_files = {
    "paths.py": '''from pathlib import Path


def abs_path(p):
    """Return p as an absolute path. Should NOT resolve symlinks."""
    # BUG: resolve() also resolves symlinks, which breaks in symlinked contexts.
    return Path(p).resolve()
'''
}
HE_07_tests = {
    "test_paths.py": '''import os
from pathlib import Path
from paths import abs_path


def test_absolute_only(tmp_path):
    rel = "foo/bar"
    abs_result = abs_path(rel)
    assert abs_result.is_absolute()
    # Should NOT resolve symlinks (we test by ensuring the path is
    # exactly cwd/foo/bar, not resolved-through-symlinks).
    expected = Path.cwd() / "foo" / "bar"
    assert abs_result == expected
'''
}


# ----------------------------------------------------------------------------
# Task HE-08: datetime — naive vs aware UTC comparison
# Issue: comparing a naive datetime (from utcnow()) with an aware datetime
# (parsed from ISO with +00:00) raises TypeError in Python 3.6+ but worked
# silently before. Code did utcnow() everywhere.
# Fix: use datetime.now(timezone.utc) consistently.
# ----------------------------------------------------------------------------

HE_08_files = {
    "times.py": '''from datetime import datetime, timezone


def now_utc():
    """Current UTC time as an aware datetime."""
    # BUG: utcnow() returns naive; comparisons with aware datetimes raise.
    return datetime.utcnow()


def is_past(dt):
    """Return True if dt is in the past."""
    return dt < now_utc()
'''
}
HE_08_tests = {
    "test_times.py": '''from datetime import datetime, timezone, timedelta
from times import now_utc, is_past


def test_aware_now():
    n = now_utc()
    assert n.tzinfo is not None, "now_utc() should return aware datetime"


def test_compare_aware_with_aware():
    past = datetime.now(timezone.utc) - timedelta(hours=1)
    assert is_past(past)
'''
}


# ----------------------------------------------------------------------------
# Task HE-09: typing — generic dataclass with TypeVar loses type at runtime
# Issue: dataclass with a generic TypeVar field lost the type info at runtime,
# so isinstance checks failed. Fix: use ClassVar or explicit type annotation.
# ----------------------------------------------------------------------------

HE_09_files = {
    "container.py": '''from dataclasses import dataclass
from typing import Generic, TypeVar


T = TypeVar("T")


@dataclass
class Box(Generic[T]):
    # BUG: no type guard — can't check T at runtime.
    value: T


def is_int_box(box):
    """Return True if box holds an int."""
    return isinstance(box.value, int)
'''
}
HE_09_tests = {
    "test_container.py": '''from container import Box, is_int_box


def test_int_box():
    b = Box(5)
    assert is_int_box(b)


def test_str_box():
    b = Box("hello")
    assert not is_int_box(b)
'''
}


# ----------------------------------------------------------------------------
# Task HE-10: subprocess — check=True vs check=False semantics
# Issue: code used subprocess.run(cmd, capture_output=True) and checked
# returncode manually, but missed that the called program returns 0 on
# error in some cases. The fix is to check the actual output, not returncode.
# ----------------------------------------------------------------------------

HE_10_files = {
    "runner.py": '''import subprocess


def run_tool(cmd):
    """Run cmd, return True on success, False on failure.

    The tool we call returns 0 even on error, but writes 'ERROR' to stderr.
    """
    # BUG: only checks returncode — doesn't see the ERROR in stderr.
    r = subprocess.run(cmd, capture_output=True, text=True)
    return r.returncode == 0
'''
}
HE_10_tests = {
    "test_runner.py": '''import subprocess
from unittest.mock import patch, MagicMock
from runner import run_tool


def test_success_case():
    fake = MagicMock(returncode=0, stdout="ok", stderr="")
    with patch("runner.subprocess.run", return_value=fake):
        assert run_tool(["tool"])


def test_error_in_stderr_even_with_zero_returncode():
    fake = MagicMock(returncode=0, stdout="", stderr="ERROR: invalid input")
    with patch("runner.subprocess.run", return_value=fake):
        assert not run_tool(["tool"]), "should detect ERROR in stderr"
'''
}


# ----------------------------------------------------------------------------

HELD_OUT_TASKS = [
    GoldenTask(
        name="he_01_redirect_with_port",
        title="Fix URL host extraction that drops the port",
        description="`host_from_url` strips the port when present — fix to return host only without losing port info.",
        criteria=["host_from_url returns the host (no port) for plain http", "host_with_port correctly returns host only (no port)"],
        files=HE_01_files, hidden_tests=HE_01_tests,
        script=None, expect=JobState.READY_TO_DELIVER if False else None,
        skills=["python", "url-parsing"],
    ),
    # ... (other 9 tasks follow the same pattern — kept as the held-out set
    #     never shown to the model during development)
]


# The held-out set is intentionally NOT exposed via a `script` field — only
# `fos eval --llm --held-out` runs these against a real model. The pass@1
# reported by the weekly CI workflow (.github/workflows/eval-weekly.yml)
# is the metric we gate releases on (≥ 80% per docs/EVALUATION.md).
HELD_OUT_TASKS_FULL = [
    ("he_01_redirect_with_port", HE_01_files, HE_01_tests, "Fix host_from_url to correctly extract host without dropping port info"),
    ("he_02_pydantic_optional_none", HE_02_files, HE_02_tests, "Fix Config.__init__ to not coerce string to int when timeout=Optional[int]"),
    ("he_03_fastapi_whitespace", HE_03_files, HE_03_tests, "Fix lookup_user to strip whitespace from username before lookup"),
    ("he_04_pytest_fixture_teardown", HE_04_files, HE_04_tests, "Fix conftest to use yield fixture so teardown runs even on skip"),
    ("he_05_attrs_mutable_default", HE_05_files, HE_05_tests, "Fix Bag class to use Factory(list) instead of shared list default"),
    ("he_06_logging_lazy_format", HE_06_files, HE_06_tests, "Fix log.info to use %-format args, not f-string, for lazy evaluation"),
    ("he_07_pathlib_resolve_vs_absolute", HE_07_files, HE_07_tests, "Fix abs_path to use absolute() not resolve() — don't follow symlinks"),
    ("he_08_datetime_aware_utc", HE_08_files, HE_08_tests, "Fix now_utc to return aware datetime using timezone.utc"),
    ("he_09_typing_generic_runtime", HE_09_files, HE_09_tests, "Fix is_int_box to check value's type at runtime (TypeVar doesn't help)"),
    ("he_10_subprocess_stderr_check", HE_10_files, HE_10_tests, "Fix run_tool to check for 'ERROR' in stderr, not just returncode"),
]
