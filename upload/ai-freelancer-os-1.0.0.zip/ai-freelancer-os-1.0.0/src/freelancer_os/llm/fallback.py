"""
LLM fallback chain — 4-tier provider cascade.

When the primary LLM provider is unavailable (HTTP 429/5xx after retries,
network error, or rate-limit), this module falls through to the next tier
so a single provider outage never blocks a paid task.

Architecture
------------
Tier 1 — Primary (e.g. glm-5.1 via Z.ai Open API)
        Highest-quality model. Cheap enough for production. Pays per token.
Tier 2 — Secondary (e.g. glm-4.6 via Z.ai Open API)
        Lower capability but still production-usable. Pays per token.
Tier 3 — Free tier (e.g. glm-4.5-flash)
        Rate-limited free model. Used only as last resort before tier 4.
Tier 4 — Deterministic degraded
        NO LLM call. Returns a structured "degraded" response that the
        pipeline knows to treat as ABORT rather than FABRICATE. Per ADR 0007,
        we would rather lose a job than fabricate an unverifiable answer.

The fallback only triggers on the following exceptions (from llm/client.py):
    LLMError            — every retryable provider failure (429/5xx after 4 attempts)
    httpx.ConnectError  — DNS/TCP unreachable
    httpx.ReadTimeout   — provider hung
It is NOT triggered by:
    BudgetExceeded      — we've spent too much on this job; abort the job, don't
                          burn budget on a fallback that may be more expensive.

Per ADR 0007 (docs/adr/0007-llm-fallback.md).
"""

from __future__ import annotations
import logging
from dataclasses import dataclass
from typing import Optional

from .client import LLMClient, LLMError, BudgetExceeded

log = logging.getLogger("fos.llm.fallback")


@dataclass(frozen=True)
class FallbackTier:
    """One step in the fallback chain."""
    name: str               # human-readable tier label
    provider: str           # "zai" / "anthropic" / "gemini" / "deterministic"
    model: str              # model name, or "degraded" for tier 4
    api_key_env: str        # env var name that holds the key (or "" for tier 4)


# Default chain — operator can override via LLM_FALLBACK_CHAIN env var (CSV of "provider:model" pairs)
DEFAULT_CHAIN: tuple[FallbackTier, ...] = (
    FallbackTier("primary",      "zai",        "glm-5.1",          "ZAI_API_KEY"),
    FallbackTier("secondary",     "zai",        "glm-4.6",          "ZAI_API_KEY"),
    FallbackTier("free",          "zai",        "glm-4.5-flash",    "ZAI_API_KEY"),
    FallbackTier("deterministic", "deterministic", "degraded",     ""),
)


class FallbackLLMClient(LLMClient):
    """LLM client that cascades through tiers on failure.

    Construction: pass a `build_client` callable that takes (provider, model,
    api_key) and returns an LLMClient. This decouples fallback from the
    concrete provider factory in llm/client.py.
    """

    def __init__(self, chain: tuple[FallbackTier, ...], build_client):
        if not chain:
            raise ValueError("fallback chain must have at least one tier")
        self.chain = chain
        self._build = build_client
        self._tier_used: dict[str, int] = {t.name: 0 for t in chain}

    async def complete(self, system, messages, *, max_tokens=4096, temperature=0.0):
        last_err: Optional[Exception] = None
        for idx, tier in enumerate(self.chain):
            if tier.provider == "deterministic":
                # Tier 4 — return a structured degraded response.
                # The pipeline treats this as an LLM-side ABORT and the job
                # ends FAILED with a clear reason — never a fabricated answer.
                log.warning("fallback: exhausted all live tiers, returning degraded",
                            extra={"tier": tier.name, "last_err": str(last_err)[:200]})
                self._tier_used[tier.name] += 1
                return {
                    "content": (
                        "[degraded: all LLM providers failed after retries; "
                        "do not act on this response. Abort the job.]"
                    ),
                    "tier_used": tier.name,
                    "degraded": True,
                    "tokens_in": 0,
                    "tokens_out": 0,
                    "cost_usd": 0.0,
                }

            # Tiers 1-3 — build a concrete client for this tier and call it.
            import os
            api_key = os.environ.get(tier.api_key_env, "") if tier.api_key_env else ""
            if tier.api_key_env and not api_key:
                log.info("fallback: skipping tier (no api key in env)",
                         extra={"tier": tier.name, "env": tier.api_key_env})
                continue

            try:
                client = self._build(tier.provider, tier.model, api_key)
                result = await client.complete(system, messages,
                                                max_tokens=max_tokens,
                                                temperature=temperature)
                if idx > 0:
                    log.info("fallback: recovered on non-primary tier",
                             extra={"tier": tier.name, "model": tier.model,
                                    "primary_failed_for": str(last_err)[:200]})
                self._tier_used[tier.name] += 1
                # Annotate the result so the pipeline knows which tier served it.
                if isinstance(result, dict):
                    result["tier_used"] = tier.name
                return result
            except BudgetExceeded:
                # NEVER cascade on budget — that's our own spending limit.
                raise
            except (LLMError, Exception) as e:
                last_err = e
                log.warning("fallback: tier failed, cascading",
                            extra={"tier": tier.name, "model": tier.model,
                                    "error": str(e)[:200]})
                continue

        # Should never reach here — tier 4 always returns. But be safe.
        raise LLMError(f"all fallback tiers failed: {last_err}")

    def tier_usage(self) -> dict[str, int]:
        """How many calls were served by each tier. Exported via /v1/metrics."""
        return dict(self._tier_used)


def parse_chain_from_env(env_value: str) -> tuple[FallbackTier, ...]:
    """Parse 'zai:glm-5.1,zai:glm-4.6,zai:glm-4.5-flash,deterministic:degraded' into FallbackTier tuple."""
    if not env_value.strip():
        return DEFAULT_CHAIN
    tiers = []
    for spec in env_value.split(","):
        spec = spec.strip()
        if not spec:
            continue
        if ":" not in spec:
            continue
        provider, model = spec.split(":", 1)
        api_key_env = {
            "zai": "ZAI_API_KEY",
            "anthropic": "ANTHROPIC_API_KEY",
            "gemini": "GEMINI_API_KEY",
            "deterministic": "",
        }.get(provider, f"{provider.upper()}_API_KEY")
        name = {0: "primary", 1: "secondary", 2: "free", 3: "deterministic"}.get(
            len(tiers), f"tier_{len(tiers)}"
        )
        tiers.append(FallbackTier(name, provider, model, api_key_env))
    return tuple(tiers) or DEFAULT_CHAIN
