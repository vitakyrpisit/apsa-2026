"""TaskBounty adapter over its MCP endpoint (JSON-RPC 2.0, Streamable HTTP).

Tool names come from TaskBounty's published MCP server (list_open_bounties, get_bounty_detail, request_repo_access,
submit_pr, check_submission_status). The endpoint URL is NOT hard-coded: set TASKBOUNTY_MCP_URL from your dashboard/docs.
Win model is `open_race`: there is no exclusive claim, so we only do work for bounties we have validated and race to submit a PR.
`fos doctor --live` calls tools/list and fails closed if a required tool is missing.
"""
from __future__ import annotations

import json
import re
from decimal import Decimal
from typing import Any

import httpx

from freelancer_os.domain import ClaimResult, Delivery, Job, PaymentStatus
from freelancer_os.marketplaces.base import Capabilities, MarketplaceAdapter, MarketplaceError

REQUIRED_TOOLS = {"list_open_bounties", "get_bounty_detail", "submit_pr", "check_submission_status"}
_NUM = re.compile(r"(\d+(?:[.,]\d+)?)")
_GH = re.compile(r"https://github\.com/[A-Za-z0-9_.\-]+/[A-Za-z0-9_.\-]+")


def _money(v: Any) -> Decimal:
    if isinstance(v, (int, float, Decimal)):
        return Decimal(str(v))
    m = _NUM.search(str(v or "").replace(",", ""))
    return Decimal(m.group(1)) if m else Decimal(0)


class TaskBountyAdapter(MarketplaceAdapter):
    id = "taskbounty"

    def __init__(self, mcp_url: str, api_key: str, agent_id: str, fee_rate: Decimal, transport: httpx.AsyncBaseTransport | None = None):
        if not mcp_url:
            raise MarketplaceError("TASKBOUNTY_MCP_URL is not set")
        if not mcp_url.startswith("https://") and "localhost" not in mcp_url and "127.0.0.1" not in mcp_url:
            raise MarketplaceError("TASKBOUNTY_MCP_URL must be https")
        self.url, self.agent_id = mcp_url, agent_id
        self.capabilities = Capabilities("open_race", fee_rate, "USDC/Base|SOL|BTC payout address", requires_funding=True, fee_verified=True)
        self._http = httpx.AsyncClient(timeout=45, transport=transport, headers={
            "Authorization": f"Bearer {api_key}", "Content-Type": "application/json", "Accept": "application/json, text/event-stream"})
        self._session: str | None = None
        self._id = 0
        self._init = False

    async def _rpc(self, method: str, params: dict | None = None, notify: bool = False) -> Any:
        self._id += 1
        msg: dict[str, Any] = {"jsonrpc": "2.0", "method": method}
        if params is not None:
            msg["params"] = params
        if not notify:
            msg["id"] = self._id
        headers = {"Mcp-Session-Id": self._session} if self._session else {}
        r = await self._http.post(self.url, json=msg, headers=headers)
        if r.status_code in (401, 403):
            raise MarketplaceError(f"auth rejected ({r.status_code})", status=r.status_code)
        if r.status_code == 429:
            raise MarketplaceError("rate limited", status=429, retryable=True)
        if r.status_code >= 500:
            raise MarketplaceError(f"server error {r.status_code}", status=r.status_code, retryable=True)
        if r.status_code >= 400:
            raise MarketplaceError(f"HTTP {r.status_code}: {r.text[:200]}", status=r.status_code)
        if "mcp-session-id" in r.headers:
            self._session = r.headers["mcp-session-id"]
        if notify or not r.content:
            return None
        body = r.text
        if "text/event-stream" in r.headers.get("content-type", ""):
            datas = [l[5:].strip() for l in body.splitlines() if l.startswith("data:")]
            body = datas[-1] if datas else "{}"
        d = json.loads(body)
        if "error" in d:
            raise MarketplaceError(f"MCP error: {d['error'].get('message', d['error'])}", code=str(d["error"].get("code")))
        return d.get("result")

    async def _ensure_init(self):
        if self._init:
            return
        await self._rpc("initialize", {"protocolVersion": "2025-03-26", "capabilities": {}, "clientInfo": {"name": "ai-freelancer-os", "version": "0.3.0"}})
        await self._rpc("notifications/initialized", {}, notify=True)
        self._init = True

    async def call(self, tool: str, args: dict) -> Any:
        await self._ensure_init()
        res = await self._rpc("tools/call", {"name": tool, "arguments": args})
        if res and res.get("isError"):
            raise MarketplaceError(f"{tool} failed: {self._text(res)[:300]}")
        txt = self._text(res)
        try:
            return json.loads(txt)
        except (json.JSONDecodeError, TypeError):
            return {"text": txt}

    @staticmethod
    def _text(res: Any) -> str:
        if not res:
            return ""
        return "".join(c.get("text", "") for c in res.get("content", []) if isinstance(c, dict))

    def _to_job(self, b: dict[str, Any], detailed: bool = False) -> Job:
        bid = str(b.get("id") or b.get("task_id") or b.get("slug") or "")
        desc = b.get("description") or b.get("body") or ""
        repo = b.get("repo_url") or b.get("repo") or ""
        if repo and not str(repo).startswith("http"):
            repo = f"https://github.com/{repo}"
        if not repo:
            m = _GH.search(desc)
            repo = m.group(0) if m else None
        crit = b.get("evaluation_criteria") or b.get("acceptance_criteria") or []
        if isinstance(crit, str):
            crit = [c.strip("-* ").strip() for c in crit.splitlines() if c.strip()]
        lang = b.get("language")
        return Job(marketplace=self.id, external_id=bid, title=b.get("title", ""), description=desc, repo_url=repo or None,
                   skills=[str(lang).lower()] if lang else [], budget_usd=_money(b.get("reward") or b.get("bounty_amount") or b.get("amount")),
                   acceptance_criteria=[str(c) for c in crit][:12], funded=True if not detailed and b.get("status", "open") == "open" else b.get("funded"),
                   competition=b.get("submission_count"), raw={})

    async def discover(self, limit: int = 30) -> list[Job]:
        d = await self.call("list_open_bounties", {"limit": limit})
        items = d if isinstance(d, list) else d.get("bounties") or d.get("items") or d.get("tasks") or []
        return [self._to_job(b) for b in items if isinstance(b, dict)][:limit]

    async def get_job(self, external_id: str) -> Job:
        d = await self.call("get_bounty_detail", {"task_id": external_id})
        return self._to_job(d.get("bounty", d) if isinstance(d, dict) else {}, detailed=True)

    async def claim(self, job: Job) -> ClaimResult:
        return ClaimResult(ok=True, claim_id="open-race", reason="TaskBounty has no exclusive claim; submit a PR to compete")

    async def deliver(self, job: Job, delivery: Delivery) -> str:
        if not delivery.pr_url:
            raise MarketplaceError("TaskBounty requires an upstream PR URL (external_link)")
        if not self.agent_id:
            raise MarketplaceError("TASKBOUNTY_AGENT_ID is not set")
        d = await self.call("submit_pr", {"task_id": job.external_id, "agent_id": self.agent_id, "result_text": delivery.summary[:4000],
                                          "external_link": delivery.pr_url, "cover_note": f"Independent QA passed. Commit {delivery.commit_sha[:12]}."})
        return str(d.get("submission_id") or d.get("id") or d.get("text", "submitted")[:60])

    async def payment_status(self, job: Job) -> PaymentStatus:
        d = await self.call("check_submission_status", {"task_id": job.external_id, "agent_id": self.agent_id})
        state = str(d.get("status") or d.get("verification_status") or d.get("payout_status") or d.get("text", "")).lower()
        tx = str(d.get("tx_hash") or d.get("payout_tx") or "")
        paid = ("paid" in state or "settled" in state) and bool(tx)
        return PaymentStatus(settled=paid, amount_usd=job.budget_usd if paid else None, tx_ref=tx, state=state, raw=d if isinstance(d, dict) else {})

    async def doctor(self):
        try:
            await self._ensure_init()
            res = await self._rpc("tools/list", {})
            names = {t["name"] for t in (res or {}).get("tools", [])}
            missing = REQUIRED_TOOLS - names
            return [("taskbounty MCP tools", not missing, "ok" if not missing else f"missing: {sorted(missing)}")]
        except Exception as e:  # noqa: BLE001
            return [("taskbounty MCP", False, str(e)[:200])]

    async def aclose(self):
        await self._http.aclose()
