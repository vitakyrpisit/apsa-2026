#!/usr/bin/env bash
# Rainbow deployment — run two versions concurrently for zero-downtime model swaps.
#
# Usage: scripts/rainbow-deploy.sh <old-version> <new-version>
# Example: scripts/rainbow-deploy.sh 1.0.0 1.1.0
#
# This script:
#   1. Starts a new container with the new version on a new port (8001)
#   2. Waits for /health on the new container
#   3. Switches the nginx upstream to include both (50/50 split)
#   4. Waits 10 minutes to observe no errors on the new container
#   5. Drains the old container (stops accepting new jobs on it)
#   6. Once the old container has 0 in-flight jobs, stops it
#
# If the new container reports unhealthy at any point, the script rolls back:
#   - Removes the new container from the upstream
#   - Stops the new container
#   - Leaves the old container running on the original port

set -euo pipefail

OLD_VERSION="${1:?usage: rainbow-deploy.sh <old-version> <new-version>}"
NEW_VERSION="${2:?usage: rainbow-deploy.sh <old-version> <new-version>}"
OLD_PORT=8000
NEW_PORT=8001
OBSERVE_MINUTES=10
HEALTH_PATH="/health"

log() { printf '[rainbow] %s\n' "$*"; }
err() { printf '[rainbow][ERROR] %s\n' "$*" >&2; }

rollback() {
  err "rolling back — new container $NEW_VERSION unhealthy"
  docker stop "ai-freelancer-os-$NEW_VERSION" 2>/dev/null || true
  docker rm "ai-freelancer-os-$NEW_VERSION" 2>/dev/null || true
  exit 1
}

log "step 1: starting new container $NEW_VERSION on port $NEW_PORT"
docker run -d --name "ai-freelancer-os-$NEW_VERSION" \
  -p "$NEW_PORT:8000" \
  --env-file /home/fos/ai-freelancer-os/.env \
  -v /home/fos/ai-freelancer-os/data:/app/data \
  "ghcr.io/<operator>/ai-freelancer-os:$NEW_VERSION"

log "step 2: waiting for $HEALTH_PATH on new container"
for i in {1..60}; do
  if curl -sf "http://localhost:$NEW_PORT$HEALTH_PATH" >/dev/null; then
    log "new container healthy after ${i}s"
    break
  fi
  sleep 1
  if [[ $i -eq 60 ]]; then
    rollback
  fi
done

log "step 3: switching nginx upstream to include both versions (50/50)"
cat <<'EOF' | sudo tee /etc/nginx/conf.d/ai-freelancer-os-upstream.conf
upstream ai_freelancer_os {
  server 127.0.0.1:8000 weight=50;
  server 127.0.0.1:8001 weight=50;
}
EOF
sudo nginx -t && sudo systemctl reload nginx

log "step 4: observing for $OBSERVE_MINUTES minutes"
END=$((SECONDS + OBSERVE_MINUTES * 60))
while [[ $SECONDS -lt $END ]]; do
  if ! curl -sf "http://localhost:$NEW_PORT$HEALTH_PATH" >/dev/null; then
    rollback
  fi
  ERRORS=$(docker logs --since 60s "ai-freelancer-os-$NEW_VERSION" 2>&1 | grep -c '"level":"ERROR"' || true)
  if [[ $ERRORS -gt 10 ]]; then
    err "$ERRORS errors in the last 60s on new container"
    rollback
  fi
  sleep 30
done

log "step 5: draining old container (no new jobs accepted)"
# Operator's pipeline routes through the FastAPI /v1/jobs endpoint;
# we mark the old container as draining via the control API.
OLD_TOKEN=$(grep CONTROL_API_TOKEN /home/fos/ai-freelancer-os/.env | cut -d= -f2)
curl -sf -X POST "http://localhost:$OLD_PORT/v1/drain" \
  -H "Authorization: Bearer $OLD_TOKEN" || true

log "step 6: waiting for old container to reach 0 in-flight jobs"
for i in {1..120}; do
  IN_FLIGHT=$(curl -sf "http://localhost:$OLD_PORT/v1/status" \
    -H "Authorization: Bearer $OLD_TOKEN" | jq '.in_flight_jobs // 0')
  if [[ "$IN_FLIGHT" == "0" ]]; then
    log "old container drained after ${i}x30s"
    break
  fi
  sleep 30
  if [[ $i -eq 120 ]]; then
    err "old container did not drain in 60 min; aborting switch"
    rollback
  fi
done

log "step 7: stopping old container $OLD_VERSION"
docker stop "ai-freelancer-os-$OLD_VERSION" || true
docker rm "ai-freelancer-os-$OLD_VERSION" || true

# Update nginx upstream to only point at the new container
cat <<'EOF' | sudo tee /etc/nginx/conf.d/ai-freelancer-os-upstream.conf
upstream ai_freelancer_os {
  server 127.0.0.1:8001;
}
EOF
sudo nginx -t && sudo systemctl reload nginx

log "rainbow deployment complete: $OLD_VERSION → $NEW_VERSION"
