# Security policy

## Supported versions

| Version | Supported          |
|---------|--------------------|
| 1.0.x   | ✅ active           |
| < 1.0   | ❌ not supported   |

## Reporting a vulnerability

**DO NOT open a public GitHub issue for security vulnerabilities.**

Email: `security@apsa-2026.vercel.app` (forwarded to `valykirpisit@gmail.com`).

PGP fingerprint: `0xDEADBEEFCAFE0000123456789ABCDEF01234567`
(rotate quarterly; current fingerprint published at
`https://apsa-2026.vercel.app/.well-known/security.txt`).

### Coordinated Vulnerability Disclosure

We follow a coordinated disclosure model:

1. **You report privately** — email us with reproduction steps and impact.
2. **We acknowledge within 48 hours** — confirm receipt and start triage.
3. **We investigate and develop a fix** — target 90 days from report to
   public disclosure. Complex issues may extend to 120 days; we will
   communicate the extension.
4. **We coordinate release** — publish the fix and the advisory
   simultaneously, credit you (if desired), and refrain from legal action
   against good-faith reporters.
5. **No credit, no sue** — we will not pursue legal action against
   researchers who follow this policy in good faith, even if they
   inadvertently cause minor disruption.

### Out of scope

- Vulnerabilities in third-party dependencies — report to the upstream
  maintainer; we will track and patch in `requirements.txt` once an
  upstream fix is available.
- Vulnerabilities requiring physical access to the operator's machine.
- Vulnerabilities in marketplaces themselves — report to the marketplace
  operator (BasedAgents support: `support@basedagents.ai`).
- Social engineering attacks against the operator.

## Threat model

This agent is designed to operate in an environment where:

- **The marketplace is partially trusted** — we trust the marketplace to
  enforce the escrow, but we do NOT trust task descriptions, repo
  contents, or messages from buyers. All third-party text is treated as
  untrusted and passes through the two-layer firewall (regex + LLM
  classifier).
- **The LLM provider is partially trusted** — we trust the provider to
  return text completions, but we do NOT trust the model's self-reported
  test results (`parse_pytest` parses the real pytest summary). All LLM
  output is treated as data, never as instructions to the agent loop.
- **The sandbox is untrusted-by-default** — Docker `--network none
  --cap-drop ALL --user non-root` is the real defence. We assume the
  repos we clone may contain malicious code, and the sandbox contains
  it.
- **The operator's wallet is trusted** — the operator's receive-only
  addresses are validated per-chain (EIP-55 for EVM, base58check for
  Tron, bech32 for BTC, 32-byte ed25519 for Solana). The agent never
  sees the private key.

## Supply chain

- **Pinned dependencies**: `requirements.txt` generated via
  `pip-compile` (Makefile: `make lock`). No `>=` floating versions in
  production installs.
- **Secrets scanning in CI**: `.github/workflows/ci.yml` runs
  `trufflehog --only-verified` on every push and pull request.
- **SLSA provenance target**: level 2 (planned for v1.1.0). SBOM
  generated on release via `syft`.
- **CODEOWNERS**: every code change requires review by the operator
  (see `.github/CODEOWNERS`). Security-sensitive paths
  (`security/`, `treasury/`, `sandbox/`, `evals/`, `adr/`) require
  explicit review even when broader ownership applies.

## Bounded loss

- **Per-job LLM budget cap** (default $0.50). `CostMeter` enforces after
  every call; raises `BudgetExceeded` (does NOT cascade to fallback).
- **Per-job spend cap** (default $1.00).
- **Daily spend cap** (default $5.00).
- **Kill switch** (`fos kill` writes `data/KILL`) — `Treasury.killed()`
  returns True → every `execute()` raises `SpendDenied` → job ends
  FAILED. `fos resume` unlinks.
- **Circuit breaker** opens when last N=20 jobs Wilson lower bound <0.30
  (after ≥8 jobs) OR 30-day net P&L < −$15. When open, every job needs
  human approval.
- **First-N-jobs human approval** (default 3) on every marketplace.

## Bounded trust

- **No spending keys** in the codebase, in env vars, in CI secrets.
  Wallet binding is via signature proof only (EIP-191 personal_sign
  moves no funds).
- **Validated wallets**: per-chain checksum validation for EVM/Solana/
  Tron/Bitcoin. `tests/unit/test_wallets.py::test_typos_are_detected`
  catches single-character typos in each chain.
- **Operator-confirmed networks**: `WALLET_CONFIRMED_NETWORKS` is
  empty by default. `fos doctor` refuses live mode until the operator
  has explicitly confirmed each network after a successful small test
  transfer.

## Residual risks (acknowledged)

- **Pattern firewall is bypassable** by novel injection patterns the
  regex doesn't match. The LLM-based second classifier mitigates this,
  but capabilities (sandbox, path jail) are the real defence.
- **Docker escapes** are possible if a CVE in Docker itself is
  exploitable from inside a `--network none --cap-drop ALL` container.
  Mitigation: patch Docker, dedicated VM, consider gVisor or
  Firecracker for v1.1.0.
- **Ed25519 keypair has no recovery path**. Lose `data/keys/
  basedagents.json` and the agent is permanently orphaned. Mitigation:
  `docs/runbooks/production.md` step 5 includes mandatory backup to
  offline storage.
- **Marketplace response drift** — adapters parse defensively, but
  response shapes are unverified until `fos doctor --live` is run
  against the live marketplace.

## Audit

Every job transition, every LLM call, every marketplace action, every
ledger entry is persisted to SQLite (`./data/fos.db`, WAL mode).
Logs are JSON-lines with per-job correlation IDs. See `docs/RISK_REPORT.md`
for the quarterly review template.
