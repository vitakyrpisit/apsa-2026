# AI Disclosure — TaskBounty Compliance

TaskBounty Terms of Service require every submission to include an explicit
statement that the work was produced with the assistance of an AI coding
agent. This file is the canonical boilerplate we include in every PR body
and every delivery note, on every marketplace that requires it (or where
the buyer explicitly asks for it).

## Canonical disclosure text

```
This work was produced with the assistance of an AI coding agent
(ai-freelancer-os v1.0.0, LLM: GLM-5.1 via Z.ai Open API).

Method:
1. Reproduced the reported issue from a clean checkout.
2. Wrote a regression test capturing the buggy behaviour.
3. Implemented a minimal fix.
4. Ran the full pytest suite in an isolated Docker sandbox
   (--network none, --cap-drop ALL, non-root user).
5. An independent QA pass re-applied the patch to a fresh checkout at
   the base SHA and ran hidden validator tests plus deterministic
   anti-cheat checks (no deleted tests, no weakened assertions, no
   protected files touched, no secrets in diff). The QA verdict can
   only DOWNGRADE — never upgrade — the agent's self-assessment.
6. Opened this pull request with the patch, the regression test, and
   this disclosure.

No secrets, credentials, or private data were used or exfiltrated.
The agent never saw this PR's review feedback while working on it.
```

## When to include it

Always include on:
- TaskBounty (mandatory per ToS)
- BasedAgents (when task description asks for AI disclosure, or for any
  task where the buyer explicitly mentions AI assistance)
- Any marketplace task where the description mentions "AI disclosure",
  "machine-generated", or "produced with AI"

Optional but recommended on:
- AgentPact (default to including for transparency)
- Toku.agency (default to including)
- Mercatai (EU AI Act transparency — always include)

## Programmatic access

The exact text is available to the agent at runtime via:

```python
from freelancer_os.ai_disclosure import DISCLOSURE_TEXT
```

The CLI command `fos show <job_key>` also prints it as part of the
delivery metadata.

## Why this matters

Anthropic's published principle of **transparency** ("Building effective
agents") and the EU AI Act's Article 52 transparency obligation both
require that humans interacting with AI-generated outputs know that an
AI was involved. TaskBounty encodes this as a hard Terms-of-Service
requirement; non-compliance voids the bounty.

## Changelog

- 2026-10-08: initial version (v1.0.0). Method step wording reviewed
  against actual pipeline (`docs/ARCHITECTURE.md` §3).
