# Production Deployment Runbook

This runbook takes you from a fresh VPS to a live AI Freelancer OS
instance earning money on BasedAgents (and other marketplaces as they're
enabled).

**Pre-requisites**:
- A dedicated VPS (not shared, not your laptop). 2 vCPU, 4GB RAM, 40GB disk
  minimum. Ubuntu 24.04 LTS recommended.
- Operator's 4 payout wallets configured (see `WALLETS.md`).
- Z.ai API key with GLM Coding Plan ($18/mo) or pay-as-you-go credit.
- GitHub account with a private repo for `data/` backup (state + keypair).
- (Optional) Anthropic API key for independent QA (Anthropic Claude).

**Time budget**: 90 minutes end-to-end, including wallet confirmation transfer.

## Step 1 — Provision the VPS (15 min)

```bash
# On your local machine, after VPS provisioning:
ssh root@<vps-ip>

# Harden SSH: edit /etc/ssh/sshd_config:
#   PermitRootLogin no
#   PasswordAuthentication no
#   AllowUsers fos
# Then: systemctl restart sshd

# Create non-root user
adduser fos --disabled-password --gecos ""
usermod -aG sudo fos
mkdir -p /home/fos/.ssh
cp ~/.ssh/authorized_keys /home/fos/.ssh/
chown -R fos:fos /home/fos/.ssh
chmod 700 /home/fos/.ssh
chmod 600 /home/fos/.ssh/authorized_keys

# Install essential tooling
apt update && apt -y upgrade
apt -y install build-essential python3.12 python3.12-venv python3-pip \
    docker.io docker-compose-plugin git curl ufw fail2ban
systemctl enable --now docker
systemctl enable --now fail2ban

# Firewall: allow SSH (rate-limited), HTTPS out only
ufw default deny incoming
ufw default allow outgoing
ufw limit 22/tcp
ufw allow 8000/tcp   # FastAPI control plane (bind to localhost in production)
ufw enable

# Disable swap (Docker + SQLite work better without swap thrashing)
swapoff -a
sed -i '/ swap /d' /etc/fstab
```

## Step 2 — Clone the agent and install (10 min)

```bash
su - fos
cd ~
git clone https://github.com/<your-handle>/ai-freelancer-os.git
cd ai-freelancer-os

# Create venv and install
python3.12 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt   # pinned from pip-compile
pip install -e .

# Verify
fos --version    # should print 1.0.0
make test        # 108 tests, all green
make eval        # 16 golden scenarios, all green
```

## Step 3 — Configure secrets (10 min)

```bash
# Copy .env.example to .env and edit
cp .env.example .env
nano .env

# Required edits:
#   MODE=live
#   DRY_RUN=true        # start in shadow mode, flip to false after 3 successful jobs
#   ENABLED_MARKETPLACES=basedagents
#   LLM_PROVIDER=zai
#   LLM_MODEL=glm-5.1
#   ZAI_API_KEY=...     # from https://chat.z.ai → Settings → API Keys
#   QA_LLM_PROVIDER=anthropic   # different from coder, for independence
#   QA_LLM_MODEL=claude-sonnet-4
#   ANTHROPIC_API_KEY=...      # from https://console.anthropic.com
#   LLM_FALLBACK_CHAIN=zai:glm-5.1,zai:glm-4.6,zai:glm-4.5-flash,deterministic:degraded
#   WALLET_EVM=0x829f877daAb94D766BB2b8511ad486C40f2C2BDA
#   WALLET_SOLANA=EyTxSdVtku7QtbwgntLvUwyxMvraJyAxoPoZ8ALdG6qL
#   WALLET_TRON=TVVhpdHEg1ZgvPjJNSe2P28bhUDE4m85ZX
#   WALLET_BITCOIN=bc1qaedy7cmqujxlmkezlxlytkrecv0ufku970tk9c
#   WALLET_CONFIRMED_NETWORKS=   # leave EMPTY until step 4
#   FIRST_N_JOBS_REQUIRE_APPROVAL=3
#   MAX_LLM_COST_PER_JOB_USD=0.50
#   MAX_JOB_SPEND_USD=1.00
#   DAILY_SPEND_CAP_USD=5.00
#   CONTROL_API_TOKEN=...    # generate: python -c "import secrets; print(secrets.token_urlsafe(32))"

# Verify the env is loaded and wallets validate
fos doctor    # should pass with "missing: WALLET_CONFIRMED_NETWORKS"
fos wallets   # all 4 addresses pass strict per-chain validation
```

## Step 4 — Wallet confirmation transfer (10 min, requires your wallet app)

BasedAgents pays USDC on Base mainnet. Before going live, we PROVE the
operator wallet can receive Base USDC at the configured address.

```bash
# From your wallet app (MetaMask/Rabby/etc.), send 1 USDC on Base to:
#   0x829f877daAb94D766BB2b8511ad486C40f2C2BDA
#
# Wait 1-2 minutes (Base blocks are 2s).
# Verify on https://basescan.org/address/0x829f877daAb94D766BB2b8511ad486C40f2C2BDA
# that the 1 USDC arrived.
#
# Then update .env:
#   WALLET_CONFIRMED_NETWORKS=base
#
# Verify:
fos doctor    # should now report: "ready for LIVE"
```

**If the transfer does not arrive within 30 minutes**: stop. Your
configuring a custodial (exchange) wallet that doesn't support Base USDC.
Read `WALLETS.md` §1 carefully, contact your exchange, or switch to a
self-custody wallet (Rabby, MetaMask with a fresh HD account).

## Step 5 — Register the agent on BasedAgents (5 min)

```bash
# Register (this creates a permanent Ed25519 keypair at ./data/keys/basedagents.json)
fos register basedagents --manifest config/agent.manifest.json

# BACK UP THE KEYPAIR IMMEDIATELY:
cp ./data/keys/basedagents.json ~/basedagents-keypair-backup-$(date +%Y%m%d).json
chmod 600 ~/basedagents-keypair-backup-*.json

# Print the wallet-bind message
fos wallet-message --network eip155:8453 > /tmp/msg.txt
cat /tmp/msg.txt

# Sign the message with your wallet (MetaMask → Sign message / personal_sign)
# Copy the resulting 0x... signature.

# Bind the wallet
fos wallet-bind --message-file /tmp/msg.txt --signature 0x...
# → "wallet_verified: true" on the BasedAgents profile

# Verify on the public profile URL printed by `fos register`
```

## Step 6 — Pre-live eval (10 min)

```bash
# Run the golden scenarios against the real LLM
fos eval --llm

# Expected output:
#   16/16 scenarios
#   3 positive capability tasks: pass@1 = ?
#   13 adversarial controls: 13/13 passed
#
# IF pass@1 < 80% on positive tasks: STOP. Do not go live. Investigate
# whether GLM-5.1 is the right model for the task category, or whether
# the prompt needs refinement. See docs/EVALUATION.md.

# Run doctor against the live marketplace (read-only, no claims)
fos doctor --live
```

## Step 7 — Deploy as a service (10 min)

```bash
# Use the docker-compose stack (recommended)
cd deploy/docker
nano docker-compose.yml   # edit: mount /home/fos/ai-freelancer-os/data:/app/data
                          #       set env_file: /home/fos/ai-freelancer-os/.env
                          #       set user: "fos:fos"
cd ../..

docker compose -f deploy/docker/docker-compose.yml up -d

# Verify the FastAPI control plane is up
curl -s http://localhost:8000/health | jq
curl -s -H "Authorization: Bearer $CONTROL_API_TOKEN" \
     http://localhost:8000/v1/status | jq

# Tail logs (JSON lines)
docker compose -f deploy/docker/docker-compose.yml logs -f
```

## Step 8 — Run in DRY_RUN for a day (varies)

```bash
# The agent scans every 30 minutes by default. Watch the first scan:
docker compose -f deploy/docker/docker-compose.yml logs -f | jq

# You should see:
#   {"event": "scan_marketplace", "marketplace": "basedagents", ...}
#   {"event": "discover", "job_key": "...", ...}
#   {"event": "score_pre", "decision": "AWAITING_APPROVAL", ...}
#     (or "REJECT" if the task fails demand verification)

# After 24 hours of clean DRY_RUN operation:
#   1. Review fos pnl — should show 0 revenue, 0 cost, breaker closed
#   2. Review fos jobs — should show scanned + rejected/awaiting
#   3. Approve 1-2 small bounty tasks manually:
fos approve <job_key>
fos execute <job_key>
#   4. Watch the full pipeline: claim → code → sandbox → QA → PR → deliver → settle
#   5. When the first tx-verified settlement lands, flip DRY_RUN=false:
sed -i 's/DRY_RUN=true/DRY_RUN=false/' .env
docker compose -f deploy/docker/docker-compose.yml restart
```

## Step 9 — Continuous monitoring (ongoing)

```bash
# Prometheus metrics (scrape http://localhost:8000/v1/metrics)
#   fos_jobs_by_state{state="settled"} → should grow over time
#   fos_ledger_sum{kind="payment_in"} → revenue
#   fos_breaker_open → 0 (healthy), 1 (intervention required)
#   fos_llm_tier_used{tier="primary"} → should be 95%+ of calls
#   fos_llm_tier_used{tier="deterministic"} → should be 0

# Daily check (cron on your local machine):
ssh fos@<vps> 'cd ~/ai-freelancer-os && source .venv/bin/activate && fos pnl && fos breaker'

# Weekly: review the eval-weekly CI check-run on GitHub.
# Quarterly: fill in docs/risk-reports/YYYY-Qn.md per docs/RISK_REPORT.md template.
```

## Incident response

If `fos breaker` reports "open": see `docs/runbooks/incident-response.md`.

If `fos kill` is invoked (kill switch on): `fos resume` when ready.

If the keypair at `./data/keys/basedagents.json` is lost: **the agent is
orphaned permanently**. There is no recovery path for Ed25519 keypairs.
Restore from the backup made in step 5. If no backup: register a new
agent (different name), accept the loss of reputation on the old one.

## Backups

```bash
# Daily: push data/ to a private GitHub repo
cd ~/ai-freelancer-os
git -C data-state pull || git clone git@github.com:<your-handle>/fos-state.git data-state
rsync -a data/ data-state/
cd data-state
git add .
git commit -m "daily backup $(date +%Y%m%d)"
git push

# Weekly: download the keypair backup to local offline storage
scp fos@<vps>:~/basedagents-keypair-backup-*.json ~/offline-backups/
```

## Going further

- Add more marketplaces: see `docs/MARKETPLACES.md` for adapter-by-adapter
  instructions.
- Tune the opportunity engine: see `docs/ARCHITECTURE.md` §4 (EV formula,
  Thompson sampling, Wilson bound).
- Upgrade ASL: see `docs/SAFETY_LEVELS.md`.
