# Safety Levels (ASL) — AI Safety Levels Governance

This document defines our if-then commitments at each AI Safety Level,
following the structure of Anthropic's Responsible Scaling Policy (RSP) v3
([source](https://www.anthropic.com/news/responsible-scaling-policy-v3)).

## Why we publish this

The operator's mandate is unambiguous: **REAL CONFIRMED ASSETS RECEIVED by
operator wallets is the only KPI**. Reaching that KPI safely requires
explicit if-then commitments per capability level, so we cannot quietly
drift into operating beyond what we have proven we can do safely.

## Levels

### L0 — Pre-revenue (current)

Operational envelope:
- DRY_RUN mode by default. LIVE_SHADOW mode used for calibration. LIVE
  requires `WALLET_CONFIRMED_NETWORKS` populated and first-3-jobs human
  approval enabled.
- Single marketplace adapter enabled (BasedAgents). Other adapters in mock.
- LLM: GLM-5.1 via Z.ai Open API. Fallback chain armed but tier-4
  (deterministic degraded) returns "do not act" — pipeline aborts the job.
- No autonomous money movement. Wallet binding proof only (EIP-191
  personal_sign — moves no funds).
- Sandbox: Docker `--network none --cap-drop ALL --user non-root`.

If-then commitments:
- IF we observe a single sandbox escape attempt → escalate to L0+Lockdown,
  suspend all LIVE jobs, ASR (Autonomous Safety Review) within 24h.
- IF the circuit breaker opens (Wilson lower bound <0.30 over 20 jobs or
  30-day net P&L < −$15) → all subsequent jobs require human approval
  until breaker closes (8 consecutive successes).
- IF wallet confirmation transfer fails (sent $1 USDC on Base, didn't
  arrive after 30 min) → LIVE mode stays disabled, contact operator.

### L1 — Calibrated (target after 20 successful jobs)

Operational envelope:
- LIVE mode enabled on BasedAgents only. DRY_RUN still required for new
  marketplace adapters until each has 8 successful shadow runs.
- LLM fallback chain may upgrade to include Anthropic Claude as tier-2
  (independent QA provider per ADR 0002).
- Per-job LLM budget cap: $0.50. Daily cap: $5.00. 30-day net P&L floor: −$15.
- First-3-jobs-on-each-marketplace human approval required.

If-then commitments:
- IF first-3-jobs approval rate <67% on any marketplace → freeze that
  marketplace, ASR within 48h.
- IF 30-day net P&L < −$15 → automatic downgrade to L0.
- IF we observe a single fabricated test result (QA verdict bypassed) →
  immediate downgrade to L0+Lockdown, ASR within 24h.

### L2 — Multi-marketplace (target after 50 successful jobs + L1 stable 30 days)

Operational envelope:
- LIVE mode on BasedAgents + TaskBounty + AgentPact.
- Per-job LLM budget cap: $2.00. Daily cap: $20.00. 30-day floor: −$50.
- LLM-as-judge QA rubric mandatory on every job.
- Held-out eval set pass@1 ≥ 80% verified weekly in CI.

If-then commitments:
- IF held-out eval pass@1 drops below 75% on any weekly run → freeze new
  claims, ASR within 48h, root-cause published in `docs/RISK_REPORT.md`.
- IF 30-day net P&L < −$50 → automatic downgrade to L1.
- IF any payment_status transition shows ACCEPTED≠PAID conflation
  (reporting a bounty as paid when only accepted) → immediate downgrade
  to L0+Lockdown, ASR within 24h.

### L3 — Multi-modal autonomous (future, requires external audit)

Operational envelope:
- LIVE on all marketplaces the operator has cleared.
- Multi-modal agent (text + image + code). Subagent fan-out.
- Per-job budget: $5.00. Daily cap: $50.00. 30-day floor: −$150.

If-then commitments:
- External third-party audit of safety cases required before reaching L3.
- IF any sub-agent emits a tool call that wasn't in the manifest →
  immediate downgrade to L2, ASR within 24h.
- IF a single operator wallet receives funds from a source not in our
  whitelist (unexpected sender) → freeze, ASR within 24h, return funds
  if possible.

## How we measure which level we're at

`fos pnl` reports: jobs-completed, 30-day-net-pnl, breaker-open-status,
success-rate-per-marketplace. The level is computed by `scripts/compute-asl.py`
(not yet implemented) and reported by `fos doctor` and `/v1/metrics`.

## How we change levels

- **Upgrade**: requires ASR sign-off + 30-day stability window at the
  current level. Documented in `docs/RISK_REPORT.md` quarterly.
- **Downgrade**: automatic on trigger conditions above. No human in the
  loop required — that's the point.

## See also

- `SECURITY.md` — vulnerability disclosure and supply-chain
- `docs/adr/0002-fail-closed-independent-qa.md` — structural QA independence
- `docs/runbooks/incident-response.md` — what to do when something breaks
- `docs/RISK_REPORT.md` — quarterly risk report template
