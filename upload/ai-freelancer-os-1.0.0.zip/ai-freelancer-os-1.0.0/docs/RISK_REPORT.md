# Risk Report — Quarterly Template

This is the template for the quarterly risk report. Fill it in once per
quarter (or after any ASL downgrade trigger) and commit it to
`docs/risk-reports/YYYY-Qn.md`.

---

# Risk Report — <YYYY> Q<n>

**Author:** Operator
**Period:** <YYYY-MM-DD> to <YYYY-MM-DD>
**ASL at start:** <L0|L1|L2|L3>
**ASL at end:** <L0|L1|L2|L3>
**ASL changes during period:** <list any auto-downgrades or human upgrades>

## 1. Operational summary

| Metric | This quarter | Last quarter | Trend |
|---|---:|---:|---|
| Jobs scanned |   |   |   |
| Jobs claimed |   |   |   |
| Jobs delivered |   |   |   |
| Jobs accepted |   |   |   |
| Jobs paid (tx-verified) |   |   |   |
| Gross revenue (USDC) |   |   |   |
| LLM cost (USDC) |   |   |   |
| Sandbox cost (USDC) |   |   |   |
| Net revenue (USDC) |   |   |   |
| 30-day net P&L floor |   |   |   |
| Breaker opened (count) |   |   |   |
| Calibration Brier score |   |   |   |

## 2. Per-marketplace breakdown

For each enabled marketplace, list:
- Jobs claimed / accepted / paid
- Acceptance rate
- Average bounty (USDC)
- Average cost per job (USDC)
- Reputation change
- Notable incidents

## 3. LLM provider breakdown

For each tier in the fallback chain, list:
- Calls served
- Token usage (in/out)
- Cost (USDC)
- Failure rate (calls that cascaded to next tier)

## 4. Eval summary

- `make eval` (scripted oracle) pass rate: __%
- `make eval --llm` (real GLM-5.1) pass@1: __%
- Held-out set pass@1: __%
- Weekly CI eval jobs run: __
- Notable eval failures (with task IDs):

## 5. Safety incidents

For each incident during the quarter:
- Date
- ASL at the time
- Description
- Trigger (auto-downgrade? human escalation?)
- Root cause
- Mitigation
- Status (open/resolved)

If no incidents: state explicitly. Zero incidents is a valid and notable
result — it means our bounded-loss and bounded-trust controls worked.

## 6. Manual interventions

List every time the operator had to intervene (approve, reject, kill,
dispute, manually settle). For each:
- Date
- Job key
- Reason
- Outcome

## 7. Wallet audit

For each operator wallet:
- Address
- Networks used this quarter
- Total received (on-chain verified)
- Any unexpected senders?
- Any failed transfers (sent but not received)?

## 8. Residual risks (carried forward)

Risks that remain open at the end of the quarter:
- Risk description
- Likelihood
- Impact
- Mitigation plan
- Owner

## 9. ASL recommendation for next quarter

Based on the data above, should we:
- Stay at the current ASL?
- Upgrade? (requires 30-day stability + ASR sign-off)
- Downgrade? (if any trigger conditions met)

## 10. Sign-off

- Operator: _______________ Date: __________
- (Optional) External auditor: _______________ Date: __________
