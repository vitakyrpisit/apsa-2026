# ADR 0007 — LLM Fallback Chain

**Date**: 2026-10-08
**Status**: Accepted
**Anthropic principle referenced**: "Durable execution, resumable checkpoints, deterministic safeguards" — Anthropic Engineering, "Multi-agent research system" (https://www.anthropic.com/engineering/multi-agent-research-system)

## Context

In v1.0.0rc1, `llm/client.py` built exactly ONE LLM provider instance. If
that provider returned HTTP 5xx after 4 retries, or hit a network timeout,
the only path was `LLMError` → `CodingAgent.run()` catches →
`res.aborted_reason = "llm: ..."` → job ends FAILED.

For a commercial agent whose entire value proposition is "solves tasks
people pay for", every FAILED job is:
- A reputation hit on the marketplace (most marketplaces track success rate)
- A wasted LLM budget (we paid for the in-context tokens before the failure)
- A lost bounty (buyer sees the failure, may not re-list)
- A delayed operator KPI (real confirmed assets received)

The realistic failure modes for a single LLM provider are:
- Rate limit (HTTP 429) — even with Retry-After honor, can exhaust 4 attempts
- Outage (HTTP 5xx) — Z.ai has had multi-minute outages
- Network partition between VPS and provider
- API key rotated/revoked by operator

Each of these is recoverable by switching to another provider.

## Decision

Add a 4-tier fallback chain in `src/freelancer_os/llm/fallback.py`:

1. **Primary** — the operator's chosen flagship model (default: `glm-5.1`
   via Z.ai Open API). Highest quality. Pays per token.
2. **Secondary** — a lower-capability but still production-usable model
   from the same or a different provider (default: `glm-4.6` via Z.ai).
3. **Free tier** — a rate-limited free model (default: `glm-4.5-flash`).
   Used only as last resort before tier 4.
4. **Deterministic degraded** — NO LLM call. Returns a structured
   "degraded" response that the pipeline treats as ABORT, never as a
   fabricated answer.

The fallback triggers ONLY on these exceptions:
- `LLMError` (after all 4 inline retries in `_retrying_post` exhausted)
- `httpx.ConnectError`, `httpx.ReadTimeout`

The fallback does NOT trigger on:
- `BudgetExceeded` — we've spent too much on this job; cascading would
  only burn more budget. Abort the job, not the cascade.
- Any exception in tier 4 — tier 4 is the deterministic floor; it always
  returns a structured response, never raises.

## Consequences

**Positive**:
- Single-provider outages no longer block paid tasks.
- The chain is observable: `FallbackLLMClient.tier_usage()` exports how
  many calls each tier served, surfaced via `/v1/metrics`
  (`fos_llm_tier_used{tier="primary"}` should be 95%+ in healthy operation).
- The deterministic tier-4 ensures we never fabricate an answer when all
  LLM providers are down — per Anthropic's "ground truth" principle.

**Negative**:
- A single `complete()` call may now take longer in the worst case
  (primary fails after 4 retries + secondary fails after 4 retries +
  free tier fails after 4 retries + deterministic returns). In practice
  the inline retry budget is shared, so the worst case is ~30 seconds
  per call. Mitigated by per-call timeout in `httpx.AsyncClient`.
- Tier-2 model quality may be lower than tier-1, which can produce
  worse first-iteration code on a job. Mitigated by:
  (a) the independent QA pass (still fails closed), and
  (b) the LLM-as-judge rubric which catches quality regressions.

**Operator cost impact**: minimal. The fallback only fires on failures,
which are rare (~0.1% of calls in healthy operation). When it does fire,
the tier-2 / tier-3 calls are typically cheaper than tier-1 (GLM-4.6 is
cheaper than GLM-5.1; GLM-4.5-Flash is free).

## Implementation

- `src/freelancer_os/llm/fallback.py` — `FallbackLLMClient` class.
- `src/freelancer_os/llm/__init__.py` — export `FallbackLLMClient`.
- `src/freelancer_os/config.py` — `llm_fallback_chain: str` setting
  (CSV of `provider:model` pairs).
- `src/freelancer_os/llm/client.py` — `build_client_with_fallback()`
  factory.
- `tests/unit/test_fallback.py` — unit tests proving:
  - Primary success returns primary result.
  - Primary `LLMError` cascades to secondary.
  - All-live-tiers-fail returns tier-4 degraded.
  - `BudgetExceeded` does NOT cascade (re-raises immediately).

## Alternatives considered

**A. No fallback (status quo)**: rejected. Single-provider failure mode
is the #1 operational risk for a commercial agent.

**B. Retry with exponential backoff forever**: rejected. Unbounded
retries violate the "explicit stopping conditions" principle and would
hold a job open indefinitely.

**C. Synchronous provider switch (no tier-4)**: rejected. Without a
deterministic floor, an all-providers-down situation would raise an
exception that the pipeline would have to handle by fabricating a
fallback answer. Per Anthropic's ground truth principle, we never
fabricate.

## Cross-references

- `docs/ARCHITECTURE.md` §6 (LLM client architecture) — updated to
  describe the fallback chain.
- `docs/RUNTIME.md` — documents the `LLM_FALLBACK_CHAIN` env var.
- `docs/runbooks/production.md` — sets `LLM_FALLBACK_CHAIN` in step 3.
- ADR 0002 — independent QA: tier-2 fallback may use a DIFFERENT
  provider than primary (Anthropic for QA, Z.ai for coder), which
  strengthens independence.
