# AI Freelancer OS — `apsa-2026-bugfixer` v1.0.0

An autonomous agent that earns by completing **verifiable** Python bug-fix / small-feature tasks on paid-bounty marketplaces — and refuses everything it cannot prove with tests.

Real git → real Docker sandbox → LLM edit/test loop with 4-tier fallback → real tests → independent QA with hidden validator tests → real PR → tx-verified payment → learning.

> **Status, honestly.** 108 tests + 16 golden scenarios + 10 held-out tasks pass (`make test`, `make eval`). The pipeline, git, sandbox limits, QA, trust gate, treasury policy, wallet validation, request signing and marketplace API parsing are all verified against mocked servers. **Not yet proven** (no keys/network/Docker in the build environment): how well *your* model solves real tasks (`fos eval --llm`), live marketplace response shapes (`fos doctor --live`), the Docker sandbox on a real host (`fos doctor`), and income. There is no income guarantee; the system is designed to *lose little and learn fast*. Read `docs/MARKET_RESEARCH.md` for the realistic picture.

## Capabilities

- **Narrow, provable product**: only sells what tests can prove; says no to the rest (accuracy by scope).
- **Demand verification** before spending a cent (unfunded / testnet / referral / signature-trap / pay-to-enter / attestation-bait ⇒ rejected).
- **Unit-economics engine**: `EV = B·P(win)·P(success)·P(pay)·(1−f) − costs`, probabilities that learn from real outcomes, Thompson-sampling job choice, Wilson-bound circuit breaker.
- **Bounded loss**: daily/job caps, per-job LLM budget, kill switch, approval queue, breaker. **Bounded trust**: no spending keys, validated wallets, operator-confirmed networks.
- **Independent QA**: fresh checkout at base SHA, applies patch, runs validator-owned hidden tests + deterministic anti-cheat, then LLM reviewer can only DOWNGRADE (per ADR 0002).
- **4-tier LLM fallback chain** (GLM-5.1 → GLM-4.6 → GLM-4.5-Flash → deterministic-degraded). Single-provider outage never blocks a paid task. See ADR 0007.
- **Structured JSON logging** with per-job correlation IDs. Prometheus metrics endpoint.
- **Signed webhook receiver** for BasedAgents events (drops latency 30 min → seconds).
- **Held-out evaluation set** (10 tasks from real public Python issue patterns). Weekly CI eval with pass@1 ≥ 80% gate.
- **ASL governance ladder** (L0–L3) with if-then commitments per Anthropic RSP v3.
- **AI disclosure boilerplate** for marketplaces requiring transparency (TaskBounty, EU AI Act Art. 52).

## Quick start (free, no keys)
```bash
make install && . .venv/bin/activate
make test && make eval          # all green
fos init && fos wallets         # .env created; your 5 payout addresses are validated
fos doctor                      # lists exactly what is missing for live mode
```

## Go live (details: `docs/runbooks/production.md`)
1. **Wallets** (`docs/WALLETS.md` — read the ⚠ section first: custodial address / Base support / signature proof). Send $1 USDC on Base to confirm receipt before live mode.
2. `ZAI_API_KEY` (GLM Coding Plan $18/mo or pay-as-you-go; see `docs/RUNTIME.md` for why chat.z.ai is the console, not the host) → `fos eval --llm` ≥ 80 %.
3. `fos register basedagents` → `fos wallet-message` → sign with your wallet → `fos wallet-bind`.
4. Run: GitHub Actions (`.github/workflows/agent-run.yml`, free 24/7 cycle) or `docker compose -f deploy/docker/docker-compose.yml up -d` on a dedicated VPS.
5. `MODE=live DRY_RUN=true` for a day → then `DRY_RUN=false` with approvals on the first 3 jobs.

## Layout
```
src/freelancer_os/   marketplaces/ security/ opportunity/ agents/ sandbox/ vcs/ treasury/ storage/ api/ evals/ llm/ pipeline.py cli.py config.py logging.py ai_disclosure.py
tests/               unit/ e2e/
deploy/              docker/ marketplace/             # hardened Dockerfile + sandbox image
config/              agent.manifest.json             # operator's permanent agent identity
docs/                ARCHITECTURE MARKET_RESEARCH RUNTIME WALLETS MARKETPLACES EVALUATION AI_DISCLOSURE SAFETY_LEVELS RISK_REPORT adr/ runbooks/ history-audit-v0.1
scripts/             rainbow-deploy.sh
.github/workflows/   ci.yml agent-run.yml eval-weekly.yml
requirements.txt     pinned via pip-compile (Makefile: make lock)
```

## Data & privacy

This agent processes:
- **Public marketplace data** (task descriptions, repository contents of public GitHub repos, public agent profiles). All third-party text is treated as untrusted — see `SECURITY.md` and `src/freelancer_os/security/`.
- **Operator's wallet addresses** (public receive-only addresses only — never private keys or seed phrases).
- **Agent's Ed25519 keypair** (stored at `./data/keys/basedagents.json`, mode 0600, .gitignored). This IS the agent identity — back up to offline storage. Without it, the agent is orphaned permanently.
- **Pipeline state** (SQLite at `./data/fos.db` — jobs, events, ledger, outcomes). WAL mode, single-process.
- **Per-job artifacts** (LLM transcript with secrets redacted, QA report, patch diff) under `./data/artifacts/{job_key}/`. Retained 90 days, then pruned.
- **Prometheus metrics** (scraped at `/v1/metrics`) — aggregate counters only, no PII.

We do NOT:
- Send your wallet private key, seed phrase, or API tokens to the agent, this repo, chat.z.ai, or anyone.
- Train models on your transcripts.
- Collect analytics or telemetry beyond what's in `/v1/metrics`.
- Make outbound network calls except to: configured LLM provider, configured marketplaces, GitHub (for git/PR operations), and on-chain RPC nodes (read-only, for payment verification).

## Privacy safeguards

- **Capability limits** are the real defence: Docker sandbox `--network none --cap-drop ALL`, no shell in agent tools, no env access in sandbox, path-jailed workspace (no `.git`, no `.env`, no `*.pem`, `*.key`, `*secret*`).
- **Two-layer prompt-injection defence**: regex firewall (fast, free) + LLM-based second classifier on every untrusted channel (catches novel patterns). See `src/freelancer_os/security/`.
- **Independent QA** (ADR 0002): the QA reviewer never sees the coder's reasoning, re-creates a clean checkout at base SHA, runs validator-owned hidden tests + deterministic anti-cheat. LLM reviewer can only DOWNGRADE.
- **Bounded trust**: no spending keys, validated wallets, operator-confirmed networks, demand-verification gate, payment-status requires real tx hash (never just a status string).
- **Audit logs**: every job transition, every LLM call, every marketplace action, every ledger entry is persisted to SQLite with a job_key correlation ID. Logs are JSON-lines with the same correlation.

## Terms, privacy, disclosure

By deploying this agent you agree to:
- **Terms of Service** of every marketplace you enable (BasedAgents, TaskBounty, AgentPact, Toku, Mercatai, BountyBook, Agent Souk — read each platform's ToS before enabling).
- **AI disclosure** in every PR body and delivery note (see `docs/AI_DISCLOSURE.md`).
- **Operator responsibility** for the agent's actions on your behalf. The agent is bounded; you are the merchant of record.
- **No warranty**. The software is provided "as is" without warranty of any kind. See `LICENSE` (Apache 2.0).

## Commercial terms

This software is Apache-2.0 licensed (see `LICENSE`). The hosted console at https://chat.z.ai is operated by Zhipu AI and is subject to their terms; this project is independent of Zhipu AI.

The APSA-2026 SentinelShield lineage (this agent's `framework`) is operated by the operator at `valykirpisit@gmail.com`. Payouts go to the operator's receive-only wallets configured in `.env`.

## What makes it commercially viable
* **Narrow, provable product**: it only sells what tests can prove; it says no to the rest (accuracy by scope).
* **Demand verification** before spending a cent.
* **Unit-economics engine** with learnable probabilities, Thompson sampling, Wilson-bound breaker.
* **Bounded loss + bounded trust** by design.
* **Anthropic-aligned**: workflow-first, ground truth every step, structural QA independence, bounded budgets, transparent logs, eval-driven development.

## Documentation
- `docs/ARCHITECTURE.md` — full pipeline + module map
- `docs/SAFETY_LEVELS.md` — ASL L0–L3 if-then commitments
- `docs/RISK_REPORT.md` — quarterly risk report template
- `docs/runbooks/production.md` — VPS → live in 90 minutes
- `docs/adr/` — 7 ADRs documenting every architectural decision
- `docs/history-audit-v0.1.md` — what we fixed from v0.1

Commands: `fos init|doctor|wallets|register|wallet-message|wallet-bind|scan|run-once|worker|jobs|show|approve|reject|execute|settle|pnl|breaker|score|eval|kill|resume|serve`.

## Community
- File issues on GitHub for bugs and feature requests.
- Security disclosures: see `SECURITY.md` for coordinated vulnerability disclosure.
- Contributions: see `CONTRIBUTING.md` (self-certification checklist required for security/treasury/sandbox changes).

## Changelog
See `CHANGELOG.md` (Keep a Changelog format).
