# Changelog

All notable changes to this project are documented in this file.
The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] — 2026-10-08

### Added — Commercial launch
- **LLM fallback chain** (`llm/fallback.py`): 4-tier provider cascade
  (primary → secondary → flash-free → deterministic-degraded). Zero single-provider
  failure mode. Documented in `docs/adr/0007-llm-fallback.md`.
- **Structured logging** (`logging.py`): JSON formatter with per-job correlation IDs
  (`job.key` propagated through every log line). Replaces ad-hoc `print()`.
- **Prometheus metrics endpoint** (`/v1/metrics`): jobs-by-state, ledger sums,
  breaker status, calibration Brier score, fallback-tier counters.
- **Signed webhook receiver** (`/v1/webhooks/basedagents`): accepts
  `task.created`/`task.funded`/`payment.settled` events, verifies AgentSig,
  triggers immediate marketplace scan (30-min latency → seconds).
- **Held-out evaluation set** (`evals/held_out.py`): 10 tasks from real public
  GitHub issues, regression-gated in CI. Pass@1 ≥ 80% gate enforced.
- **LLM-as-judge QA rubric** (`agents/qa_agent.py`): 0.0–1.0 score across
  factual / completeness / scope / test-quality dimensions, persisted to `qa.json`.
  Judge can only DOWNGRADE per ADR 0002.
- **ASL governance ladder** (`docs/SAFETY_LEVELS.md`): L0–L3 if-then commitments
  per Anthropic RSP v3.
- **Quarterly Risk Report template** (`docs/RISK_REPORT.md`).
- **Production deployment runbook** (`docs/runbooks/production.md`).
- **Rainbow deployment script** (`scripts/rainbow-deploy.sh`): two-version
  concurrent operation for zero-downtime model swaps.
- **Secrets scanning in CI** (`.github/workflows/ci.yml`): `trufflehog` step on
  every push and pull request.
- **Weekly real-LLM eval** (`.github/workflows/eval-weekly.yml`): Sunday 00:00 UTC
  against configured Z.ai key, posts pass@1 + cost-per-task as check-run.
- **AI disclosure boilerplate** (`docs/AI_DISCLOSURE.md`): satisfies TaskBounty
  Terms requiring explicit "produced with assistance of AI coding agent" text
  in every PR body and delivery.
- **LIVE_SHADOW mode** (`config.py`): calibration middle-ground between
  DRY_RUN and LIVE — runs the full pipeline including LLM calls and sandbox,
  but never claims/delivers/settles. Generates a synthetic shadow-settlement
  for offline P&L verification without spending real money.

### Changed
- **BasedAgents fee rate** corrected from `0.10` to `0.00` (actual: 0%, full
  bounty to agent). `fee_verified=True`.
- **`config/agent.manifest.json`**: placeholder `"your-unique-agent-name"`
  replaced with the operator's permanent agent identity (`apsa-2026-bugfixer`).
- **`CODEOWNERS`**: placeholder `@owner` replaced with operator's GitHub handle.
- **TaskBounty adapter** rewritten to current REST API
  (`GET/POST /api/v1/tasks[/access|/submissions]`, `tb_live_*` keys).
- **`WALLETS.md`**: added Arbitrum memo guidance (`578354` is a deposit memo,
  not part of the address; same EVM address used for ETH/ARB/Base).
- **`sandbox/runner.py`**: tool output cap reduced from 200K chars to 25K tokens
  (Anthropic default for high-signal context-efficient tool returns).
- **`requirements.txt`**: pinned dependencies via `pip-compile`.
- **`Dockerfile`**: switched to `pip install --no-cache-dir -r requirements.txt`.
- **`README.md`**: rewritten Anthropic-style with Data & Privacy section,
  Privacy Safeguards section, ToS/Privacy/Disclosure/Usage/Commercial Terms links.

### Security
- Coordinated Vulnerability Disclosure policy added to `SECURITY.md`.
- PGP contact key fingerprint published.
- Supply-chain: SBOM generated on release; SLSA provenance level 2 target.
- LLM-based second prompt-injection classifier on every untrusted channel
  (`security/llm_classifier.py`).

### Fixed
- v0.1 regression: firewall regex backslash escaping (now covered by
  static check in CI — `test_regression_v01_patterns_actually_match`).
- LLM `reasoning_content` was silently ignored — now logged for observability
  but still not used in completion text (deliberate, per `docs/RUNTIME.md`).

## [1.0.0rc1] — 2026-10-07
- Z.ai (GLM) / OpenAI-compatible provider; wallet validation (EIP-55,
  base58check, bech32) with per-network confirmation; BasedAgents wallet-bind flow.
- Demand-verification gate, P(pay) learning, saturation model, Thompson-sampling
  job ranking, Wilson-bound circuit breaker, payment timeouts.
- Agent: persistent notes, stuck-detection, run metrics. 16 golden scenarios
  (13 adversarial). 108 tests.
- Repo restructured (`src/` layout, `deploy/`, `config/`, ADRs, runbooks, CI,
  scheduled GitHub Actions runtime).

## [0.3.0]
- Real runtime replacing the v0.1 simulator (see `docs/history-audit-v0.1.md`).
