# Источники и интерпретация

Дата проверки ссылок: 2026-10-09. Документы моделей и API меняются; перед внедрением повторно проверяйте актуальные версии.

## OpenAI GPT-6 Astra
1. Deployment Safety Hub / GPT-6 Astra System Card, включая appendix Sol/Luna: https://deploymentsafety.openai.com/gpt-6-astra/sec%3Aappendix-sol-luna
2. Safety overview: https://openai.com/index/safety-overview-gpt-6-astra/
3. Описание модели: https://openai.com/index/gpt-6-astra/

**Интерпретация:** материалы описывают оценки, ограничения, мониторинг, устойчивость к prompt injection, контроль разрешённой области действий и safeguards для модели и её развёртывания. Это не готовая универсальная спецификация для любого стороннего агента. Отсутствие наблюдаемого сбоя в тесте не доказывает абсолютную надёжность; мониторинг только chain-of-thought недостаточен.

## ARC-AGI / ARC Prize Foundation
4. ARC-AGI series: https://arcprize.org/arc-agi
5. ARC-AGI-2 technical report: https://arcprize.org/blog/arc-agi-2-technical-report

**Интерпретация:** используем акцент на приобретении навыка для новых задач и на измерении обобщения. Конкретные эвристики о типизированных объектах, цикле гипотез и OOD-тестах в этом пакете — инженерная адаптация, а не дословная архитектурная рекомендация ARC Prize. Не утверждаем, что высокий результат на ARC-AGI автоматически означает безопасный агент или AGI.

## Другие платформы и инженерные практики
6. Anthropic, System prompts overview: https://platform.claude.com/docs/en/release-notes/system-prompts/overview
7. Anthropic, Prompting best practices: https://docs.anthropic.com/en/docs/build-with-claude/prompt-engineering/prompt-templates-and-variables
8. Google Gemini API, Safety and factuality guidance: https://ai.google.dev/gemini-api/docs/safety-guidance
9. Google Gemini API, Function calling: https://ai.google.dev/gemini-api/docs/function-calling
10. Google Gemini API, Agents overview: https://ai.google.dev/gemini-api/docs/agents
11. Google Gemini API, Agent hooks: https://ai.google.dev/gemini-api/docs/agent-hooks
12. Google Gemini API, Computer use: https://ai.google.dev/gemini-api/docs/computer-use.md

Эти материалы поддерживают общие практики: оценка рисков конкретного приложения, ручная проверка, строгие схемы вызовов, контролируемое выполнение инструментов, sandbox и guardrails. Это не сравнительный аудит качества всех платформ и не утверждение, что перечисленные функции доступны в каждом пользовательском чате.

## Принципы, синтезированные в этом пакете
- authorized scope, least privilege, внешние эффекты под подтверждением;
- недоверенные данные изолируются от инструкций;
- policy gate по возможности исполняется вне LLM;
- наблюдаемость строится на действиях и результатах, а не только на CoT;
- тесты включают jailbreak/prompt injection, сбои, edge cases и OOD;
- релиз — только после проверяемых критериев, staged rollout и плана отката.

Не включайте в документы проекта закрытые системные промпты сторонних моделей, не пытайтесь обходить платформенные правила и не выдавайте пользовательский протокол за официальный стандарт OpenAI, ARC Prize, Anthropic, Google, xAI или Z.ai.
