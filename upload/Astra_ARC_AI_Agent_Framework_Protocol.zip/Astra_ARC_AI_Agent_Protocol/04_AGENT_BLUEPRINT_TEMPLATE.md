# ШАБЛОН АРХИТЕКТУРЫ ИИ-АГЕНТА: ASTRA-LUNA & ARC-AGI
## Производственный каркас спецификации агента

### 1. Паспорт агента (Specification Header)
- **Название агента**: `[Agent Identifier]`
- **Класс критичности (Safety Tier)**: `Tier 1 (Read-Only) / Tier 2 (Internal Mutation) / Tier 3 (External Financial/High-Impact)`
- **Основной фреймворк реализации**: `Python (PydanticAI / LangGraph) | TypeScript / Node.js`
- **Целевые модели**: Sol (рассуждения) + Luna (валидация безопасности)

---

### 2. ARC-AGI Модель предметной области
1. **Априорные сущности (Entities & Objects)**:
   - Перечисление ключевых структур данных и их неизменяемых свойств.
2. **Целевые состояния и инварианты (Invariants)**:
   - Условия, которые ДОЛЖНЫ быть истинными до и после любого шага агента.
3. **Граф переходов (State Machine)**:
   - Начальное состояние -> Генерация гипотезы -> Верификация Luna -> Исполнение действия -> Проверка прогресса -> Завершение.

---

### 3. Спецификация инструментов (Tooling Sandbox Matrix)
```yaml
tools:
  - name: read_resource
    description: Безопасное чтение данных
    risk_level: LOW
    luna_policy: AUTO_APPROVE_WITH_SANITATION
  - name: mutate_resource
    description: Создание или обновление записи
    risk_level: MEDIUM
    luna_policy: REQUIRE_IDEMPOTENCY_AND_SCHEMA_CHECK
  - name: execute_system_command
    description: Исполнение команды в песочнице
    risk_level: HIGH
    luna_policy: ALLOWLIST_ONLY_AND_ASTRA_SANDBOX
```

---

### 4. Референсный код ядра Sol & Luna (TypeScript / Python)
```python
from typing import Dict, Any, Optional
from pydantic import BaseModel, Field

class ActionProposal(BaseModel):
    tool: str
    args: Dict[str, Any]
    rationale: str
    arc_hypothesis: str

class LunaVerdict(BaseModel):
    approved: bool
    risk_score: float
    violations: list[str] = []
    feedback_for_sol: Optional[str] = None

class AstraAgentEngine:
    def __init__(self, sol_model, luna_model, tools_sandbox):
        self.sol = sol_model
        self.luna = luna_model
        self.sandbox = tools_sandbox

    async def execute_step(self, context: dict) -> dict:
        # Шаг 1: Sol формулирует гипотезу и действие по канонам ARC-AGI
        proposal: ActionProposal = await self.sol.propose_action(context)
        
        # Шаг 2: Luna независимо анализирует безопасность действия
        verdict: LunaVerdict = await self.luna.audit_action(proposal, context)
        
        # Шаг 3: Проверка консенсуса
        if not verdict.approved:
            # Возврат ошибки в Sol для синтеза новой гипотезы
            return await self.handle_refinement(proposal, verdict, context)
            
        # Шаг 4: Безопасное исполнение в песочнице
        result = await self.sandbox.execute(proposal.tool, proposal.args)
        return {"status": "SUCCESS", "result": result}
```
