# ASTRA-LUNA & ARC-AGI AGENT PROTOCOL SUITE
Grounding:
- OpenAI GPT-6 Astra Safety Overview & Appendix Sol & Luna
- ARC Prize Foundation / ARC-AGI Cognitive Foundations (François Chollet)

## Содержимое архива:
1. 00_SYSTEM_PROMPT_PROTOCOL.md - Универсальный мастер-промпт для любого ИИ-чата
2. 01_SOL_LUNA_DUAL_CORE_ARCHITECTURE.md - Двухъядерная архитектура Sol-Luna
3. 02_ARC_AGI_COGNITIVE_FOUNDATIONS.md - Принципы мышления ARC-AGI
4. 03_DEPLOYMENT_SAFETY_REDTEAMING.md - Стандарты безопасности развертывания
5. 04_AGENT_BLUEPRINT_TEMPLATE.md - Производственный шаблон спецификации агента
6. 05_INSTRUCTIONS_FOR_AI_PLATFORMS.md - Инструкция по загрузке в Claude, ChatGPT, Gemini, Grok, Chat.z.ai
7. 06_REFERENCE_EXAMPLES.md - Готовые примеры агентов

## Как использовать:
1. Загрузите файл 00_SYSTEM_PROMPT_PROTOCOL.md или весь архив в чат вашего ИИ (Claude, ChatGPT, Gemini, Grok, Chat.z.ai).
2. ИИ ответит стандартизированным подтверждением готовности и спросит:
   "Какого ИИ-агента мы будем разрабатывать? Пожалуйста, предоставьте техническое задание (ТЗ)..."
3. Отправьте ТЗ на разработку агента.
4. ИИ приступит к проектированию и созданию агента строго по правилам Sol-Luna, Astra Safety и ARC-AGI.
