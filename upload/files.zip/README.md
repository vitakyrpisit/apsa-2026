# APSA patch v2 — SentinelShield correctness fix

Files (paths relative to repo root, replace existing):
- production_server.ts            (based on main @ 7730b63; keeps the absolute-URL fix)
- src/services/sentinelShieldCore.ts
- src/types/x402.ts               (metrics fields may be null = "not evaluated"; version 2.1.0)
- test/sentinel.test.ts           (12 checks; run: npx tsx test/sentinel.test.ts)

What changed
1. Missing `await` removed: the paid response used to contain only the payment block, no analysis.
2. Bytecode is now scanned opcode-by-opcode (PUSH data and Solidity metadata skipped) instead of
   searching the hex text for "f4"/"ff", which matched almost every contract and produced false HIGH results.
3. Metrics that cannot be known from bytecode are null instead of hard-coded "false" (which implied safety).
4. Input is validated BEFORE any payment is verified or settled; analysis runs BEFORE settle, so a failed
   analysis (bad address, no code, RPC error) never charges the buyer. Errors return { charged:false }.
5. Summary states plainly that only bytecode was analysed and what was NOT evaluated.
