import { scanBytecode, validateSentinelInput, SentinelInputError } from '../src/services/sentinelShieldCore';

let failed = 0;
function eq(name: string, got: unknown, want: unknown) {
  const ok = JSON.stringify(got) === JSON.stringify(want);
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${ok ? '' : `  got=${JSON.stringify(got)} want=${JSON.stringify(want)}`}`);
  if (!ok) failed++;
}

// 1. 'f4'/'ff' appear only as PUSH2 data -> the old substring check flagged this; opcode walk must not.
let s = scanBytecode('0x61f4ff00');
eq('push-data f4ff is not DELEGATECALL/SELFDESTRUCT', [s.hasDelegatecall, s.hasSelfdestruct], [false, false]);

// 2. real DELEGATECALL: PUSH1 0 x4, PUSH20 addr, GAS, DELEGATECALL, STOP
const addr = '11'.repeat(20);
s = scanBytecode('0x6000600060006000' + '73' + addr + '5a' + 'f4' + '00');
eq('real DELEGATECALL detected', s.hasDelegatecall, true);

// 3. real SELFDESTRUCT: PUSH1 0, SELFDESTRUCT
s = scanBytecode('0x6000ff');
eq('real SELFDESTRUCT detected', s.hasSelfdestruct, true);

// 4. metadata trailer must be skipped (contains f4 and ff bytes, length 0x29)
const cbor = 'a165627a7a72305820' + 'f4ff'.repeat(16);
s = scanBytecode('0x00fe' + cbor + '0029');
eq('metadata trailer skipped', [s.hasDelegatecall, s.hasSelfdestruct, s.metadataTrailerBytes > 0], [false, false, true]);

// 5. EIP-1167 minimal proxy
s = scanBytecode('0x363d3d373d3d3d363d73' + addr + '5af43d82803e903d91602b57fd5bf3');
eq('EIP-1167 detected', [s.minimalProxy, s.hasDelegatecall], [true, true]);

// 6. EIP-1967 slot via PUSH32
s = scanBytecode('0x7f360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc54f400');
eq('EIP-1967 slot + delegatecall', [s.eip1967Slot, s.hasDelegatecall], [true, true]);

// 7. tx.origin
s = scanBytecode('0x3200');
eq('ORIGIN detected', s.hasOrigin, true);

// 8. input validation
function throws(name: string, f: () => void, status?: number) {
  try { f(); eq(name, 'no throw', 'throw'); } catch (e: any) {
    eq(name, e instanceof SentinelInputError && (status === undefined || e.status === status), true);
  }
}
throws('empty body rejected', () => validateSentinelInput({} as any), 400);
throws('bad address rejected', () => validateSentinelInput({ contractAddress: '0x123' }), 400);
throws('odd hex rejected', () => validateSentinelInput({ bytecode: '0x123' }), 400);
throws('non-base chain rejected', () => validateSentinelInput({ chain: 'ethereum', bytecode: '0x00' }), 400);
validateSentinelInput({ bytecode: '0x6000ff' });
validateSentinelInput({ contractAddress: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913' });
eq('valid inputs accepted', true, true);

console.log(failed === 0 ? '\nALL PASSED' : `\n${failed} FAILED`);
process.exit(failed === 0 ? 0 : 1);
