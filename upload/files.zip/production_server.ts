import 'dotenv/config';
import express from 'express';
import { x402ResourceServer } from '@x402/core/server';
import { ExactEvmScheme } from '@x402/evm/exact/server';
import { HTTPFacilitatorClient } from '@x402/core/server';
import { analyzeContractRisk, validateSentinelInput, SentinelInputError } from './src/services/sentinelShieldCore';
import { verifySettlementEvidence, PRODUCTION_PAY_TO, BASE_USDC_MAINNET, SENTINEL_PRICE_ATOMIC, SENTINEL_PRICE_USDC, BASE_MAINNET_CHAIN_ID } from './src/services/x402Facilitator';

const PORT = Number(process.env.PORT ?? 8080);
// Render sets RENDER_EXTERNAL_URL automatically; APP_URL overrides it if provided.
const APP_URL = (process.env.APP_URL || process.env.RENDER_EXTERNAL_URL || '').replace(/\/+$/, '');
const NETWORK = 'eip155:8453';

const FACILITATOR_URL = process.env.FACILITATOR_URL || 'https://facilitator.xpay.sh';
const facilitator = new HTTPFacilitatorClient({ url: FACILITATOR_URL });
const resourceServer = new x402ResourceServer(facilitator);
resourceServer.register(NETWORK, new ExactEvmScheme());

const paymentRequirements = {
  scheme: 'exact' as const,
  network: NETWORK,
  amount: SENTINEL_PRICE_ATOMIC,
  payTo: PRODUCTION_PAY_TO,
  asset: BASE_USDC_MAINNET,
  maxTimeoutSeconds: 3600,
  extra: { name: 'USD Coin', version: '2' },
};

const CANARY_PRICE_USDC = 0.10;
const CANARY_PRICE_ATOMIC = '100000';

function makePaymentRequirements(amount: string) {
  return { ...paymentRequirements, amount };
}

const paymentRequired = (route = '/sentinelshield', amount = SENTINEL_PRICE_ATOMIC, description = 'SentinelShield automated deterministic smart-contract risk triage and SARIF report; not a full security audit.') => ({
  x402Version: 2,
  resource: {
    url: APP_URL ? `${APP_URL}${route}` : route,
    description,
    mimeType: 'application/json',
  },
  accepts: [makePaymentRequirements(amount)],
  extensions: {
    bazaar: {
      info: {
        input: { type: 'http', method: 'POST' },
        output: { example: { riskLevel: 'LOW', overallScore: 82, summary: 'Deterministic contract triage completed.' } },
      },
      schema: {
        input: {
          type: 'object',
          properties: {
            contractAddress: { type: 'string' },
            chain: { type: 'string' },
            bytecode: { type: 'string' },
            sourceCode: { type: 'string' },
          },
        },
      },
    },
  },
});

function encodePaymentRequired(value: unknown) {
  return Buffer.from(JSON.stringify(value)).toString('base64');
}

function decodePaymentHeader(value: string | undefined) {
  if (!value) return null;
  try {
    return JSON.parse(Buffer.from(value, 'base64').toString('utf8'));
  } catch {
    return null;
  }
}

const app = express();
app.use(express.json({ limit: '5mb' }));

app.get('/health', (_req, res) => res.json({
  status: 'ok',
  mode: 'production-http-facilitator',
  facilitator: FACILITATOR_URL,
  protocol: 'x402-v2',
  network: NETWORK,
  asset: BASE_USDC_MAINNET,
  amountUSDC: SENTINEL_PRICE_USDC,
  payTo: PRODUCTION_PAY_TO,
}));

function baseUrl(req: express.Request) {
  if (APP_URL) return APP_URL;
  const proto = (req.header('x-forwarded-proto') ?? req.protocol).split(',')[0].trim();
  const host = (req.header('x-forwarded-host') ?? req.header('host') ?? '').split(',')[0].trim();
  return host ? `${proto}://${host}` : '';
}

function withAbsoluteUrl(req: express.Request, body: ReturnType<typeof paymentRequired>) {
  const b = baseUrl(req);
  if (!b || /^https?:\/\//.test(body.resource.url)) return body;
  return { ...body, resource: { ...body.resource, url: `${b}${body.resource.url}` } };
}

app.get('/.well-known/x402-manifest.json', (req, res) => res.json(withAbsoluteUrl(req, paymentRequired())));

app.get('/.well-known/x402', (req, res) => res.json(withAbsoluteUrl(req, paymentRequired())));

async function handlePaidSentinel(req: express.Request, res: express.Response, route: string, amountAtomic: string) {
  const required = withAbsoluteUrl(req, paymentRequired(route, amountAtomic, route === '/sentinelshield-canary'
    ? 'SentinelShield canary: deterministic smart-contract risk triage sample for marketplace verification; not a full security audit.'
    : 'SentinelShield automated deterministic smart-contract risk triage and SARIF report; not a full security audit.'));
  const requirements = makePaymentRequirements(amountAtomic);
  const signatureHeader = (req.header('PAYMENT-SIGNATURE') ?? req.header('X-PAYMENT'));

  if (!signatureHeader) {
    const encoded = encodePaymentRequired(required);
    res.setHeader('PAYMENT-REQUIRED', encoded);
    res.setHeader('payment-required', encoded);
    return res.status(402).json(required);
  }

  const paymentPayload = decodePaymentHeader(signatureHeader);
  if (!paymentPayload) return res.status(400).json({ error: 'Malformed PAYMENT-SIGNATURE header.' });

  // Reject bad input BEFORE any money moves, so a buyer is never charged for a request we cannot serve.
  try {
    validateSentinelInput((req.body ?? {}) as any);
  } catch (e: any) {
    const status = e instanceof SentinelInputError ? e.status : 400;
    return res.status(status).json({ error: e?.message ?? 'Invalid request', charged: false });
  }

  try {
    const verification = await facilitator.verify({ paymentPayload, paymentRequirements: requirements });
    if (!verification.isValid) {
      return res.status(402).json({ error: 'Payment verification failed', reason: verification.invalidReason ?? 'invalid_payment' });
    }

    // Do the work first: if it fails, the payment is never settled and the buyer is not charged.
    let result;
    try {
      result = await analyzeContractRisk((req.body ?? {}) as any);
    } catch (e: any) {
      const status = e instanceof SentinelInputError ? e.status : 502;
      return res.status(status).json({ error: e?.message ?? 'Analysis failed', charged: false });
    }

    const settlement = await facilitator.settle({ paymentPayload, paymentRequirements: requirements });
    if (!settlement.success) {
      return res.status(402).json({ error: 'Payment settlement failed', reason: settlement.errorReason ?? 'settlement_failed' });
    }

    const txHash = settlement.transaction;
    if (!txHash) return res.status(502).json({ error: 'Facilitator settled without a transaction hash.' });

    const payer = paymentPayload?.payload?.authorization?.from ?? verification.payer ?? '';
    const evidence = await verifySettlementEvidence(txHash, payer, PRODUCTION_PAY_TO, BigInt(amountAtomic));
    if (!evidence.verified) {
      return res.status(502).json({ error: 'Settlement evidence failed', evidence });
    }

    return res.status(200).json({
      ...result,
      payment: {
        settled: true,
        verifiedOnChain: true,
        txHash,
        payer,
        payTo: PRODUCTION_PAY_TO,
        amountUSDC: evidence.amountUSDC,
        blockNumber: evidence.blockNumber,
        network: NETWORK,
      },
    });
  } catch (error: any) {
    console.error('[x402 production]', error);
    return res.status(502).json({ error: 'Production x402 upstream failure', reason: error?.message ?? String(error) });
  }
}

app.post('/sentinelshield', async (req, res) => handlePaidSentinel(req, res, '/sentinelshield', SENTINEL_PRICE_ATOMIC));

// Low-price external marketplace canary. This does NOT replace the $0.49 product.
app.post('/sentinelshield-canary', async (req, res) => handlePaidSentinel(req, res, '/sentinelshield-canary', CANARY_PRICE_ATOMIC));

app.get('/api/onchain/status', async (_req, res) => {
  try {
    const { fetchLiveOnChainStatus } = await import('./src/services/baseRpc');
    res.json(await fetchLiveOnChainStatus(PRODUCTION_PAY_TO, 'base-mainnet'));
  } catch (error: any) {
    res.status(502).json({ error: error?.message ?? String(error) });
  }
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`[APSA] production x402 server listening on :${PORT}`);
  console.log(`[APSA] payTo=${PRODUCTION_PAY_TO}`);
  console.log(`[APSA] Base USDC=${BASE_USDC_MAINNET}`);
  console.log(`[APSA] facilitator=${FACILITATOR_URL}`);
});
