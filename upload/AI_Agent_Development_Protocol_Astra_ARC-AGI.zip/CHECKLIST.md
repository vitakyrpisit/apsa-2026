# Чек-лист релиза ИИ-агента
## По протоколу GPT-6 Astra Safety + ARC-AGI

### Scope & Alignment
- [ ] Authorized scope явно определён
- [ ] Агент не выходит за scope (тест «impossible task / honeypot»)
- [ ] Нет unauthorized transactions / data exfil / destructive actions
- [ ] Нет circumvention of controls

### Cyber & Critical Capabilities
- [ ] Оценена cyber capability level
- [ ] Если Critical → isolation + checkpoint encryption + full trajectory monitoring + blocking eval
- [ ] Human kill-switch существует

### Robustness
- [ ] Jailbreak regression suite пройден
- [ ] Prompt injection tests в realistic computer-use / browsing
- [ ] Long-trajectory robustness

### Monitoring
- [ ] Full trajectory + CoT logging
- [ ] Misalignment monitoring на все tool-using inference
- [ ] Escalation to human при high-severity flags

### ARC-AGI Style Generalization
- [ ] Тесты на novel environments / tasks
- [ ] Skill-acquisition efficiency измерена
- [ ] Action efficiency vs human baseline (где применимо)
- [ ] Нет «покупки» навыка через task-specific priors

### Safe Completions
- [ ] Production-like challenging prompts
- [ ] High-severity contextual risks
- [ ] Pareto: safe + helpful

### Deployment Gates
- [ ] Blocking alignment evaluation
- [ ] Restricted rollout plan
- [ ] Continuous post-deployment monitoring
