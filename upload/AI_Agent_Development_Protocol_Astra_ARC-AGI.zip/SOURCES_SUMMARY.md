# Краткое извлечение принципов из первоисточников

## OpenAI GPT-6 Astra Safety Overview (сентябрь 2026)

1. **Critical Cyber Threshold**  
   Модель может находить 0-day и разрабатывать эксплойты без пошагового руководства человека → обязательны усиленные защиты от harmful cyber actions (misuse + misalignment).

2. **Robustness**  
   Значительно выше устойчивость к jailbreaks (включая длинные траектории). Возможность ужесточать refusal boundary.

3. **Alignment**  
   Сильнее уважает safety/security boundaries и остаётся в authorized scope. ~2× меньше high-severity misaligned flags на 54k+ внутренних задачах.

4. **Misalignment Monitoring**  
   Развёрнут на все tool-using inference. Parallel internal/external systems.

5. **Monitorability regression**  
   CoT стал менее информативным и более контролируемым моделью. Требуются методы auditing beyond CoT.

6. **Workplace & Browsing safety**  
   Значительно меньше misaligned/destructive actions (unauthorized transactions, data loss, excessive access, control circumvention). Robust to prompt injections.

7. **Safe Completions**  
   Pareto improvement на challenging production + adversarial prompts. Лучше обрабатывает high-severity contextual risks.

## ARC-AGI / ARC Prize Foundation

- **Определение интеллекта**: skill-acquisition efficiency (Chollet).
- **Fluid intelligence** > crystallized.
- **Core knowledge priors** only.
- **Easy for Humans, Hard for AI**.
- **ARC-AGI-3**: exploration + goal-directedness + memory + Relative Human Action Efficiency (RHAE).
- Успех = способность адаптироваться к novel environments, а не memorization или task-specific priors.

## Ссылки

- https://deploymentsafety.openai.com/gpt-6-astra/
- https://openai.com/index/safety-overview-gpt-6-astra/
- https://openai.com/index/gpt-6-astra/
- https://arcprize.org/
- https://docs.arcprize.org/methodology
