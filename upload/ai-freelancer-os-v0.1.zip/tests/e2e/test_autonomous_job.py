"""
End-to-End Automated Test for AI Freelancer OS.
Simulates and validates the entire autonomous freelance lifecycle:
DISCOVER -> QUALIFY -> SCORE -> PROPOSAL/CLAIM -> REPO -> CODE -> TEST -> QA -> DELIVERY -> PAYMENT.

Run via:
pytest tests/e2e/test_autonomous_job.py -v
"""

import pytest
import pytest_asyncio
from decimal import Decimal

from schemas.pydantic_schemas import JobDiscoveryPayload
from packages.agents.coding_agent import CodingAgent, PromptInjectionFirewall
from packages.agents.qa_agent import QAAgent
from packages.sandbox.docker_runner import DockerSandboxRunner


@pytest.mark.asyncio
async def test_full_autonomous_freelance_lifecycle():
    # 1. DISCOVER JOB
    job = JobDiscoveryPayload(
        marketplace="taskbounty",
        external_job_id="tb-issue-582",
        title="Fix FastAPI Async JWT Refresh Token Deadlock",
        description="Production deadlock bug in AsyncSession. Must pass all regression tests in E2B sandbox.",
        repo_url="github.com/cloudscale-corp/fastapi-auth-core",
        skills=["Python", "FastAPI", "SQLAlchemy"],
        budget_gross=Decimal("280.00"),
        currency="USDC",
        deadline_hours=8,
        client_rating=4.95,
        client_verified_payment=True,
        acceptance_criteria=[
            "AC1: Reproduce deadlock in isolated container",
            "AC2: Implement async session context manager",
            "AC3: 0 regressions across existing test suite"
        ]
    )

    # 2. PROMPT INJECTION FIREWALL CHECK
    is_threat = PromptInjectionFirewall.inspect(job.description)
    assert not is_threat, "Valid job should not be flagged as prompt injection"

    # 3. OPPORTUNITY ENGINE / EXPECTED VALUE CALCULATION
    marketplace_fee = Decimal("0.20")  # TaskBounty 20%
    p_win = Decimal("0.65")
    p_success = Decimal("0.95")
    operator_take = Decimal("1.00") - marketplace_fee
    
    expected_gross = job.budget_gross * p_win * p_success * operator_take
    compute_cost = Decimal("4.30")
    expected_profit = expected_gross - compute_cost
    
    assert expected_profit > Decimal("50.00"), f"Expected profit should be high, got {expected_profit}"

    # 4. PLAN & CODING ITERATION
    agent = CodingAgent(agent_id="coding_agent_001")
    plan = await agent.plan_implementation(job)
    assert not plan["blocked"], "Planning should succeed"
    assert len(plan["tasks"]) > 0, "Should have discrete subtasks"

    # 5. SANDBOX EXECUTION & TESTING
    runner = DockerSandboxRunner()
    sandbox_result = await runner.run_command_in_container(
        container_image="python:3.12-slim",
        command=["pytest", "tests/"],
        workspace_mount="/tmp/sandboxes/tb-issue-582"
    )
    assert sandbox_result["exit_code"] == 0, "Tests in sandbox must pass"
    assert "84 passed" in sandbox_result["stdout"]

    # 6. INDEPENDENT QA AUDIT
    qa = QAAgent()
    qa_report = await qa.audit_delivery(
        acceptance_criteria=job.acceptance_criteria,
        git_diff="+ async with AsyncSessionLocal() as session:",
        test_output=sandbox_result["stdout"]
    )
    assert qa_report.passed is True, "Independent QA audit must pass"
    assert qa_report.regressions_count == 0

    # 7. FINANCIAL SETTLEMENT & UNIT ECONOMICS VERIFICATION
    actual_gross = job.budget_gross
    actual_fee = actual_gross * marketplace_fee
    llm_cost = Decimal("3.20")
    sandbox_cost = Decimal("1.10")
    net_payout = actual_gross - actual_fee - llm_cost - sandbox_cost

    assert net_payout > Decimal("200.00"), f"Net profit {net_payout} must exceed target threshold"
    print(f"\n[E2E SUCCESS] Job settled! Net profit: " + str(net_payout) + " USDC on Base.")
