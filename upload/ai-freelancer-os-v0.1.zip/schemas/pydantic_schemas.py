"""
Pydantic v2 validation contracts for API and worker messaging.
"""

from decimal import Decimal
from typing import List, Optional, Dict, Any
from uuid import UUID
from datetime import datetime
from pydantic import BaseModel, Field, HttpUrl


class JobDiscoveryPayload(BaseModel):
    marketplace: str
    external_job_id: str
    title: str
    description: str
    repo_url: Optional[str] = None
    skills: List[str] = Field(default_factory=list)
    budget_gross: Decimal
    currency: str = "USD"
    deadline_hours: int = 24
    client_rating: float = 5.0
    client_verified_payment: bool = True
    acceptance_criteria: List[str] = Field(default_factory=list)


class OpportunityScoreResult(BaseModel):
    skill_match: Decimal
    client_quality: Decimal
    success_probability: Decimal
    win_probability: Decimal
    expected_revenue: Decimal
    expected_cost: Decimal
    expected_profit: Decimal
    profit_per_hour: Decimal
    decision: str  # APPLY, REJECT, HUMAN_APPROVAL
    reasoning: Dict[str, Any] = Field(default_factory=dict)


class ProposalDraftRequest(BaseModel):
    job_id: UUID
    price: Decimal
    content: str


class QAAuditReport(BaseModel):
    passed: bool
    criteria_results: Dict[str, bool]
    regressions_count: int
    security_clean: bool
    summary: str


class DeliverySubmission(BaseModel):
    summary: str
    patch_or_pr_url: str
    qa_report: QAAuditReport
    git_commit_hash: str
