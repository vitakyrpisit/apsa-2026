"""
Abstract Marketplace Adapter interface.
Unifies diverse platforms (TaskBounty, BasedAgents, AgentGigs, Upwork MCP) under a single contract.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import List, Dict, Any, Optional
from schemas.pydantic_schemas import JobDiscoveryPayload, DeliverySubmission


@dataclass
class MarketplaceCapabilities:
    can_auto_discover: bool
    can_auto_apply: bool
    can_auto_claim_bounty: bool
    supports_messaging: bool
    supports_escrow: bool
    payment_rail: str  # USDC/Base, USDC/Solana, Stripe
    requires_human_approval: bool


class MarketplaceAdapter(ABC):
    @property
    @abstractmethod
    def marketplace_id(self) -> str:
        pass

    @property
    @abstractmethod
    def capabilities(self) -> MarketplaceCapabilities:
        pass

    @abstractmethod
    async def discover_jobs(self, filters: Dict[str, Any]) -> List[JobDiscoveryPayload]:
        """Fetch available job postings matching agent skill filters."""
        pass

    @abstractmethod
    async def submit_proposal(self, job_id: str, proposal_text: str, price: float) -> str:
        """Submit proposal or bid. Returns external proposal ID."""
        pass

    @abstractmethod
    async def claim_bounty(self, job_id: str) -> bool:
        """Atomically claim a programmatic bounty (e.g. TaskBounty / BasedAgents)."""
        pass

    @abstractmethod
    async def submit_delivery(self, job_id: str, delivery: DeliverySubmission) -> str:
        """Submit code patch, PR link, and verified test evidence to client/escrow."""
        pass

    @abstractmethod
    async def check_payment_settled(self, contract_id: str) -> Optional[Dict[str, Any]]:
        """Verify escrow release and record tx hash or invoice confirmation."""
        pass
