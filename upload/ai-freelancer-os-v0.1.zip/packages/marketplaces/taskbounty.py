"""
TaskBounty Marketplace Adapter.
Connects to TaskBounty API/MCP for GitHub issues, automated claims, and E2B verification sandbox.
Split: 80% Operator, 20% Platform fee. Instant USDC on Base network.
"""

import httpx
from typing import List, Dict, Any, Optional
from decimal import Decimal

from packages.marketplaces.base import MarketplaceAdapter, MarketplaceCapabilities
from schemas.pydantic_schemas import JobDiscoveryPayload, DeliverySubmission


class TaskBountyAdapter(MarketplaceAdapter):
    def __init__(self, api_key: str, base_url: str = "https://api.task-bounty.com/v1"):
        self.api_key = api_key
        self.base_url = base_url
        self.headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "User-Agent": "AIFreelancerOS/0.1.0"
        }

    @property
    def marketplace_id(self) -> str:
        return "taskbounty"

    @property
    def capabilities(self) -> MarketplaceCapabilities:
        return MarketplaceCapabilities(
            can_auto_discover=True,
            can_auto_apply=True,
            can_auto_claim_bounty=True,
            supports_messaging=False,  # GitHub issue based
            supports_escrow=True,
            payment_rail="USDC/Base",
            requires_human_approval=False
        )

    async def discover_jobs(self, filters: Dict[str, Any]) -> List[JobDiscoveryPayload]:
        # Connects to live TaskBounty bounty feed
        async with httpx.AsyncClient(timeout=10.0) as client:
            try:
                resp = await client.get(
                    f"{self.base_url}/bounties",
                    headers=self.headers,
                    params={"status": "open", "skills": filters.get("skills", [])}
                )
                if resp.status_code == 200:
                    raw_items = resp.json().get("items", [])
                    return [
                        JobDiscoveryPayload(
                            marketplace="taskbounty",
                            external_job_id=item["id"],
                            title=item["title"],
                            description=item["description"],
                            repo_url=item.get("github_repo"),
                            skills=item.get("tags", ["Python"]),
                            budget_gross=Decimal(str(item["bounty_amount_usd"])),
                            currency="USDC",
                            deadline_hours=item.get("timeout_hours", 12),
                            acceptance_criteria=item.get("acceptance_tests", [])
                        )
                        for item in raw_items
                    ]
            except Exception:
                pass
        return []

    async def claim_bounty(self, job_id: str) -> bool:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.post(
                f"{self.base_url}/bounties/{job_id}/claim",
                headers=self.headers
            )
            return resp.status_code in [200, 201]

    async def submit_proposal(self, job_id: str, proposal_text: str, price: float) -> str:
        # In TaskBounty, claiming is the proposal action
        success = await self.claim_bounty(job_id)
        return f"tb-claim-{job_id}" if success else ""

    async def submit_delivery(self, job_id: str, delivery: DeliverySubmission) -> str:
        payload = {
            "patch_url": delivery.patch_or_pr_url,
            "commit_hash": delivery.git_commit_hash,
            "qa_passed": delivery.qa_report.passed,
            "summary": delivery.summary
        }
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.post(
                f"{self.base_url}/bounties/{job_id}/submit",
                headers=self.headers,
                json=payload
            )
            if resp.status_code == 200:
                return resp.json().get("submission_id", f"sub-{job_id}")
            return f"manual-sub-{job_id}"

    async def check_payment_settled(self, contract_id: str) -> Optional[Dict[str, Any]]:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(
                f"{self.base_url}/settlements/{contract_id}",
                headers=self.headers
            )
            if resp.status_code == 200:
                return resp.json()
        return None
