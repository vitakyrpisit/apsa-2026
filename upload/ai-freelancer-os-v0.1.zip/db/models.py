"""
SQLAlchemy 2.0 Async Domain Models for AI Freelancer OS.
Supports complete lifecycle from job discovery to delivery, escrow, QA audit, and cost tracking.
"""

from datetime import datetime, timezone
import uuid
from decimal import Decimal
from typing import Optional, List, Dict, Any

from sqlalchemy import (
    String, Text, Boolean, Integer, Numeric, DateTime, ForeignKey, 
    Index, UniqueConstraint, JSON
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
from sqlalchemy.dialects.postgresql import UUID, JSONB


class Base(DeclarativeBase):
    pass


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


class User(Base):
    __tablename__ = "users"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    status: Mapped[str] = mapped_column(String(50), default="active", nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)

    agents: Mapped[List["Agent"]] = relationship("Agent", back_populates="user", cascade="all, delete-orphan")


class Agent(Base):
    __tablename__ = "agents"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"))
    
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    agent_type: Mapped[str] = mapped_column(String(50), default="coding", nullable=False)  # coding, research, qa
    status: Mapped[str] = mapped_column(String(50), default="idle", nullable=False)
    
    public_key: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)  # Ed25519 pubkey
    system_prompt_version: Mapped[str] = mapped_column(String(50), default="v1.0")
    
    daily_spend_limit: Mapped[Decimal] = mapped_column(Numeric(12, 2), default=Decimal("50.00"))
    daily_llm_budget: Mapped[Decimal] = mapped_column(Numeric(12, 2), default=Decimal("15.00"))
    max_concurrent_jobs: Mapped[int] = mapped_column(Integer, default=2)
    
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now, onupdate=utc_now)

    user: Mapped["User"] = relationship("User", back_populates="agents")
    skills: Mapped[List["AgentSkill"]] = relationship("AgentSkill", back_populates="agent")
    accounts: Mapped[List["MarketplaceAccount"]] = relationship("MarketplaceAccount", back_populates="agent")
    jobs: Mapped[List["Job"]] = relationship("Job", back_populates="agent")


class AgentSkill(Base):
    __tablename__ = "agent_skills"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    agent_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("agents.id", ondelete="CASCADE"))
    
    skill: Mapped[str] = mapped_column(String(100), nullable=False)
    confidence: Mapped[Decimal] = mapped_column(Numeric(5, 4), default=Decimal("0.9000"))
    jobs_completed: Mapped[int] = mapped_column(Integer, default=0)
    jobs_failed: Mapped[int] = mapped_column(Integer, default=0)
    win_rate: Mapped[Decimal] = mapped_column(Numeric(5, 4), default=Decimal("0.5000"))

    agent: Mapped["Agent"] = relationship("Agent", back_populates="skills")
    __table_args__ = (UniqueConstraint("agent_id", "skill", name="uq_agent_skill"),)


class MarketplaceAccount(Base):
    __tablename__ = "marketplace_accounts"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    agent_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("agents.id", ondelete="CASCADE"))
    
    marketplace: Mapped[str] = mapped_column(String(50), nullable=False)  # taskbounty, basedagents, agentgigs
    external_account_id: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    credential_ref: Mapped[str] = mapped_column(String(255), nullable=False)  # Vault pointer
    capabilities: Mapped[Dict[str, Any]] = mapped_column(JSONB, default=dict)
    status: Mapped[str] = mapped_column(String(50), default="active")

    agent: Mapped["Agent"] = relationship("Agent", back_populates="accounts")
    __table_args__ = (UniqueConstraint("agent_id", "marketplace", name="uq_agent_marketplace"),)


class Job(Base):
    __tablename__ = "jobs"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    agent_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("agents.id", ondelete="CASCADE"))
    marketplace: Mapped[str] = mapped_column(String(50), nullable=False)
    external_job_id: Mapped[str] = mapped_column(String(255), nullable=False)

    title: Mapped[str] = mapped_column(String(500), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    repo_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    
    budget_gross: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False)
    currency: Mapped[str] = mapped_column(String(10), default="USD")
    deadline_hours: Mapped[int] = mapped_column(Integer, default=24)
    
    status: Mapped[str] = mapped_column(String(50), default="DISCOVERED", nullable=False)
    risk_score: Mapped[Decimal] = mapped_column(Numeric(5, 4), default=Decimal("0.1000"))
    expected_profit: Mapped[Decimal] = mapped_column(Numeric(12, 2), default=Decimal("0.00"))
    
    raw_payload: Mapped[Dict[str, Any]] = mapped_column(JSONB, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now, onupdate=utc_now)

    agent: Mapped["Agent"] = relationship("Agent", back_populates="jobs")
    score: Mapped[Optional["JobScore"]] = relationship("JobScore", uselist=False, back_populates="job")
    proposal: Mapped[Optional["Proposal"]] = relationship("Proposal", uselist=False, back_populates="job")
    project: Mapped[Optional["Project"]] = relationship("Project", uselist=False, back_populates="job")

    __table_args__ = (UniqueConstraint("marketplace", "external_job_id", name="uq_marketplace_job"),)


class JobScore(Base):
    __tablename__ = "job_scores"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    job_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("jobs.id", ondelete="CASCADE"), unique=True)
    
    skill_match: Mapped[Decimal] = mapped_column(Numeric(5, 4), nullable=False)
    client_quality: Mapped[Decimal] = mapped_column(Numeric(5, 4), nullable=False)
    success_probability: Mapped[Decimal] = mapped_column(Numeric(5, 4), nullable=False)
    win_probability: Mapped[Decimal] = mapped_column(Numeric(5, 4), nullable=False)
    
    expected_revenue: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False)
    expected_cost: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False)
    expected_profit: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False)
    profit_per_hour: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False)
    
    decision: Mapped[str] = mapped_column(String(50), nullable=False)  # APPLY, REJECT, HUMAN_APPROVAL
    reasoning: Mapped[Dict[str, Any]] = mapped_column(JSONB, default=dict)

    job: Mapped["Job"] = relationship("Job", back_populates="score")


class Proposal(Base):
    __tablename__ = "proposals"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    job_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("jobs.id", ondelete="CASCADE"), unique=True)
    
    price: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False)
    currency: Mapped[str] = mapped_column(String(10), default="USD")
    content: Mapped[str] = mapped_column(Text, nullable=False)
    
    status: Mapped[str] = mapped_column(String(50), default="DRAFT")  # DRAFT, SENT, ACCEPTED, REJECTED
    external_proposal_id: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    submitted_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    job: Mapped["Job"] = relationship("Job", back_populates="proposal")


class Project(Base):
    __tablename__ = "projects"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    job_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("jobs.id", ondelete="CASCADE"), unique=True)
    
    workspace_path: Mapped[str] = mapped_column(String(500), nullable=False)
    git_branch: Mapped[str] = mapped_column(String(100), default="ai-agent/fix")
    status: Mapped[str] = mapped_column(String(50), default="RUNNING")
    
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
    completed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    job: Mapped["Job"] = relationship("Job", back_populates="project")
    artifacts: Mapped[List["Artifact"]] = relationship("Artifact", back_populates="project")
    deliveries: Mapped[List["Delivery"]] = relationship("Delivery", back_populates="project")
    payments: Mapped[List["Payment"]] = relationship("Payment", back_populates="project")


class Artifact(Base):
    __tablename__ = "artifacts"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    project_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("projects.id", ondelete="CASCADE"))
    
    artifact_type: Mapped[str] = mapped_column(String(50), nullable=False)  # commit, patch, pr, test_log
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    uri: Mapped[str] = mapped_column(String(1000), nullable=False)
    checksum: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    metadata_payload: Mapped[Dict[str, Any]] = mapped_column(JSONB, default=dict)

    project: Mapped["Project"] = relationship("Project", back_populates="artifacts")


class Delivery(Base):
    __tablename__ = "deliveries"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    project_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("projects.id", ondelete="CASCADE"))
    
    external_delivery_id: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    qa_audit_status: Mapped[str] = mapped_column(String(50), default="PENDING")  # PASSED, FAILED
    status: Mapped[str] = mapped_column(String(50), default="SUBMITTED")
    summary: Mapped[str] = mapped_column(Text, nullable=False)
    
    submitted_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
    accepted_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    project: Mapped["Project"] = relationship("Project", back_populates="deliveries")


class Payment(Base):
    __tablename__ = "payments"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    project_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("projects.id", ondelete="CASCADE"))
    
    marketplace: Mapped[str] = mapped_column(String(50), nullable=False)
    gross_amount: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False)
    marketplace_fee: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False)
    net_payout: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False)
    currency: Mapped[str] = mapped_column(String(10), default="USD")
    
    tx_hash_or_ref: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    status: Mapped[str] = mapped_column(String(50), default="SETTLED")
    paid_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)

    project: Mapped["Project"] = relationship("Project", back_populates="payments")


class CostEvent(Base):
    __tablename__ = "cost_events"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    job_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("jobs.id", ondelete="SET NULL"), nullable=True)
    
    category: Mapped[str] = mapped_column(String(50), nullable=False)  # llm, sandbox, api, proxy
    provider: Mapped[str] = mapped_column(String(50), nullable=False)  # gemini, docker, e2b
    units: Mapped[Decimal] = mapped_column(Numeric(12, 2), default=Decimal("0.00"))  # tokens or seconds
    amount_usd: Mapped[Decimal] = mapped_column(Numeric(12, 6), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
