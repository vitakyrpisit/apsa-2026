-- Initial PostgreSQL Migration for AI Freelancer OS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'active',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE agents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    agent_type VARCHAR(50) NOT NULL DEFAULT 'coding',
    status VARCHAR(50) NOT NULL DEFAULT 'idle',
    public_key VARCHAR(128),
    system_prompt_version VARCHAR(50) DEFAULT 'v1.0',
    daily_spend_limit NUMERIC(12,2) DEFAULT 50.00,
    daily_llm_budget NUMERIC(12,2) DEFAULT 15.00,
    max_concurrent_jobs INT DEFAULT 2,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE agent_skills (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    agent_id UUID NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
    skill VARCHAR(100) NOT NULL,
    confidence NUMERIC(5,4) DEFAULT 0.9000,
    jobs_completed INT DEFAULT 0,
    jobs_failed INT DEFAULT 0,
    win_rate NUMERIC(5,4) DEFAULT 0.5000,
    CONSTRAINT uq_agent_skill UNIQUE (agent_id, skill)
);

CREATE TABLE marketplace_accounts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    agent_id UUID NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
    marketplace VARCHAR(50) NOT NULL,
    external_account_id VARCHAR(255),
    credential_ref VARCHAR(255) NOT NULL,
    capabilities JSONB DEFAULT '{}'::jsonb,
    status VARCHAR(50) DEFAULT 'active',
    CONSTRAINT uq_agent_marketplace UNIQUE (agent_id, marketplace)
);

CREATE TABLE jobs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    agent_id UUID NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
    marketplace VARCHAR(50) NOT NULL,
    external_job_id VARCHAR(255) NOT NULL,
    title VARCHAR(500) NOT NULL,
    description TEXT,
    repo_url VARCHAR(500),
    budget_gross NUMERIC(12,2) NOT NULL,
    currency VARCHAR(10) DEFAULT 'USD',
    deadline_hours INT DEFAULT 24,
    status VARCHAR(50) NOT NULL DEFAULT 'DISCOVERED',
    risk_score NUMERIC(5,4) DEFAULT 0.1000,
    expected_profit NUMERIC(12,2) DEFAULT 0.00,
    raw_payload JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_marketplace_job UNIQUE (marketplace, external_job_id)
);

CREATE INDEX idx_jobs_status ON jobs(status);
CREATE INDEX idx_jobs_marketplace ON jobs(marketplace);

CREATE TABLE job_scores (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    job_id UUID NOT NULL UNIQUE REFERENCES jobs(id) ON DELETE CASCADE,
    skill_match NUMERIC(5,4) NOT NULL,
    client_quality NUMERIC(5,4) NOT NULL,
    success_probability NUMERIC(5,4) NOT NULL,
    win_probability NUMERIC(5,4) NOT NULL,
    expected_revenue NUMERIC(12,2) NOT NULL,
    expected_cost NUMERIC(12,2) NOT NULL,
    expected_profit NUMERIC(12,2) NOT NULL,
    profit_per_hour NUMERIC(12,2) NOT NULL,
    decision VARCHAR(50) NOT NULL,
    reasoning JSONB DEFAULT '{}'::jsonb
);

CREATE TABLE proposals (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    job_id UUID NOT NULL UNIQUE REFERENCES jobs(id) ON DELETE CASCADE,
    price NUMERIC(12,2) NOT NULL,
    currency VARCHAR(10) DEFAULT 'USD',
    content TEXT NOT NULL,
    status VARCHAR(50) DEFAULT 'DRAFT',
    external_proposal_id VARCHAR(255),
    submitted_at TIMESTAMPTZ
);

CREATE TABLE projects (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    job_id UUID NOT NULL UNIQUE REFERENCES jobs(id) ON DELETE CASCADE,
    workspace_path VARCHAR(500) NOT NULL,
    git_branch VARCHAR(100) DEFAULT 'ai-agent/fix',
    status VARCHAR(50) DEFAULT 'RUNNING',
    started_at TIMESTAMPTZ DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);

CREATE TABLE artifacts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    artifact_type VARCHAR(50) NOT NULL,
    name VARCHAR(255) NOT NULL,
    uri VARCHAR(1000) NOT NULL,
    checksum VARCHAR(64),
    metadata_payload JSONB DEFAULT '{}'::jsonb
);

CREATE TABLE deliveries (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    external_delivery_id VARCHAR(255),
    qa_audit_status VARCHAR(50) DEFAULT 'PENDING',
    status VARCHAR(50) DEFAULT 'SUBMITTED',
    summary TEXT NOT NULL,
    submitted_at TIMESTAMPTZ DEFAULT NOW(),
    accepted_at TIMESTAMPTZ
);

CREATE TABLE payments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    marketplace VARCHAR(50) NOT NULL,
    gross_amount NUMERIC(12,2) NOT NULL,
    marketplace_fee NUMERIC(12,2) NOT NULL,
    net_payout NUMERIC(12,2) NOT NULL,
    currency VARCHAR(10) DEFAULT 'USD',
    tx_hash_or_ref VARCHAR(255),
    status VARCHAR(50) DEFAULT 'SETTLED',
    paid_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE cost_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    job_id UUID REFERENCES jobs(id) ON DELETE SET NULL,
    category VARCHAR(50) NOT NULL,
    provider VARCHAR(50) NOT NULL,
    units NUMERIC(12,2) DEFAULT 0.00,
    amount_usd NUMERIC(12,6) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
