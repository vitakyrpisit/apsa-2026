# AI Freelancer OS - v0.1 Executable Skeleton

Autonomous Multi-Marketplace AI Freelance Operating System.
Covers TaskBounty, BasedAgents, AgentGigs, ClawGig, and Upwork MCP.

## Quickstart

1. Launch environment via Docker:
```bash
cp .env.example .env
docker compose up -d
```

2. Run Database Migrations:
```bash
docker compose exec api python db/seed_data.py
```

3. Run the Autonomous End-to-End Cycle Test:
```bash
docker compose exec worker pytest tests/e2e/test_autonomous_job.py -v
```

## Architecture & Lifecycle
- Discovery -> Opportunity EV Scoring -> Proposal/Claim -> Isolated Sandbox -> Coding & PyTest -> Independent QA -> Delivery -> Escrow Payment.
