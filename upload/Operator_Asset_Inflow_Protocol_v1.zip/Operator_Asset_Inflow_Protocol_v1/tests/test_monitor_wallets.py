import importlib.util
from pathlib import Path
p=Path(__file__).parents[1]/"scripts"/"monitor_wallets.py"
s=importlib.util.spec_from_file_location("mon",p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
def test_exact_base_units():
 w={"network":"ethereum","asset":"ETH","address":"0xabc","explorer":"https://example.test"}
 x=m.rec(w,"hash",None,"2770120000000000","incoming","success","0xfrom","0xabc")
 assert x["amount_base_units"]=="2770120000000000" and x["recipient"]=="0xabc"
def test_unknown_amount_stays_unknown():
 w={"network":"solana","asset":"SOL","address":"wallet","explorer":"https://example.test"}
 assert m.rec(w,"sig",1,"unknown","candidate","observed")["amount_base_units"]=="unknown"
