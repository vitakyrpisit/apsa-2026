# Changelog

## 1.0.0 — 2026-10-09
- Consolidated the mission around real, attributable inflows.
- Added cross-platform master protocol, safety controls, revenue operations, ARC-AGI guidance and source notes.
- Added read-only monitor and static Receive page generator.
- Recorded historical ETH transfer with explicit attribution caveat.
- No private keys, signing or transaction-sending code.
