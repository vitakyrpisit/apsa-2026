# Architecture

## 1. Design stance (what we took from Anthropic's published agent guidance)
| Principle | How it shows up here |
|---|---|
| Use the simplest thing that works; agents only where the path cannot be hard-coded **and** progress is verifiable | Everything outside the code loop is a deterministic *workflow* (scan → trust gate → score → probe → claim → … → settle). The LLM-driven *agent* exists in exactly one place: the edit/test loop, where tests give ground truth. |
| Ground truth from the environment at every step | Test runs in a sandbox, git diffs, marketplace payment status with a tx reference. Never the model's own claim of success. |
| Evaluator–optimizer, with an evaluator that cannot be talked round | Coder and QA are separate components; QA re-creates a clean checkout, re-runs tests (plus validator-owned tests the coder never saw) and may only *downgrade*. |
| Invest in the agent–computer interface (ACI) | Few, orthogonal tools; relative paths only; numbered `read_file`; `replace` that fails loudly on ambiguity; every tool documented with an example in the prompt; errors are explanations ("matches 2 places; add context"). |
| Context is a finite resource | Just-in-time reads, 6 KB observation clipping, sliding window, a persistent `note` tool re-injected every turn (structured note-taking), stuck-detection to avoid burning context on repeated failures. |
| Stopping conditions & human checkpoints | step budget, $ budget, stuck abort, kill switch, approval queue for first N live jobs / large budgets / low confidence / open circuit breaker. |
| Transparency | plan is persisted, full transcript (secret-redacted) and QA report saved per job under `data/artifacts/`. |
| Evaluation-driven development | `fos eval`: 3 solved tasks + 13 adversarial scenarios. Metrics per job: tool calls, tool errors, tokens, cost, wall-clock. |

## 2. Pipeline
```
DISCOVER → DEDUP → FIREWALL → DEMAND-VERIFICATION GATE → SCORE(pre) → {REJECT | APPROVAL | CLAIM}
   → PROBE (clone, baseline tests) → SCORE(post, real testability) → CLAIM → CODE(agent loop)
   → INDEPENDENT QA → COMMIT/PR → DELIVER → SETTLE (tx-verified) → LEARN (posteriors, breaker)
```
State machine persisted in SQLite after every transition; crash-safe and idempotent (jobs are keyed `marketplace:id`, never re-scored or re-claimed).

## 3. The mathematics (what is used, and why it earns its place)
**Expected profit** of attempting a job:

`EV = B · P(win) · P(success) · P(pay) · (1 − f)  −  [ P(win) · C_work + C_probe ]`

* `B` bounty, `f` platform fee, `C_work` expected LLM+compute cost *if we win* (paid whether or not we succeed), `C_probe` clone+baseline cost (always paid).
* `P(pay)` is the factor most agent-income schemes ignore: escrow-confirmed ≈ 0.93, unknown funding ≈ 0.55, requester with zero settlement history ×0.6.
* Decision requires `EV ≥ min_profit` **and** `EV / cost ≥ min_ROI` **and** hard floors on `P(success)`.

**Probabilities = prior ⊕ evidence (conjugate Beta update).** Each probability starts as a transparent prior from observable features
(skill match, requirement clarity, testability, repo health, time margin, complexity) and is blended with the agent's own outcomes:
`p = (K·prior + successes) / (K + n)`, K = 8 (6 for P(pay)). With few outcomes the prior dominates; with many, data dominates. Cap 0.92.

**Saturation** (open-race bounties): expected competitors `n ≈ 2 + 4·age/24h` when unknown; `P(win) ≈ 1/(1 + 1.1 n)`. Fresh tasks have odds, stale ones don't.

**Exploration vs exploitation — Thompson sampling.** Jobs are ranked by *sampled* value/hour with `p_success ~ Beta(a, b)` (the same posterior). Proven lanes win most draws; unknown lanes still get tried, and the exploration rate decays automatically with evidence.

**Honest uncertainty — Wilson score bound.** Success-rate decisions use the 95 % lower bound (3/3 ⇒ 0.53, not 1.0; 16/20 ⇒ 0.62). The **circuit breaker** opens when the bound over the last 20 jobs falls below 0.30 (after ≥ 8 jobs) or 30-day net P&L < −$15; when open, every job needs a human.

**Calibration.** Brier score over completed jobs is reported by `fos pnl`; < 0.25 beats a coin flip. Needs ≥ 20 jobs to mean anything.

*Geometry, physics and other sciences:* we deliberately do not decorate the system with them. Where an engineering discipline applies it is
used for real — resource limits (cgroups: memory/CPU/pids), timeouts and process-group kills, idempotency, queueing (concurrency = 1 until measured),
cryptography (Ed25519 request signing, EIP-55/base58check/bech32 checksums), and statistics (above).

## 4. Components
`marketplaces/` adapters (+ honest `PlannedAdapter`) · `security/` firewall, untrusted-data quoting, redaction · `opportunity/` engine, trust gate, bandit, breaker ·
`agents/` coder, jailed workspace, QA · `sandbox/` Docker/local runners, pytest parser · `vcs/` git + GitHub PR · `treasury/` caps, ledger, wallets · `storage/` SQLite · `api/` control plane · `evals/` golden tasks · `cli.py`.

## 5. Known limits
Python/pytest only; one concurrent job; response shapes of live marketplaces are parsed defensively but unverified until `fos doctor --live`; LLM QA can be fooled (hence it only downgrades).
