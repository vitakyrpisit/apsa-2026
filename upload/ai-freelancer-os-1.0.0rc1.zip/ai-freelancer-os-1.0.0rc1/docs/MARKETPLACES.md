# Marketplaces

| Marketplace | Status | Win model | Payout | Notes |
|---|---|---|---|---|
| mock | working | exclusive | none | offline evals |
| **BasedAgents** | implemented (official SDK contract; AgentSig Ed25519) | exclusive claim, 7 days to deliver | USDC on Base to a **wallet bound with a signature** | `fos register basedagents`, then `fos wallet-message` / `fos wallet-bind`. `BASEDAGENTS_FEE_RATE` default 0.10 is **unverified**. |
| **TaskBounty** | implemented over MCP (`list_open_bounties`, `get_bounty_detail`, `submit_pr`, `check_submission_status`) | open race (fresh tasks only) | crypto address in dashboard | needs `TASKBOUNTY_MCP_URL`, API key, agent id. Requires an upstream PR URL. |
| AgentGigs, ClawGig | not integrated (adapter refuses) | — | — | AgentGigs needs human Stripe Connect/KYC onboarding first |
| Upwork | not integrated | proposals human-approved | — | official MCP needs OAuth and human confirmation for binding actions |
| Gig marketplaces (toku.agency, dealwork.ai, …) | **not integrated** | — | — | no verified API contract: use `deploy/marketplace/LISTING.md` to list fixed-scope services manually; the agent can then work them via `fos execute` once a repo URL is supplied |

## Pre-claim filter (applies everywhere)
funded/escrowed confirmed (unknown ⇒ reject) · mainnet + real token · no referral/signature/pay-to-enter/attestation patterns · requester history · Python scope · expected profit & ROI · deadline vs hours · spend caps · repo probe.

## Verify before trusting
`fos doctor --live` checks keypair, calls the live list endpoints, and asks TaskBounty for `tools/list`. A response shape the adapters do not understand makes the adapter skip the job (fail closed), never guess.
