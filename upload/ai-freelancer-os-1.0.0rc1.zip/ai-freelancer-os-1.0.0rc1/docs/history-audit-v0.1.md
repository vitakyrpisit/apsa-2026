# Audit of the v0.1 archive (verified by unpacking and running it)

| # | Finding | Evidence | v0.3 fix |
|---|---|---|---|
| 1 | Project does not compile | `docker_runner.py` SyntaxError (multi-line string) | rewritten; `ruff`/pytest clean |
| 2 | "Sandbox" never ran Docker | `asyncio.sleep(0.5)` then returns canned `84 passed` | real `docker run` (no network, caps dropped, mem/cpu/pids limits, non-root) |
| 3 | Coding agent wrote no code | returned a fixed 4-step plan and fake `modified_files` | LLM planner + jailed tool loop, verified by real tests |
| 4 | QA always passed | `criteria_results[key] = True`, `passed=True` | fail-closed oracle; independent re-run; anti-cheat checks; negative controls in eval |
| 5 | GitHub tool simulated | every method returned canned values, PR #142 | real git subprocess + GitHub REST (fork/push/PR) |
| 6 | **Prompt-injection firewall matched nothing** | regexes were `r"ignores+(previous|all)s+instructions"`: every `\s` lost its backslash | fixed, normalised (NFKC, zero-width), regression-tested |
| 7 | Worker/seed/API fabricated numbers | `14 jobs / 4 qualified / $133.56`, `treasury_balance 742.10`, `autonomy 88%` | DB-backed; API reports real zeros |
| 8 | EV used constants | `p_win=0.60`, `p_success=0.92`, `skill_match=0.95`, cost `4.50` | feature-based priors + Beta learning from outcomes |
| 9 | E2E test proved nothing | asserted the mock's string `"84 passed"` | E2E uses real git/tests/QA; `parse_pytest` rejects spoofed text |
| 10 | Missing imports / Dockerfiles | `uuid, datetime, Decimal` unimported; `infra/docker/Dockerfile.*` absent | removed dead code; Dockerfiles supplied |
| 11 | TaskBounty adapter used guessed endpoints (`api.task-bounty.com/v1/bounties`) | official MCP exposes `list_open_bounties/submit_pr/...` on `www.task-bounty.com` | MCP-based adapter, fail-closed doctor |
| 12 | Unauthenticated API with `allow_origins=*` + credentials | `apps/api/main.py` | bearer token required, no CORS, bind 127.0.0.1 |

Bugs found *by the new test-suite while building v0.3* (kept as regression tests): QA's extra checks were silently dropped from the report
(pydantic copies lists); `assert 1 == 1` was wrongly flagged as a weakened test.
