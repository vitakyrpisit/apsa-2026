# ADR 0003 — Wallets are public addresses; networks must be operator-confirmed
**Decision:** no spending keys anywhere; every address checksum-validated; `WALLET_CONFIRMED_NETWORKS` must list a network before live mode. **Why:** wrong-network deposits to custodial addresses are unrecoverable; an agent holding keys is an unbounded loss.
