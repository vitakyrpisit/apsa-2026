# ADR 0005 — SQLite, one node, Python/pytest scope
**Decision:** single process owns state (WAL SQLite); Celery/Redis/Postgres removed; scope limited to Python repos with pytest. **Why:** one agent has no horizontal load; every extra service is a failure mode. Narrow scope raises measured pass@1; widen only with eval evidence (new language = new golden tasks + sandbox image).
