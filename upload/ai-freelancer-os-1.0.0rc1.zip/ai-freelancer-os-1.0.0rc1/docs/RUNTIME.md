# Where the agent runs (Z.ai / chat.z.ai analysis)

## What chat.z.ai is
A web chat from Z.ai (Zhipu) with an **Agent mode** and built-in "skills" that produce deliverables (documents, spreadsheets, code, pages). Free tier with quotas.
The models behind it (GLM-5 / GLM-5.1; 200K context, deep-thinking mode, function calling, structured JSON output) are also exposed through an
**OpenAI-compatible API** (`https://api.z.ai/api/paas/v4/chat/completions`) and an Anthropic-compatible endpoint used by Claude Code-style tools.

## What it is not (our inference — we found no documentation of a persistent background runtime)
A chat session is interactive, quota-limited and ends when you close it. It is not a place to run a 24/7 daemon that holds a signing key, polls marketplaces
and drives Docker. Putting the agent *inside* a chat would also remove the guarantees (isolation, ledger, kill switch) the system is built on.

## Decision
**Z.ai is the brain, not the host.** The runtime is code you control; Z.ai is called through its API.
1. Set `LLM_PROVIDER=zai`, `LLM_MODEL=glm-5.1`, `ZAI_API_KEY=…` (works on the free API quota or a GLM Coding Plan — use the endpoint Z.ai lists for your plan in `ZAI_BASE_URL`).
2. Use **chat.z.ai Agent mode as the operator's console**: paste `fos jobs` / `fos show` output, ask it to review a `patch.diff` or draft a listing — a human-in-the-loop second opinion, not the executor.
3. Pick a host:
   | Host | Cost | Notes |
   |---|---|---|
   | **GitHub Actions** (`.github/workflows/agent-run.yml`) | free for private repos within the monthly minutes quota (verify current limits) | Docker available, scheduled every 30 min, state kept on an orphan branch. Fastest to start. |
   | Small VPS + `docker compose` (`deploy/docker/`) | ~$5/mo | Continuous worker; dedicated VM only (Docker socket = root). |
   | Your laptop | free | `fos worker`; only while it's on. |
4. Tune for GLM: thinking mode raises cost and latency; for the tool loop try `LLM_EXTRA_BODY={"thinking":{"type":"disabled"}}` and compare with `fos eval --llm`. Keep the better pass@1 per dollar.

## Model selection rule
Run `fos eval --llm` for each candidate (GLM-5.1, a Claude model, Gemini). Choose the cheapest model with pass@1 ≥ 80 %. Use a *different* model for `QA_LLM_*`.
