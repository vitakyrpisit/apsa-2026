# Payout wallets

Public addresses only — configured in `.env` (`WALLET_*`). The agent never needs, stores or asks for a private key. Run `fos wallets` to validate.

| Network | Address (as configured) | Validation |
|---|---|---|
| Ethereum / Arbitrum / Base | `0x829f877daAb94D766BB2b8511ad486C40f2C2BDA` | EIP-55 checksum ✔ |
| Solana | `EyTxSdVtku7QtbwgntLvUwyxMvraJyAxoPoZ8ALdG6qL` | 32-byte key ✔ |
| Tron | `TVVhpdHEg1ZgvPjJNSe2P28bhUDE4m85ZX` | base58check ✔ |
| Bitcoin | `bc1qaedy7cmqujxlmkezlxlytkrecv0ufku970tk9c` | bech32 segwit v0 ✔ |

## ⚠ Read before going live (money can be lost here)
1. **Your Arbitrum entry has a trailing number (`578354`).** EVM addresses have no memo. It looks like a deposit *memo/tag* from an exchange or custodial app.
   It was **not** included. If it really is a memo, the address is an exchange deposit address — see 2 and 3.
2. **The wording "this address accepts only Ethereum assets" usually means a custodial deposit address.** BasedAgents pays **USDC on Base**. If your custodian does not
   support Base deposits at that address, the payout can be **permanently lost**. `WALLET_CONFIRMED_NETWORKS` is empty on purpose: `fos doctor` refuses live mode
   until you confirm each network after checking with a small test transfer (e.g. $1 USDC on Base) and seeing it arrive.
3. **BasedAgents requires proof of wallet control**: a signature *from the wallet* over a bind message. A custodial/exchange address cannot sign. You need a self-custody EVM wallet
   (MetaMask, Rabby, Ledger…). Recommended: create one, use it for `WALLET_EVM`, and sweep earnings to your exchange periodically.
4. Never send the private key / seed phrase to the agent, this repo, chat.z.ai or anyone.

## BasedAgents binding (Base, USDC) — 2 minutes
```bash
fos register basedagents                       # creates the agent identity (back up data/keys/!)
fos wallet-message --network eip155:8453 > msg.txt   # prints the exact message the registry expects (valid 15 min)
# sign msg.txt with the wallet (MetaMask → Sign message / personal_sign), copy the 0x… signature
fos wallet-bind --message-file msg.txt --signature 0xSIGNATURE
```
Without a bound wallet, claiming a bounty task returns `409 wallet_required`.

## TaskBounty
Set the payout address in the TaskBounty dashboard (supports Solana-USDC, EVM/Base-USDC, BTC addresses; no bank). Use the address whose network you confirmed.
