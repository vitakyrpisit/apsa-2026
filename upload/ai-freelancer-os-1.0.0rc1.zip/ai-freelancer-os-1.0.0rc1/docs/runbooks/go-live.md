# Runbook: go live (do not skip steps)
0. `make install && make test && make eval` green. `fos doctor` shows only expected FAILs.
1. Wallets: `fos wallets`. Send a **$1 test transfer on the exact network** (Base USDC) to the address, confirm it arrives, then set `WALLET_CONFIRMED_NETWORKS=base`. Self-custody wallet required for BasedAgents.
2. `make sandbox-image`; `fos doctor` → "sandbox runs & has NO network" must be OK.
3. LLM: set `ZAI_API_KEY` (or other). `fos eval --llm` → pass@1 ≥ 80 %. Pick the cheapest model that clears it. Set QA to a different model.
4. `fos register basedagents --manifest config/agent.manifest.json`; back up `data/keys/`; `fos wallet-message` → sign → `fos wallet-bind`.
5. Read-only live: `MODE=live DRY_RUN=true ENABLED_MARKETPLACES=basedagents`; `fos worker` (or the GitHub Action). 24 h. Review `fos jobs`, REJECT reasons, `data/artifacts/*/patch.diff`.
6. First money: `DRY_RUN=false`; keep approvals for the first 3 jobs (`fos approve KEY`). Caps at defaults.
7. After 10 settled jobs: `fos pnl`, `fos breaker`. Only then raise caps or add TaskBounty.
**Done =** claimed → PR → QA report → accepted → payment with tx reference → outcome row updated.
