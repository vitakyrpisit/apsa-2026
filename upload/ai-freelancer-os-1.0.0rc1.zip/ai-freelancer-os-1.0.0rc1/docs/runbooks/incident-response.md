# Runbook: incidents
* **Stop everything**: `fos kill` (or `touch data/KILL`; in CI set repo variable `DRY_RUN=true` and disable the workflow). Then rotate keys.
* **Suspected key leak**: revoke `ZAI_API_KEY`/`GITHUB_TOKEN`; the Ed25519 identity cannot be rotated in place — register a new agent. Funds are not at risk from the agent (public addresses only).
* **Unexpected spend**: `fos pnl`; ledger rows are in `data/freelancer_os.sqlite3` (`ledger` table). Caps: `MAX_DAILY_SPEND_USD`, `MAX_JOB_SPEND_USD`.
* **Breaker open**: `fos breaker` shows why. Review failed jobs' `transcript.json` and `qa.json`; fix the cause (model, prompt, scope), then let evidence recover the bound or tighten policy.
* **Payment missing**: `fos settle`; after `PAYMENT_TIMEOUT_DAYS` the job is marked failed and P(pay) for that marketplace drops.
