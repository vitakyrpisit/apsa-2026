# What actually pays AI agents (research summary, Oct 2026)

**Evidence quality warning.** Most public material is blogs and self-reported operator logs, some of it promotional. Treat as hypotheses; the agent's own
ledger (`fos pnl`) is the only evidence that matters. Sources consulted: a 160-day / 40+ platform operator field-notes repo, several "platforms where agents earn" comparisons
(May 2026 and earlier), marketplace comparison posts, platform docs/SDKs (BasedAgents, TaskBounty), AI-training/RL-environment pay surveys.

## Findings
1. **The bottleneck is verified demand, not supply.** Operators report many "agent task" boards are fake-demand loops: unfunded buyer posts (one audit: 10/10 unfunded), testnet tokens, referral-recruiting "tasks", wallet-signature traps, KYC walls at payout. → Implemented as `opportunity/trust.py` (hard reject / payment-odds penalty) and "unknown funding ⇒ reject".
2. **Real but saturated:** escrowed micro-bounties on Base (winners verifiably paid; popular tasks draw 100+ submissions for one award; fresh tasks have the only real odds). → Saturation model + age; poll often; claim-first marketplaces (BasedAgents) preferred over open races.
3. **Verifiable code work is the best fit for an autonomous agent**: tests are ground truth, so quality can be proven *before* delivery. Larger coding bounties exist but are claimed within hours and may need vendor hardware (out of scope).
4. **Per-task prices on agent marketplaces are small** ($0.50–$50 typical; $200–$10k on crypto-project bounty boards such as Superteam Earn, which need domain skills we do not claim). Unit economics therefore dominate: LLM cost per job must stay ≈ $0.3–$3.
5. **Human-only data/annotation platforms forbid AI**: excluded. Airdrop farming/trading bots: out of scope (capital, signatures, risk).
6. **Pricing models that work commercially** (outside bounty boards): outcome-based or per-unit-of-verified-work. Our productized SKUs follow that (see `deploy/marketplace/LISTING.md`).
7. **High-paying adjacent lane (not built):** RL-environment / agentic-task authoring pays $200–$2,000 per task (human-expert market, vendor-gated).
   The golden-task framework in `evals/` is reusable for it.

## Where the agent aims, in order
| Lane | Why | Status |
|---|---|---|
| BasedAgents `code` tasks (escrow, exclusive claim, USDC on Base) | funded-and-verifiable demand; no race once claimed | implemented |
| TaskBounty (PR bounties, USDC/ETH/SOL/BTC) | real coding bounties; open race → needs fresh tasks | implemented (needs MCP URL) |
| Productized services on gig marketplaces (fixed-scope, verifiable) | direct demand, better prices than bounties | listing copy provided; integrations are yours (no verified API) |
| Forecasting tournaments, research bounties | real prize pools reported; different verification model | not built — documented as next lane |

## Reality check on income
No guarantee. Expect small absolute amounts at first; the system is built so that it **cannot lose much** (spend caps, breaker) and **learns what works** (posteriors).
Scale only on measured, tx-verified net P&L.
