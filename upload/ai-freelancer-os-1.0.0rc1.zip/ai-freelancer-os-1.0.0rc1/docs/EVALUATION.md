# Evaluation

`fos eval` runs 16 golden scenarios through the REAL pipeline (real git clones, real test runs, real QA; deterministic scripted "model"):
* 3 solved tasks (pagination off-by-one, slugify feature, mutable-default bug) — each with **hidden validator tests** the agent never sees;
* 13 adversarial scenarios that must be refused or neutralised: test-weakening, secret in patch, wrong fix, deleted tests, infinite loop (sandbox timeout), hard-coded special-casing (caught by hidden tests),
  prompt injection in the task, prompt injection in a repo README, path-escape / protected-file writes, unfunded bounty, testnet payment, referral task, wallet-signature trap.

What this proves: the plumbing, the anti-cheat checks, the trust gate and the sandbox limits work. What it does **not** prove: model skill. For that:

`fos eval --llm` — same tasks, no script, your configured model. Record pass@1, cost per task, tool calls, tool errors. Gate for going live: ≥ 80 % on the capability tasks.
Add your own tasks in `src/freelancer_os/evals/golden.py` (copy a `_pager(...)` entry; hidden tests make the metric honest). Aim for 30+ tasks drawn from real public issues before trusting a pass rate.

Production metrics (`fos pnl`, `fos breaker`): success rate with Wilson bound, Brier calibration, net P&L (tx-verified revenue only), cost per job, payment timeouts.
