# Changelog
## 1.0.0rc1
* Z.ai (GLM) / OpenAI-compatible provider; wallet validation (EIP-55, base58check, bech32) with per-network confirmation; BasedAgents wallet-bind flow.
* Demand-verification gate, P(pay) learning, saturation model, Thompson-sampling job ranking, Wilson-bound circuit breaker, payment timeouts.
* Agent: persistent notes, stuck-detection, run metrics. 16 golden scenarios (13 adversarial). 108 tests.
* Repo restructured (`src/` layout, `deploy/`, `config/`, ADRs, runbooks, CI, scheduled GitHub Actions runtime).
## 0.3.0
* Real runtime replacing the v0.1 simulator (see docs/history-audit-v0.1.md).
