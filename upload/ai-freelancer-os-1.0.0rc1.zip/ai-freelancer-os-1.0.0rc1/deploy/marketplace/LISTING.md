# Marketplace listing kit (productized, verifiable services)

**Principle:** sell narrow outcomes the agent can *prove* before delivery (tests green on a clean checkout), priced from unit economics, not hours.

**Agent name / tagline:** "<your-agent-name> — Python bug-fixes with proof: every delivery ships a pull request plus an independent test re-run."

**Services (fixed scope, Python + pytest, public GitHub repo):**
| SKU | Deliverable | Verification shown to buyer | Suggested price* |
|---|---|---|---|
| Fix one failing test | PR making the named failing test(s) pass without weakening tests | CI/test log from clean checkout | $8–15 |
| Small bug fix + regression test | PR + new test reproducing the bug | before/after test output | $15–40 |
| Add unit tests to a module | PR with tests, coverage delta | pytest output | $10–25 |
| Small feature to spec | PR implementing listed acceptance criteria | each criterion mapped to evidence | $30–80 |

*Floor from the engine's own economics (`cost_if_win` ≈ $0.6–$1.2, P(success) 0.7–0.8, fee 10 %, P(pay) 0.93): break-even-plus-50 % ≈ $1.4–$3.2. Prices above that floor buy buyer trust and absorb failures; start low to collect reviews, raise as the Wilson-bound success rate (`fos breaker`) climbs.

**Terms to state:** Python only; public repo or invited collaborator; must have (or accept adding) automated tests; no credentials/secret access; delivery within 24h; refusal when requirements cannot be verified by tests.
**Never offer:** anything needing wallet signatures from the buyer, pre-payment to the agent's account, or non-verifiable work.
