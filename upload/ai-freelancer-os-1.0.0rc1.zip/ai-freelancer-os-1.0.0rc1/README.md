# AI Freelancer OS 1.0.0-rc1

An autonomous agent that earns by completing **verifiable** Python bug-fix / small-feature tasks on paid-bounty marketplaces — and refuses everything else.
Real git → real Docker sandbox → LLM edit/test loop → real tests → independent QA → real PR → tx-verified payment → learning.

> **Status, honestly.** 108 tests + 16 golden scenarios pass (`make test`, `make eval`) and verify the pipeline, git, sandbox limits, QA, trust gate, policy,
> wallet validation, request signing and API parsing against mocked servers. **Not yet proven** (no keys/network/Docker in the build environment): how well *your* model
> solves real tasks (`fos eval --llm`), live marketplace response shapes (`fos doctor --live`), the Docker sandbox on a real host (`fos doctor`), and income.
> There is no income guarantee; the system is designed to *lose little and learn fast*. Read `docs/MARKET_RESEARCH.md` for the realistic picture.

## 10-minute start (free, no keys)
```bash
make install && . .venv/bin/activate
make test && make eval          # all green
fos init && fos wallets         # .env created; your 5 payout addresses are validated
fos doctor                      # lists exactly what is missing for live mode
```

## Go live (details: docs/runbooks/go-live.md)
1. **Wallets** (`docs/WALLETS.md` — read the ⚠ section first: custodial address / Base support / signature proof).
2. `ZAI_API_KEY` (GLM-5.1; see `docs/RUNTIME.md` for why chat.z.ai is the console, not the host) → `fos eval --llm` ≥ 80 %.
3. `fos register basedagents` → `fos wallet-message` → sign → `fos wallet-bind`.
4. Run: GitHub Actions (`.github/workflows/agent-run.yml`, free 24/7 cycle) or `docker compose -f deploy/docker/docker-compose.yml up -d` on a dedicated VM.
5. `MODE=live DRY_RUN=true` for a day → then `DRY_RUN=false` with approvals on the first 3 jobs.

## Layout
```
src/freelancer_os/   marketplaces/ security/ opportunity/ agents/ sandbox/ vcs/ treasury/ storage/ api/ evals/  pipeline.py cli.py config.py
tests/               unit/ e2e/          deploy/   docker/ marketplace/        config/  agent.manifest.json
docs/                ARCHITECTURE MARKET_RESEARCH RUNTIME WALLETS MARKETPLACES EVALUATION adr/ runbooks/ history-audit-v0.1
.github/workflows/   ci.yml agent-run.yml
```

## What makes it commercially viable
* **Narrow, provable product**: it only sells what tests can prove; it says no to the rest (accuracy by scope).
* **Demand verification** before spending a cent (unfunded / testnet / referral / signature-trap / pay-to-enter / attestation-bait ⇒ rejected).
* **Unit-economics engine**: `EV = B·P(win)·P(success)·P(pay)·(1−f) − costs`, probabilities that learn from its own outcomes, Thompson-sampling job choice, Wilson-bound circuit breaker.
* **Bounded loss**: daily/job caps, per-job LLM budget, kill switch, approvals, breaker. **Bounded trust**: no spending keys, validated wallets, operator-confirmed networks.

Commands: `fos init|doctor|wallets|register|wallet-message|wallet-bind|scan|run-once|worker|jobs|show|approve|reject|execute|settle|pnl|breaker|score|eval|kill|resume|serve`.
See `docs/ARCHITECTURE.md`, `SECURITY.md`, `CONTRIBUTING.md`.
