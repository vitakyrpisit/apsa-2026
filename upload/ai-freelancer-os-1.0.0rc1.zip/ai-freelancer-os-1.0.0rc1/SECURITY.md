# Security

## Reporting
Open a private security advisory on the repository. Do not post exploits publicly.

## Threat model & controls
* **Untrusted input**: job text, repo files, test output. Quoted as `<untrusted_*>` data; firewall tripwire blocks hijacks; repo content that tries to instruct the agent is withheld and logged.
* **Capabilities are the real defence**: jailed tools (no `.git`, no symlink escape, protected CI/secret paths), no shell, no network, no env, no payment tools; tests run in Docker with `--network none`, `--cap-drop ALL`, no-new-privileges, non-root, memory/CPU/pids limits, scrubbed environment.
* **Secrets**: never mounted into the sandbox; redacted from transcripts; QA fails any patch adding key-like strings. Wallets are public addresses; the agent identity key (Ed25519) only signs marketplace requests. In CI it lives in an Actions secret.
* **Anti-cheating**: QA fails deleted tests, removed assertions, skip/xfail/`assert True`, protected-file edits, oversized patches; tests re-run on a clean checkout with validator tests.
* **Money**: daily/job caps, per-job LLM budget enforced after every call, kill switch (`fos kill` / `touch data/KILL`), approval for first N live jobs and large budgets, circuit breaker, revenue counted only with tx reference, wallet networks must be operator-confirmed.
* **Demand fraud**: unfunded/testnet/referral/signature-trap/pay-to-enter/attestation-bait jobs are rejected before any spend.

## Residual risks
Pattern firewall is bypassable; Docker escapes (patch Docker, dedicated VM, consider gVisor/Firecracker); `docker.sock` mount is root-equivalent; LLM QA can be fooled (it only downgrades); marketplace response drift; a custodial payout address that cannot receive the paid network.
Supply chain: pin dependencies in production (`pip-compile`), review `basedagents` SDK updates.
