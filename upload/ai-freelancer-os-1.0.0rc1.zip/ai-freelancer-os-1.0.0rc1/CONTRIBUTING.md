# Contributing
* Python ≥ 3.11, `make install`, `make lint`, `make test`, `make eval` must pass (CI enforces).
* Every behavioural change needs a test; every new failure mode needs a golden scenario in `evals/golden.py`.
* Never add a feature that holds spending keys, disables the sandbox, or lets the agent grade its own work. Propose an ADR for architectural changes (`docs/adr/`).
* Code, comments, docs, commit messages: English. Conventional commits (`feat:`, `fix:`, `docs:`, `test:`).
