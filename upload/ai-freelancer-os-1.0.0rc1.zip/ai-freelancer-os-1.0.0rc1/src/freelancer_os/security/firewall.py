"""Prompt-injection screening + secret redaction.

Honest note: pattern matching is a *tripwire*, not the defence. The real defences are
capability limits: the coding agent has no secrets, no network, no payment tools, a
path-jailed workspace and every piece of third-party text is passed as quoted DATA.
(The v0.1 firewall had a bug: every `\\s` lost its backslash, so it matched nothing.)
"""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field

_ZERO_WIDTH = dict.fromkeys(map(ord, "\u200b\u200c\u200d\u2060\ufeff\u202a\u202b\u202c\u202d\u202e\u2066\u2067\u2068\u2069"), None)

# (category, severity, regex)
_PATTERNS: list[tuple[str, str, re.Pattern[str]]] = [
    ("instruction_override", "high", re.compile(r"\b(ignore|disregard|forget|override)\s+(all\s+|any\s+|the\s+|your\s+)?(previous|prior|above|earlier|system|developer)\s+(instructions?|prompts?|rules?|messages?)", re.I)),
    ("instruction_override", "high", re.compile(r"\b(new|updated)\s+(system\s+)?instructions?\s*[:\-]", re.I)),
    ("role_spoof", "medium", re.compile(r"(^|\n)\s*(system|assistant|developer)\s*:\s", re.I)),
    ("role_spoof", "medium", re.compile(r"</?\s*(system|instructions?|untrusted_[a-z_]+)\s*>", re.I)),
    ("role_spoof", "medium", re.compile(r"\byou\s+are\s+now\s+(a|an|in)\b", re.I)),
    ("secret_exfil", "high", re.compile(r"\b(reveal|print|show|export|send|post|upload|cat|echo|dump|leak|exfiltrate)\b[^\n]{0,60}\b(api[_\s-]?keys?|secrets?|passwords?|credentials?|tokens?|private[_\s-]?keys?|seed\s+phrase|mnemonic|\.env|environment\s+variables?|vault)\b", re.I)),
    ("secret_exfil", "high", re.compile(r"\b(printenv|os\.environ|process\.env)\b[^\n]{0,40}(curl|http|nc\s|requests\.)", re.I)),
    ("funds_transfer", "high", re.compile(r"\b(transfer|send|withdraw|move|wire)\b[^\n]{0,40}\b(usdc|usdt|eth|btc|sol|funds|crypto|tokens?|wallet)\b", re.I)),
    ("funds_transfer", "high", re.compile(r"\b0x[a-fA-F0-9]{40}\b[^\n]{0,80}\b(send|transfer|pay)\b|\b(send|transfer|pay)\b[^\n]{0,80}\b0x[a-fA-F0-9]{40}\b", re.I)),
    ("remote_exec", "high", re.compile(r"(curl|wget)\s+[^\n|]*\|\s*(sudo\s+)?(ba)?sh\b", re.I)),
    ("tool_hijack", "medium", re.compile(r"\b(disable|turn\s+off|bypass|skip)\s+(the\s+)?(tests?|qa|review|sandbox|firewall|safety|security|checks?)\b", re.I)),
    ("tool_hijack", "medium", re.compile(r"\b(mark|report|say)\b[^\n]{0,30}\b(tests?|qa|task)\b[^\n]{0,20}\b(passed|passing|complete|done|successful)\b[^\n]{0,30}\b(regardless|anyway|without)\b", re.I)),
]

_LONG_B64 = re.compile(r"[A-Za-z0-9+/]{200,}={0,2}")


@dataclass
class Finding:
    category: str
    severity: str
    excerpt: str


@dataclass
class ScanResult:
    findings: list[Finding] = field(default_factory=list)

    @property
    def blocked(self) -> bool:
        return any(f.severity == "high" for f in self.findings)

    @property
    def suspicious(self) -> bool:
        return bool(self.findings)

    def summary(self) -> str:
        return "; ".join(f"{f.category}/{f.severity}: {f.excerpt!r}" for f in self.findings[:5])


def normalize(text: str) -> str:
    text = unicodedata.normalize("NFKC", text or "")
    text = text.translate(_ZERO_WIDTH)
    return text


def scan(text: str) -> ScanResult:
    """Scan untrusted text. Returns findings; `.blocked` means do not process the job."""
    norm = normalize(text)
    res = ScanResult()
    for cat, sev, rx in _PATTERNS:
        m = rx.search(norm)
        if m:
            s = max(0, m.start() - 20)
            res.findings.append(Finding(cat, sev, norm[s : m.end() + 20].replace("\n", " ")[:160]))
    if _LONG_B64.search(norm):
        res.findings.append(Finding("encoded_payload", "medium", "long base64-like blob"))
    return res


def wrap_untrusted(label: str, text: str, limit: int = 12000) -> str:
    """Quote third-party text so the model treats it as data. Strips fake closing tags."""
    body = normalize(text)[:limit]
    body = re.sub(r"</?\s*untrusted[^>]*>", "[tag removed]", body, flags=re.I)
    return f'<untrusted_{label}>\n{body}\n</untrusted_{label}>'


# ---------------------------------------------------------------- redaction
_SECRET_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("anthropic_key", re.compile(r"sk-ant-[A-Za-z0-9_\-]{20,}")),
    ("openai_key", re.compile(r"sk-[A-Za-z0-9]{32,}")),
    ("google_key", re.compile(r"AIza[0-9A-Za-z_\-]{30,}")),
    ("github_token", re.compile(r"\b(ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{30,}\b|github_pat_[A-Za-z0-9_]{40,}")),
    ("taskbounty_key", re.compile(r"\btb_live_[A-Za-z0-9]{8,}")),
    ("aws_key", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("private_key_block", re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")),
    ("slack_token", re.compile(r"\bxox[abprs]-[A-Za-z0-9-]{10,}")),
    ("hex_private_key", re.compile(r"(?i)(private[_-]?key|secret|seed)[\"'\s:=]+(0x)?[0-9a-f]{64}\b")),
]


def find_secrets(text: str) -> list[str]:
    return [name for name, rx in _SECRET_PATTERNS if rx.search(text or "")]


def redact(text: str, extra_secrets: list[str] | None = None) -> str:
    out = text or ""
    for name, rx in _SECRET_PATTERNS:
        out = rx.sub(f"[REDACTED:{name}]", out)
    for s in extra_secrets or []:
        if s and len(s) >= 8:
            out = out.replace(s, "[REDACTED:configured_secret]")
    return out
