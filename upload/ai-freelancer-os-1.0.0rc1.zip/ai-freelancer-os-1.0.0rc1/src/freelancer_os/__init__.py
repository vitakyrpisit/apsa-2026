"""AI Freelancer OS — real agent runtime (v0.3)."""
__version__ = "0.3.0"
