"""Demand-verification gate.

Field reports from operators who ran agents against 40+ "agent marketplaces" for months (self-reported, so treated as
heuristics, not facts) converge on the same failure modes: unfunded buyer posts, testnet tokens, referral-recruiting
"tasks", signature/wallet-connect traps, pay-to-enter, model-attestation bait, requesters with no settlement history,
and saturated tasks (100+ submissions for one award). The bottleneck is VERIFIED demand, not supply. This module turns
that checklist into code: hard flags reject, soft flags reduce the probability that we will actually be paid.
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field

from freelancer_os.domain import Job
from freelancer_os.security.firewall import normalize

TESTNETS = {"eip155:84532", "eip155:11155111", "eip155:421614", "eip155:80002", "eip155:97", "eip155:5", "solana:devnet", "solana:testnet"}
MAINNETS = {"eip155:8453", "eip155:1", "eip155:42161", "eip155:10", "eip155:137", "solana:mainnet"}
REAL_TOKENS = {"USDC", "USDT", "DAI", "ETH", "SOL", "BTC", "TRX"}

_HARD = [
    ("referral_task", re.compile(r"\b(refer(ral)?s?|invite|recruit|onboard)\b[^\n]{0,50}\b(agents?|friends?|users?|members?)\b|\breferral\s+(bounty|code|link|reward)", re.I)),
    ("wallet_signature_trap", re.compile(r"\b(connect|link)\s+(your\s+)?wallet\b|\bsign\s+(this|the|a)\s+(message|transaction|permit|approval|typed)|\bapprove\s+(the\s+)?(spend|token|allowance)|setApprovalForAll|\beth_sign\b|\bpermit\s*\(", re.I)),
    ("pay_to_enter", re.compile(r"\b(deposit|stake|pay|buy|purchase)\b[^\n]{0,30}\b(to\s+(enter|participate|apply|unlock|claim)|entry\s+fee|registration\s+fee|bond)\b", re.I)),
    ("attestation_bait", re.compile(r"\b(prove|attest|certify)\b[^\n]{0,40}\b(which\s+model|model\s+(used|name)|human|not\s+ai|written\s+by)\b|\bhuman[\s-]only\b|\bno\s+ai\b|\bmust\s+not\s+(be|use)\s+ai\b|\bai[\s-]generated\b[^\n]{0,20}\b(forbidden|prohibited|banned|not\s+allowed)", re.I)),
    ("cashback_trap", re.compile(r"\b(first\s+task|welcome)\b[^\n]{0,30}\b(pays?\s+back|cash\s*back|refund)\b", re.I)),
]
_SOFT = [
    ("payout_wall", re.compile(r"\bKYC\b|\btax\s+form\b|\bW-?[89]\b|\bbank\s+(account|transfer|details)\b|\bpaypal\b", re.I), 0.80),
    ("vague_reward", re.compile(r"\b(tbd|to\s+be\s+determined|negotiable|exposure|equity|revenue\s+share|future\s+(rewards?|airdrops?))\b", re.I), 0.60),
]


@dataclass
class TrustReport:
    hard: list[str] = field(default_factory=list)
    soft: list[str] = field(default_factory=list)
    p_pay_mult: float = 1.0          # multiplies P(we get paid | we deliver accepted work)

    @property
    def rejected(self) -> bool:
        return bool(self.hard)


def assess(job: Job, *, requires_funding: bool = True) -> TrustReport:
    text = normalize(job.title + "\n" + job.description + "\n" + "\n".join(job.acceptance_criteria))
    rep = TrustReport()
    for name, rx in _HARD:
        if rx.search(text):
            rep.hard.append(name)
    for name, rx, mult in _SOFT:
        if rx.search(text):
            rep.soft.append(name)
            rep.p_pay_mult *= mult
    if job.network:
        if job.network in TESTNETS:
            rep.hard.append(f"testnet_payment:{job.network}")
        elif job.network not in MAINNETS:
            rep.soft.append(f"unrecognised_network:{job.network}")
            rep.p_pay_mult *= 0.7
    if job.token and job.token.upper() not in REAL_TOKENS:
        rep.hard.append(f"unrecognised_token:{job.token}")      # could be a worthless contract: resolve it before ever accepting
    if job.requester_settled is not None and job.requester_settled == 0 and job.budget_usd > 25:
        rep.soft.append("requester_has_no_settlement_history")
        rep.p_pay_mult *= 0.6
    return rep


def p_pay_prior(job: Job, caps_requires_funding: bool) -> float:
    """Prior probability we are paid given accepted work: escrow-confirmed >> unknown."""
    if job.funded is True:
        base = 0.93
    elif job.funded is None:
        base = 0.55
    else:
        base = 0.15
    if job.requester_settled is not None and job.requester_settled > 0:
        base = min(0.97, base + 0.04 * min(3, job.requester_settled))
    return base


def expected_competitors(job: Job) -> float:
    """Saturation model for open-race bounties: submissions accumulate with age; fresh tasks have odds."""
    n = job.competition
    if n is not None:
        return float(n)
    age = job.age_hours if job.age_hours is not None else 24.0
    return 2.0 + 4.0 * (age / 24.0)


def p_win_open_race(competitors: float) -> float:
    """Uniform-ish award among comparably capable submissions, discounted for a stronger-than-average field."""
    return 1.0 / (1.0 + competitors * 1.1)


def wilson_lower(successes: int, n: int, z: float = 1.645) -> float:
    """Lower bound of the Wilson score interval (95% one-sided): honest success rate for small samples."""
    if n <= 0:
        return 0.0
    p = successes / n
    d = 1 + z * z / n
    centre = p + z * z / (2 * n)
    margin = z * math.sqrt((p * (1 - p) + z * z / (4 * n)) / n)
    return max(0.0, (centre - margin) / d)
