"""Thompson sampling over candidate jobs.

Point estimates always exploit what we already believe. Sampling p(success) from its Beta posterior makes the agent
occasionally try lanes with little data (exploration) and exploit proven lanes the rest of the time, with the
exploration rate shrinking automatically as evidence accumulates. Deterministic under a seeded RNG for tests.
"""
from __future__ import annotations

import random
from decimal import Decimal

from freelancer_os.domain import Job, Score
from freelancer_os.opportunity.engine import PRIOR_STRENGTH, OpportunityEngine, skill_bucket


def posterior(engine: OpportunityEngine, job: Job, score: Score) -> tuple[float, float]:
    prior = float(score.features.get("prior_p_success", score.p_success))
    st = engine.db.outcome_stats(marketplace=job.marketplace, bucket=skill_bucket(job, engine.s))
    a = PRIOR_STRENGTH * prior + st["successes"]
    b = PRIOR_STRENGTH * (1 - prior) + (st["n_done"] - st["successes"])
    return max(a, 1e-3), max(b, 1e-3)


def sampled_value_per_hour(engine: OpportunityEngine, job: Job, score: Score, rng: random.Random, fee: Decimal) -> float:
    a, b = posterior(engine, job, score)
    p = rng.betavariate(a, b)
    p_pay = float(score.features.get("p_pay", 0.9))
    revenue = float(job.budget_usd) * score.p_win * p * p_pay * (1 - float(fee))
    return (revenue - float(score.expected_cost)) / max(score.expected_hours, 0.25)


def rank(engine: OpportunityEngine, candidates: list[tuple[Job, Score, Decimal]], seed: int | None = None) -> list[tuple[Job, Score, Decimal]]:
    rng = random.Random(seed)
    scored = [(sampled_value_per_hour(engine, j, s, rng, fee), (j, s, fee)) for j, s, fee in candidates]
    scored.sort(key=lambda t: t[0], reverse=True)
    return [c for _, c in scored]
