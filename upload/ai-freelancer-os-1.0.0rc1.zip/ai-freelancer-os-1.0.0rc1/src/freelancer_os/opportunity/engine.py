"""Opportunity engine: expected-profit scoring with probabilities that LEARN from real outcomes.

Nothing here is a magic constant presented as fact. Every probability starts as a transparent
prior computed from observable features, then is blended with the agent's own history using a
Beta posterior (prior strength K). Once outcomes accumulate, data dominates the prior.
"""
from __future__ import annotations

import re
from decimal import Decimal
from typing import Any

from freelancer_os.config import Settings
from freelancer_os.domain import Decision, Job, Score
from freelancer_os.marketplaces.base import Capabilities
from freelancer_os.opportunity import trust
from freelancer_os.opportunity.health import CircuitBreaker
from freelancer_os.security.firewall import scan
from freelancer_os.storage.db import Database

PRIOR_STRENGTH = 8.0       # K: a prior is worth ~8 observations
P_SUCCESS_CAP = 0.92
MIN_HOURS = 0.25
# Prior cost model (USD) used until the agent has real cost history for a complexity level.
PRIOR_LLM_COST = {1: 0.30, 2: 0.60, 3: 1.20, 4: 2.20, 5: 3.50}
PRIOR_SANDBOX_COST = 0.05
PRIOR_HOURS = {1: 0.3, 2: 0.6, 3: 1.2, 4: 2.5, 5: 5.0}
CLAIM_PROBE_COST = 0.02    # cloning + baseline tests

_CODE_HINTS = re.compile(r"(traceback|exception|error|failing|test|pytest|expected|actual|reproduce|steps to|def |class |\.py\b)", re.I)


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def skill_bucket(job: Job, settings: Settings) -> str:
    prof = settings.proficiency_map()
    known = [s.lower() for s in job.skills if s.lower() in prof]
    return known[0] if known else "unknown"


def skill_match(job: Job, settings: Settings) -> tuple[float, list[str]]:
    langs, prof = settings.languages(), settings.proficiency_map()
    skills = [s.lower() for s in job.skills]
    reasons: list[str] = []
    if not skills:
        return 0.45, ["no skills listed: neutral skill match"]
    lang_skills = [s for s in skills if s in {"python", "javascript", "typescript", "java", "go", "rust", "c++", "c#", "ruby", "php", "kotlin", "swift", "solidity"}]
    if lang_skills and not any(s in langs for s in lang_skills):
        return 0.0, [f"unsupported language(s): {', '.join(lang_skills)}"]
    vals = [prof.get(s, 0.15) for s in skills]
    unknown = [s for s in skills if s not in prof]
    if unknown:
        reasons.append(f"unfamiliar skills: {', '.join(unknown[:5])}")
    # weakest-link weighted: one missing core skill hurts more than the mean suggests
    sm = 0.6 * (sum(vals) / len(vals)) + 0.4 * min(vals)
    return clamp(sm), reasons


def clarity(job: Job) -> float:
    c = 0.0
    c += 0.35 if job.acceptance_criteria else 0.0
    n = len(job.description)
    c += 0.25 if n >= 300 else 0.15 if n >= 120 else 0.0
    c += 0.2 if _CODE_HINTS.search(job.description) else 0.0
    c += 0.1 if job.repo_url else 0.0
    c += 0.1 if len(job.title) >= 12 else 0.0
    return clamp(c)


def beta_blend(prior: float, successes: int, n: int, k: float = PRIOR_STRENGTH) -> float:
    return (k * prior + successes) / (k + n) if n >= 0 else prior


class OpportunityEngine:
    def __init__(self, settings: Settings, db: Database):
        self.s, self.db = settings, db

    # ------------------------------------------------------------------ estimates
    def estimate_complexity(self, job: Job, plan_complexity: int | None = None) -> int:
        if plan_complexity:
            return max(1, min(5, plan_complexity))
        n = len(job.description) + 40 * len(job.acceptance_criteria)
        return 1 if n < 250 else 2 if n < 600 else 3 if n < 1400 else 4 if n < 3000 else 5

    def p_success(self, job: Job, *, complexity: int, testability: float | None, repo_health: float | None, hours: float) -> tuple[float, dict[str, Any]]:
        sm, _ = skill_match(job, self.s)
        bucket = skill_bucket(job, self.s)
        st = self.db.outcome_stats(bucket=bucket)
        hist_prior = beta_blend(0.5, st["successes"], st["n_done"], 4.0)   # skill track record, 0.5 until data
        cl = clarity(job)
        t = 0.5 if testability is None else testability
        rh = 0.5 if repo_health is None else repo_health
        margin = 1.0 if not job.deadline_hours else clamp((job.deadline_hours / max(hours, MIN_HOURS) - 1.0) / 3.0)
        raw = 0.30 * sm + 0.20 * hist_prior + 0.15 * cl + 0.12 * rh + 0.13 * t + 0.10 * margin
        raw *= {1: 1.0, 2: 0.97, 3: 0.92, 4: 0.82, 5: 0.7}[complexity]
        prior = clamp(0.05 + 0.9 * raw, 0.02, P_SUCCESS_CAP)
        done = self.db.outcome_stats(marketplace=job.marketplace, bucket=bucket)
        p = clamp(beta_blend(prior, done["successes"], done["n_done"]), 0.02, P_SUCCESS_CAP)
        return p, {"skill_match": round(sm, 3), "history_prior": round(hist_prior, 3), "clarity": round(cl, 3), "testability": round(t, 3),
                   "repo_health": round(rh, 3), "time_margin": round(margin, 3), "prior_p_success": round(prior, 3),
                   "n_history": done["n_done"], "complexity": complexity}

    def p_win(self, job: Job, caps: Capabilities) -> tuple[float, dict[str, Any]]:
        comp = job.competition
        if caps.win_model == "exclusive_claim":
            prior = 0.9 if job.funded else 0.5
        elif caps.win_model == "open_race":
            prior = clamp(trust.p_win_open_race(trust.expected_competitors(job)), 0.02, 0.8)
        else:  # proposal / bid
            prior = clamp(1.0 / (2.0 + (comp if comp is not None else 12) * 0.5), 0.03, 0.4)
        st = self.db.outcome_stats(marketplace=job.marketplace)
        p = clamp(beta_blend(prior, st["wins"], st["n_won_known"]), 0.02, 0.97)
        return p, {"win_model": caps.win_model, "prior_p_win": round(prior, 3), "n_history": st["n_won_known"]}

    def p_pay(self, job: Job, caps: Capabilities, mult: float) -> tuple[float, dict[str, Any]]:
        prior = trust.p_pay_prior(job, caps.requires_funding) * mult
        st = self.db.paid_stats(job.marketplace)
        p = clamp(beta_blend(prior, st["paid"], st["n"], 6.0), 0.02, 0.98)
        return p, {"prior_p_pay": round(prior, 3), "n_pay_history": st["n"]}

    def cost_model(self, job: Job, complexity: int) -> tuple[Decimal, float]:
        st = self.db.outcome_stats(marketplace=job.marketplace)
        if st["median_cost"] is not None and st["n_done"] >= 3:
            cost = Decimal(st["median_cost"]) * Decimal(str(1 + 0.25 * (complexity - 3)))
        else:
            cost = Decimal(str(PRIOR_LLM_COST[complexity] + PRIOR_SANDBOX_COST))
        hours = st["median_hours"] if st["median_hours"] and st["n_done"] >= 3 else PRIOR_HOURS[complexity]
        return max(cost, Decimal("0.05")), float(hours)

    # ---------------------------------------------------------------------- score
    def score(self, job: Job, caps: Capabilities, *, stage: str = "pre", plan_complexity: int | None = None,
              testability: float | None = None, repo_health: float | None = None, est_hours: float | None = None) -> Score:
        reasons: list[str] = []
        complexity = self.estimate_complexity(job, plan_complexity)
        cost_if_win, hours = self.cost_model(job, complexity)
        if est_hours:
            hours = max(hours * 0.5, est_hours) if stage == "post" else hours
        sm, sm_reasons = skill_match(job, self.s)
        reasons += sm_reasons
        ps, psf = self.p_success(job, complexity=complexity, testability=testability, repo_health=repo_health, hours=hours)
        pw, pwf = self.p_win(job, caps)
        tr = trust.assess(job, requires_funding=caps.requires_funding)
        pp, ppf = self.p_pay(job, caps, tr.p_pay_mult)
        fee = caps.platform_fee_rate
        gross = job.budget_usd
        revenue = gross * Decimal(str(pw)) * Decimal(str(ps)) * Decimal(str(pp)) * (Decimal(1) - fee)
        # cost is incurred whenever we win and start working (success or not); the probe is always paid
        exp_cost = cost_if_win * Decimal(str(pw)) + Decimal(str(CLAIM_PROBE_COST))
        profit = revenue - exp_cost
        pph = profit / Decimal(str(max(hours, MIN_HOURS)))
        decision = self._decide(job, caps, sm, ps, profit, exp_cost, cost_if_win, hours, reasons, stage, tr)
        feats = {**psf, **pwf, **ppf, "p_pay": round(pp, 3), "trust_soft": tr.soft, "fee_rate": float(fee), "cost_if_win": float(cost_if_win)}
        q = lambda d: d.quantize(Decimal("0.01"))
        return Score(stage=stage, skill_match=round(sm, 3), p_success=round(ps, 3), p_win=round(pw, 3), expected_revenue=q(revenue),
                     expected_cost=q(exp_cost), expected_profit=q(profit), expected_hours=round(hours, 2), profit_per_hour=q(pph),
                     decision=decision, reasons=reasons, features=feats)

    # --------------------------------------------------------------------- policy
    def _decide(self, job, caps, sm, ps, profit, exp_cost, cost_if_win, hours, reasons: list[str], stage: str, tr) -> Decision:
        s = self.s
        rej: list[str] = []
        sec = scan(job.title + "\n" + job.description + "\n" + "\n".join(job.acceptance_criteria))
        if sec.blocked:
            rej.append(f"security firewall: {sec.summary()}")
        if tr.rejected:
            rej.append("demand-verification gate: " + ", ".join(tr.hard))
        if tr.soft:
            reasons.append("trust warnings (payment odds reduced): " + ", ".join(tr.soft))
        if not job.repo_url and "repo" in caps.requires:
            rej.append("no repository URL")
        if caps.requires_funding and job.funded is not True:
            rej.append("bounty is not confirmed as funded/escrowed" if job.funded is None else "bounty is not funded")
        if sm <= 0.0:
            rej.append("outside supported skills")
        if job.budget_usd < s.min_budget_usd:
            rej.append(f"budget ${job.budget_usd} below minimum ${s.min_budget_usd}")
        if cost_if_win > s.max_job_spend_usd:
            rej.append(f"estimated cost ${cost_if_win:.2f} exceeds per-job cap ${s.max_job_spend_usd}")
        if self.db.spend_today() + cost_if_win > s.max_daily_spend_usd:
            rej.append("daily spend cap would be exceeded")
        if job.deadline_hours is not None and job.deadline_hours < hours * 1.5:
            rej.append(f"deadline {job.deadline_hours}h too tight for ~{hours:.1f}h of work")
        if ps < s.min_p_success_hard:
            rej.append(f"P(success)={ps:.2f} below hard floor {s.min_p_success_hard}")
        if profit < s.min_expected_profit_usd:
            rej.append(f"expected profit ${profit:.2f} below minimum ${s.min_expected_profit_usd}")
        elif exp_cost > 0 and profit / exp_cost < s.min_roi:
            rej.append(f"ROI {float(profit / exp_cost):.1f}x below minimum {s.min_roi}x")
        if rej:
            reasons += rej
            return Decision.REJECT
        approval: list[str] = []
        if caps.requires_human_approval:
            approval.append("marketplace requires human approval for binding actions")
        if job.budget_usd > s.human_approval_threshold_usd:
            approval.append(f"budget above ${s.human_approval_threshold_usd} approval threshold")
        if ps < s.min_p_success_auto:
            approval.append(f"P(success)={ps:.2f} below auto threshold {s.min_p_success_auto}")
        br = CircuitBreaker(s, self.db).status()
        if br.open:
            approval.append(f"circuit breaker OPEN: {br.reason}")
        if s.mode == "live" and self.db.count_state_done() < s.first_n_jobs_require_approval:
            approval.append(f"first {s.first_n_jobs_require_approval} live jobs require approval")
        if approval:
            reasons += approval
            return Decision.HUMAN_APPROVAL
        reasons.append("meets all auto-claim criteria")
        return Decision.CLAIM

    def calibration_report(self) -> dict[str, Any]:
        st = self.db.outcome_stats()
        return {"completed_jobs": st["n_done"], "successes": st["successes"], "brier_score": st["brier"],
                "note": "Brier < 0.25 beats a coin flip; needs >= 20 completed jobs to be meaningful."}
