"""Circuit breaker: an agent that loses money must stop deciding alone. Pure statistics, no vibes."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from decimal import Decimal

from freelancer_os.config import Settings
from freelancer_os.opportunity.trust import wilson_lower
from freelancer_os.storage.db import Database


@dataclass
class BreakerStatus:
    open: bool
    reason: str
    n: int
    success_rate: float
    lower_bound: float
    net_30d_usd: Decimal


class CircuitBreaker:
    def __init__(self, settings: Settings, db: Database):
        self.s, self.db = settings, db

    def status(self) -> BreakerStatus:
        rows = self.db.q("SELECT succeeded FROM outcomes WHERE succeeded IS NOT NULL ORDER BY id DESC LIMIT ?", (self.s.breaker_window,))
        n, k = len(rows), sum(r["succeeded"] for r in rows)
        lb = wilson_lower(k, n)
        since = datetime.now(timezone.utc) - timedelta(days=30)
        net = (self.db.ledger_sum(("payment_in",), since=since)
               - self.db.ledger_sum(("llm_cost", "sandbox_cost", "other_cost"), since=since))
        reason = ""
        if n >= self.s.breaker_min_jobs and lb < self.s.breaker_min_lower_bound:
            reason = f"success rate {k}/{n} (95% lower bound {lb:.2f}) below {self.s.breaker_min_lower_bound}"
        elif net < -self.s.breaker_max_net_loss_usd:
            reason = f"30-day net P&L ${net:.2f} below -${self.s.breaker_max_net_loss_usd}"
        return BreakerStatus(bool(reason), reason, n, (k / n) if n else 0.0, lb, net)
