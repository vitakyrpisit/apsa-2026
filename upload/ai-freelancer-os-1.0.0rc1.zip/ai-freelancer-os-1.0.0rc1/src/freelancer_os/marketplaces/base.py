from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Literal

from freelancer_os.domain import ClaimResult, Delivery, Job, PaymentStatus


class MarketplaceError(RuntimeError):
    def __init__(self, msg: str, *, status: int | None = None, code: str | None = None, retryable: bool = False):
        super().__init__(msg)
        self.status, self.code, self.retryable = status, code, retryable


class NotImplementedMarketplace(MarketplaceError):
    pass


@dataclass(frozen=True)
class Capabilities:
    win_model: Literal["exclusive_claim", "open_race", "proposal"]
    platform_fee_rate: Decimal
    payment_rail: str
    requires_funding: bool = True            # reject jobs not confirmed as funded/escrowed
    requires_human_approval: bool = False    # binding actions need a human (e.g. Upwork)
    requires: frozenset[str] = field(default_factory=lambda: frozenset({"repo"}))
    fee_verified: bool = False               # True only when confirmed from official docs


class MarketplaceAdapter(ABC):
    id: str
    capabilities: Capabilities

    @abstractmethod
    async def discover(self, limit: int = 30) -> list[Job]: ...

    @abstractmethod
    async def get_job(self, external_id: str) -> Job: ...

    @abstractmethod
    async def claim(self, job: Job) -> ClaimResult: ...

    @abstractmethod
    async def deliver(self, job: Job, delivery: Delivery) -> str: ...

    @abstractmethod
    async def payment_status(self, job: Job) -> PaymentStatus: ...

    async def doctor(self) -> list[tuple[str, bool, str]]:
        """Connectivity/contract self-check used by `fos doctor`."""
        return [(f"{self.id}: doctor", True, "no checks implemented")]

    async def aclose(self) -> None:
        return None


class PlannedAdapter(MarketplaceAdapter):
    """Honest placeholder: registered but refuses to operate until a real integration exists."""
    reason = "integration not implemented"

    def __init__(self, id: str, reason: str, human: bool = False, fee: str = "0.10"):
        self.id, self.reason = id, reason
        self.capabilities = Capabilities("proposal" if human else "exclusive_claim", Decimal(fee), "unknown", requires_human_approval=human)

    def _no(self):
        raise NotImplementedMarketplace(f"{self.id}: {self.reason}")

    async def discover(self, limit=30): self._no()
    async def get_job(self, external_id): self._no()
    async def claim(self, job): self._no()
    async def deliver(self, job, delivery): self._no()
    async def payment_status(self, job): self._no()

    async def doctor(self):
        return [(f"{self.id}", False, self.reason)]
