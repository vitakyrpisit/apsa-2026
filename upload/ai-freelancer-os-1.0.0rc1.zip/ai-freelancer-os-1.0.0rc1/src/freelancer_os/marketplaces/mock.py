"""In-memory marketplace for offline end-to-end runs and evals. Clearly NOT real money."""
from __future__ import annotations

from decimal import Decimal
from typing import Callable

from freelancer_os.domain import ClaimResult, Delivery, Job, PaymentStatus
from freelancer_os.marketplaces.base import Capabilities, MarketplaceAdapter, MarketplaceError


class MockMarketplace(MarketplaceAdapter):
    id = "mock"
    capabilities = Capabilities("exclusive_claim", Decimal("0.10"), "mock", requires_funding=True, fee_verified=True)

    def __init__(self, jobs: list[Job] | None = None, accept: Callable[[Job, Delivery], bool] | None = None):
        self.jobs = {j.external_id: j for j in (jobs or [])}
        self.claimed: dict[str, str] = {}
        self.deliveries: dict[str, Delivery] = {}
        self.accept = accept or (lambda job, d: d.qa.passed)

    def add(self, job: Job) -> None:
        job.marketplace = "mock"
        self.jobs[job.external_id] = job

    async def discover(self, limit: int = 30) -> list[Job]:
        return [j for j in self.jobs.values() if j.external_id not in self.claimed][:limit]

    async def get_job(self, external_id: str) -> Job:
        if external_id not in self.jobs:
            raise MarketplaceError("not found", status=404)
        return self.jobs[external_id]

    async def claim(self, job: Job) -> ClaimResult:
        if job.external_id in self.claimed:
            return ClaimResult(ok=False, reason="already claimed", retryable=False)
        self.claimed[job.external_id] = "mock-agent"
        return ClaimResult(ok=True, claim_id=f"mock-claim-{job.external_id}")

    async def deliver(self, job: Job, delivery: Delivery) -> str:
        self.deliveries[job.external_id] = delivery
        return f"mock-delivery-{job.external_id}"

    async def payment_status(self, job: Job) -> PaymentStatus:
        d = self.deliveries.get(job.external_id)
        if d and self.accept(job, d):
            return PaymentStatus(settled=True, amount_usd=job.budget_usd * (Decimal(1) - self.capabilities.platform_fee_rate),
                                 tx_ref=f"mock-tx-{job.external_id}", state="accepted")
        return PaymentStatus(settled=False, state="pending" if d else "not_delivered")
