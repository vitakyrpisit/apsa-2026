"""BasedAgents adapter (https://basedagents.ai) — AgentSig-signed REST, USDC escrow on Base.

Contract taken from the official `basedagents` Python SDK (v0.5.x): Ed25519 keypair, requests signed as
  Authorization: AgentSig <b58 pubkey>:<b64 sig>, X-Timestamp, X-Nonce
  signed message = "<METHOD>:<path>:<ts>:<sha256(body)>:<nonce>"
Task lifecycle: GET /v1/tasks -> POST /v1/tasks/{id}/claim (7 days to deliver) -> POST .../deliver -> buyer accepts -> x402 settlement.
Response shapes are parsed defensively; run `fos doctor --live` to verify against the live API.
"""
from __future__ import annotations

import json
import re
from datetime import datetime
from decimal import Decimal
from pathlib import Path
from typing import Any

import httpx

from freelancer_os.domain import ClaimResult, Delivery, Job, PaymentStatus
from freelancer_os.marketplaces.base import Capabilities, MarketplaceAdapter, MarketplaceError

_GH = re.compile(r"https://github\.com/[A-Za-z0-9_.\-]+/[A-Za-z0-9_.\-]+")
_AC_LINE = re.compile(r"^\s*(?:[-*]\s*(?:\[[ xX]\]\s*)?|\d+[.)]\s*|AC\d+[:.)]\s*)(.+)$")


def atomic_to_usd(amount: str | int | None) -> Decimal:
    try:
        return Decimal(str(amount)) / Decimal(1_000_000)
    except Exception:  # noqa: BLE001
        return Decimal(0)


def extract_criteria(description: str, expected_output: str | None) -> list[str]:
    out: list[str] = []
    in_ac = False
    for line in (description or "").splitlines():
        if re.search(r"acceptance|criteria|requirements|must", line, re.I) and line.rstrip().endswith(":"):
            in_ac = True
            continue
        m = _AC_LINE.match(line)
        if m and in_ac:
            out.append(m.group(1).strip())
        elif in_ac and not line.strip():
            in_ac = False
    if expected_output:
        out.append(expected_output.strip())
    return out[:12]


class BasedAgentsAdapter(MarketplaceAdapter):
    id = "basedagents"

    def __init__(self, api_url: str, keypair_path: Path, fee_rate: Decimal, transport: httpx.AsyncBaseTransport | None = None, keypair=None):
        self.base = api_url.rstrip("/")
        self.keypair_path = Path(keypair_path)
        self._kp = keypair
        self.capabilities = Capabilities("exclusive_claim", fee_rate, "USDC/Base (x402 escrow)", requires_funding=True, fee_verified=False)
        self._http = httpx.AsyncClient(base_url=self.base, timeout=30, transport=transport)

    # ------------------------------------------------------------ identity/signing
    def keypair(self):
        if self._kp is None:
            try:
                from basedagents.keypair import AgentKeypair
            except ImportError as e:
                raise MarketplaceError("pip install basedagents") from e
            if not self.keypair_path.exists():
                raise MarketplaceError(f"no keypair at {self.keypair_path}; run `fos register basedagents`")
            self._kp = AgentKeypair.load(self.keypair_path)
        return self._kp

    def _signed_headers(self, method: str, path: str, body: str) -> dict[str, str]:
        from basedagents.auth import build_headers
        h = build_headers(self.keypair(), method, path, body)
        h["Content-Type"] = "application/json"
        return h

    async def _get(self, path: str) -> Any:
        last = None
        for attempt in range(3):
            r = await self._http.get(path)
            if r.status_code in (429, 500, 502, 503, 504):
                last = r
                import asyncio
                await asyncio.sleep(min(float(r.headers.get("retry-after", 2 ** attempt)), 20))
                continue
            return self._parse(r)
        raise MarketplaceError(f"GET {path} failed: {last.status_code if last else '?'}", status=last.status_code if last else None, retryable=True)

    async def _signed_post(self, path: str, body: dict) -> Any:
        return await self._signed("POST", path, body)

    async def _signed(self, method: str, path: str, body: dict) -> Any:
        s = json.dumps(body)
        r = await self._http.request(method, path, content=s.encode(), headers=self._signed_headers(method, path, s))
        return self._parse(r)

    # --------------------------------------------------------- payout wallet binding
    @staticmethod
    def wallet_bind_message(agent_id: str, address: str, network: str = "eip155:8453", *, issued: datetime | None = None, nonce: str | None = None) -> str:
        """Exact message the registry expects the WALLET to sign (EIP-191 personal_sign). Valid for 15 minutes."""
        import secrets
        from datetime import timezone
        ts = (issued or datetime.now(timezone.utc)).strftime("%Y-%m-%dT%H:%M:%SZ")
        return "\n".join(["BasedAgents payout wallet", f"Agent: {agent_id}", f"Wallet: {address.lower()}", f"Network: {network}",
                          f"Issued: {ts}", f"Nonce: {nonce or secrets.token_hex(8)}", "",
                          "Signing proves you control this wallet and lets BasedAgents pay this agent's bounties to it. It moves no funds."])

    async def set_wallet(self, address: str, network: str, message: str, signature: str) -> Any:
        """PATCH /v1/agents/{id}/wallet with the wallet's personal_sign proof. The agent never sees a wallet key."""
        if not re.fullmatch(r"0x[a-fA-F0-9]{40}", address):
            raise MarketplaceError("invalid EVM address")
        aid = self.keypair().agent_id
        return await self._signed("PATCH", f"/v1/agents/{aid}/wallet", {"wallet_address": address, "wallet_network": network,
                                                                     "wallet_proof": {"message": message, "signature": signature}})

    @staticmethod
    def _parse(r: httpx.Response) -> Any:
        try:
            data = r.json()
        except Exception:  # noqa: BLE001
            data = {}
        if r.is_success:
            return data
        code = data.get("code") or data.get("error") if isinstance(data, dict) else None
        msg = (data.get("message") if isinstance(data, dict) else None) or r.text[:200]
        raise MarketplaceError(f"HTTP {r.status_code}: {msg}", status=r.status_code, code=str(code) if code else None,
                               retryable=r.status_code in (429, 500, 502, 503, 504))

    # -------------------------------------------------------------------- mapping
    def _to_job(self, t: dict[str, Any]) -> Job:
        tid = t.get("id") or t.get("task_id") or ""
        desc = t.get("description") or ""
        bounty = t.get("bounty") or {}
        escrow = t.get("escrow") or {}
        funded: bool | None = None
        if bounty:
            if escrow:
                funded = str(escrow.get("status", "")).lower() == "funded"
            elif str(t.get("payment_status", "")).lower() in ("funded", "escrowed"):
                funded = True
        gh = _GH.search(desc + " " + json.dumps(t.get("inputs", "")))
        caps = [str(c) for c in (t.get("required_capabilities") or [])]
        posted = None
        age = None
        if t.get("created_at"):
            try:
                posted = datetime.fromisoformat(str(t["created_at"]).replace("Z", "+00:00"))
                age = max(0.0, (datetime.now(posted.tzinfo) - posted).total_seconds() / 3600)
            except ValueError:
                pass
        return Job(marketplace=self.id, external_id=str(tid), title=t.get("title", ""), description=desc,
                   repo_url=gh.group(0) if gh else None, skills=caps or ["python"] if t.get("category") == "code" else caps,
                   budget_usd=atomic_to_usd(bounty.get("amount")), currency=bounty.get("token", "USDC"),
                   acceptance_criteria=extract_criteria(desc, t.get("expected_output")), funded=funded,
                   competition=None, posted_at=posted, age_hours=age, network=bounty.get("network"), token=bounty.get("token", "USDC") if bounty else None, raw={k: v for k, v in t.items() if k in ("status", "category", "creator", "network")})

    # ------------------------------------------------------------------ interface
    async def discover(self, limit: int = 30) -> list[Job]:
        d = await self._get(f"/v1/tasks?status=open&category=code&limit={limit}")
        items = d.get("tasks", d.get("items", d)) if isinstance(d, dict) else d
        return [self._to_job(t) for t in items if isinstance(t, dict) and (t.get("id") or t.get("task_id"))]

    async def get_job(self, external_id: str) -> Job:
        d = await self._get(f"/v1/tasks/{external_id}")
        return self._to_job(d.get("task", d))

    async def claim(self, job: Job) -> ClaimResult:
        try:
            d = await self._signed_post(f"/v1/tasks/{job.external_id}/claim", {})
            return ClaimResult(ok=True, claim_id=str(d.get("claim_id") or d.get("task_id") or job.external_id))
        except MarketplaceError as e:
            if e.status == 409:
                hint = {"wallet_required": "set a payout wallet on the agent profile first",
                        "wallet_network_mismatch": "payout wallet network differs from the bounty network"}.get(e.code or "", "already claimed or not claimable")
                return ClaimResult(ok=False, reason=f"409 {e.code or ''}: {hint}", retryable=False)
            return ClaimResult(ok=False, reason=str(e), retryable=e.retryable)

    async def deliver(self, job: Job, delivery: Delivery) -> str:
        body: dict[str, Any] = {"summary": delivery.summary[:4000]}
        if delivery.pr_url:
            body.update(submission_type="pr", pr_url=delivery.pr_url)
        else:
            body.update(submission_type="json", submission_content=delivery.patch[:200_000])
        if delivery.commit_sha:
            body["commit_hash"] = delivery.commit_sha
        d = await self._signed_post(f"/v1/tasks/{job.external_id}/deliver", body)
        return str(d.get("receipt_id") or d.get("task_id") or job.external_id)

    async def payment_status(self, job: Job) -> PaymentStatus:
        d = await self._get(f"/v1/tasks/{job.external_id}/payment")
        p = d.get("payment", d)
        state = str(p.get("payment_status") or p.get("status") or "").lower()
        tx = str(p.get("payment_tx_hash") or p.get("tx_hash") or "")
        settled = state == "settled" and bool(tx)   # require an on-chain reference, not just a status string
        amt = atomic_to_usd((p.get("bounty") or {}).get("amount")) if isinstance(p.get("bounty"), dict) else None
        return PaymentStatus(settled=settled, amount_usd=amt or None, tx_ref=tx, state=state, raw=p)

    async def doctor(self) -> list[tuple[str, bool, str]]:
        res = []
        try:
            kp = self.keypair()
            res.append(("basedagents keypair", True, kp.agent_id))
        except Exception as e:  # noqa: BLE001
            res.append(("basedagents keypair", False, str(e)))
        try:
            jobs = await self.discover(limit=3)
            res.append(("basedagents GET /v1/tasks", True, f"{len(jobs)} open code tasks"))
        except Exception as e:  # noqa: BLE001
            res.append(("basedagents GET /v1/tasks", False, str(e)[:200]))
        return res

    async def aclose(self):
        await self._http.aclose()
