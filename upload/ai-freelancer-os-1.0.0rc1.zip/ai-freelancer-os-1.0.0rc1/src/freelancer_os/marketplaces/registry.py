from __future__ import annotations

from freelancer_os.config import Settings
from freelancer_os.marketplaces.base import MarketplaceAdapter, MarketplaceError, PlannedAdapter
from freelancer_os.marketplaces.basedagents import BasedAgentsAdapter
from freelancer_os.marketplaces.mock import MockMarketplace
from freelancer_os.marketplaces.taskbounty import TaskBountyAdapter

PLANNED = {
    "agentgigs": ("needs human Stripe Connect/KYC onboarding and an official API contract; not integrated", False),
    "clawgig": ("MCP/escrow contract not verified; not integrated", False),
    "upwork": ("official Upwork MCP requires OAuth + human confirmation for binding actions; proposal-draft flow not integrated", True),
}


def build_adapters(s: Settings) -> dict[str, MarketplaceAdapter]:
    out: dict[str, MarketplaceAdapter] = {}
    for name in s.marketplaces():
        if name == "mock":
            out[name] = MockMarketplace()
        elif name == "basedagents":
            out[name] = BasedAgentsAdapter(s.basedagents_api_url, s.basedagents_keypair_path, s.basedagents_fee_rate)
        elif name == "taskbounty":
            out[name] = TaskBountyAdapter(s.taskbounty_mcp_url, s.taskbounty_api_key, s.taskbounty_agent_id, s.taskbounty_fee_rate)
        elif name in PLANNED:
            reason, human = PLANNED[name]
            out[name] = PlannedAdapter(name, reason, human)
        else:
            raise MarketplaceError(f"unknown marketplace {name!r}")
    return out
