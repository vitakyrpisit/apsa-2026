"""Provider-agnostic LLM layer with retries, cost metering and validated JSON output."""
from __future__ import annotations

import asyncio
import json
import random
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Protocol, TypeVar

import httpx
from pydantic import BaseModel, ValidationError

T = TypeVar("T", bound=BaseModel)


class LLMError(RuntimeError):
    pass


class BudgetExceeded(LLMError):
    pass


@dataclass
class LLMResponse:
    text: str
    input_tokens: int = 0
    output_tokens: int = 0
    model: str = ""


class LLMClient(Protocol):
    model: str

    async def complete(self, system: str, messages: list[dict[str, str]], *, max_tokens: int = 4096,
                       temperature: float = 0.0) -> LLMResponse: ...


@dataclass
class CostMeter:
    price_in: Decimal
    price_out: Decimal
    limit_usd: Decimal
    input_tokens: int = 0
    output_tokens: int = 0
    calls: int = 0

    @property
    def cost_usd(self) -> Decimal:
        return (Decimal(self.input_tokens) * self.price_in + Decimal(self.output_tokens) * self.price_out) / Decimal(1_000_000)

    def add(self, r: LLMResponse) -> None:
        self.input_tokens += r.input_tokens
        self.output_tokens += r.output_tokens
        self.calls += 1
        if self.cost_usd > self.limit_usd:
            raise BudgetExceeded(f"LLM budget exceeded: ${self.cost_usd:.4f} > ${self.limit_usd}")


class MeteredLLM:
    """Wraps a client; every call is metered and the budget is enforced *after* each call."""

    def __init__(self, inner: LLMClient, meter: CostMeter):
        self.inner, self.meter = inner, meter
        self.model = getattr(inner, "model", "")

    async def complete(self, system, messages, *, max_tokens=4096, temperature=0.0) -> LLMResponse:
        if self.meter.cost_usd >= self.meter.limit_usd:
            raise BudgetExceeded("LLM budget already exhausted")
        r = await self.inner.complete(system, messages, max_tokens=max_tokens, temperature=temperature)
        self.meter.add(r)
        return r


async def _retrying_post(client: httpx.AsyncClient, url: str, *, headers: dict, json_body: dict, attempts: int = 4) -> httpx.Response:
    last: Exception | None = None
    for i in range(attempts):
        try:
            r = await client.post(url, headers=headers, json=json_body)
            if r.status_code in (429, 500, 502, 503, 504, 529):
                ra = r.headers.get("retry-after")
                delay = float(ra) if ra and ra.replace(".", "", 1).isdigit() else (2 ** i) + random.random()
                last = LLMError(f"HTTP {r.status_code}")
                await asyncio.sleep(min(delay, 30))
                continue
            return r
        except (httpx.TimeoutException, httpx.TransportError) as e:
            last = e
            await asyncio.sleep((2 ** i) + random.random())
    raise LLMError(f"LLM request failed after {attempts} attempts: {last}")


class AnthropicClient:
    def __init__(self, api_key: str, model: str, base_url: str = "https://api.anthropic.com", timeout: float = 180):
        if not api_key:
            raise LLMError("ANTHROPIC_API_KEY is not set")
        self.api_key, self.model, self.base_url = api_key, model, base_url.rstrip("/")
        self._http = httpx.AsyncClient(timeout=timeout)

    async def complete(self, system, messages, *, max_tokens=4096, temperature=0.0) -> LLMResponse:
        body = {"model": self.model, "max_tokens": max_tokens, "temperature": temperature,
                "system": system, "messages": messages}
        headers = {"x-api-key": self.api_key, "anthropic-version": "2023-06-01", "content-type": "application/json"}
        r = await _retrying_post(self._http, f"{self.base_url}/v1/messages", headers=headers, json_body=body)
        if r.status_code != 200:
            raise LLMError(f"Anthropic API {r.status_code}: {r.text[:300]}")
        d = r.json()
        text = "".join(b.get("text", "") for b in d.get("content", []) if b.get("type") == "text")
        u = d.get("usage", {})
        return LLMResponse(text, u.get("input_tokens", 0), u.get("output_tokens", 0), d.get("model", self.model))

    async def aclose(self):
        await self._http.aclose()


class GeminiClient:
    def __init__(self, api_key: str, model: str, timeout: float = 180):
        if not api_key:
            raise LLMError("GEMINI_API_KEY is not set")
        self.api_key, self.model = api_key, model
        self._http = httpx.AsyncClient(timeout=timeout)

    async def complete(self, system, messages, *, max_tokens=4096, temperature=0.0) -> LLMResponse:
        contents = [{"role": "user" if m["role"] == "user" else "model", "parts": [{"text": m["content"]}]} for m in messages]
        body = {"systemInstruction": {"parts": [{"text": system}]}, "contents": contents,
                "generationConfig": {"maxOutputTokens": max_tokens, "temperature": temperature}}
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent"
        r = await _retrying_post(self._http, url, headers={"x-goog-api-key": self.api_key, "content-type": "application/json"}, json_body=body)
        if r.status_code != 200:
            raise LLMError(f"Gemini API {r.status_code}: {r.text[:300]}")
        d = r.json()
        try:
            text = "".join(p.get("text", "") for p in d["candidates"][0]["content"]["parts"])
        except (KeyError, IndexError):
            raise LLMError(f"Gemini returned no content: {str(d)[:300]}")
        u = d.get("usageMetadata", {})
        return LLMResponse(text, u.get("promptTokenCount", 0), u.get("candidatesTokenCount", 0), self.model)

    async def aclose(self):
        await self._http.aclose()


class OpenAICompatClient:
    """Any OpenAI-compatible /chat/completions endpoint. Used for Z.ai (GLM-5/5.1) and self-hosted gateways."""

    def __init__(self, api_key: str, model: str, base_url: str, extra_body: dict | None = None, timeout: float = 240,
                 transport: httpx.AsyncBaseTransport | None = None):
        if not api_key:
            raise LLMError("API key for the OpenAI-compatible provider is not set")
        if not base_url.startswith("https://") and "localhost" not in base_url and "127.0.0.1" not in base_url:
            raise LLMError("base_url must be https")
        self.api_key, self.model, self.base_url, self.extra = api_key, model, base_url.rstrip("/"), extra_body or {}
        self._http = httpx.AsyncClient(timeout=timeout, transport=transport)

    async def complete(self, system, messages, *, max_tokens=4096, temperature=0.0) -> LLMResponse:
        body = {"model": self.model, "max_tokens": max_tokens, "temperature": temperature,
                "messages": [{"role": "system", "content": system}, *messages], **self.extra}
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        r = await _retrying_post(self._http, f"{self.base_url}/chat/completions", headers=headers, json_body=body)
        if r.status_code != 200:
            raise LLMError(f"OpenAI-compatible API {r.status_code}: {r.text[:300]}")
        d = r.json()
        try:
            text = d["choices"][0]["message"].get("content") or ""   # reasoning_content (GLM thinking) is deliberately ignored
        except (KeyError, IndexError):
            raise LLMError(f"no choices in response: {str(d)[:300]}")
        u = d.get("usage", {})
        return LLMResponse(text, u.get("prompt_tokens", 0), u.get("completion_tokens", 0), d.get("model", self.model))

    async def aclose(self):
        await self._http.aclose()


@dataclass
class ScriptedLLM:
    """Deterministic LLM for tests/evals. `script` is a list of strings or callables(messages)->str."""
    script: list[Any]
    model: str = "scripted"
    calls: list[dict[str, Any]] = field(default_factory=list)

    async def complete(self, system, messages, *, max_tokens=4096, temperature=0.0) -> LLMResponse:
        self.calls.append({"system": system, "messages": messages})
        if not self.script:
            raise LLMError("ScriptedLLM exhausted")
        item = self.script.pop(0)
        text = item(messages) if callable(item) else item
        return LLMResponse(text if isinstance(text, str) else json.dumps(text), 100, 50, self.model)


def extract_json(text: str) -> Any:
    """Find the first valid JSON object in model output (tolerates prose / code fences)."""
    dec = json.JSONDecoder()
    for i, ch in enumerate(text):
        if ch == "{":
            try:
                obj, _ = dec.raw_decode(text[i:])
                return obj
            except json.JSONDecodeError:
                continue
    raise ValueError("no JSON object found in model output")


async def complete_json(llm: LLMClient, system: str, user: str, schema: type[T], *, retries: int = 2,
                        max_tokens: int = 4096, history: list[dict[str, str]] | None = None) -> T:
    """Ask for JSON, validate against a pydantic model, feed validation errors back and retry."""
    messages = list(history or []) + [{"role": "user", "content": user}]
    last_err = ""
    for _ in range(retries + 1):
        r = await llm.complete(system, messages, max_tokens=max_tokens)
        try:
            return schema.model_validate(extract_json(r.text))
        except (ValueError, ValidationError) as e:
            last_err = str(e)[:500]
            messages = messages + [{"role": "assistant", "content": r.text[:4000]},
                                   {"role": "user", "content": f"Your reply was invalid: {last_err}\nReply again with ONLY one valid JSON object matching the required schema."}]
    raise LLMError(f"model failed to produce valid JSON: {last_err}")


def build_client(provider: str, model: str, settings) -> LLMClient | None:
    if provider == "none":
        return None
    if provider == "anthropic":
        return AnthropicClient(settings.anthropic_api_key, model)
    if provider == "gemini":
        return GeminiClient(settings.gemini_api_key, model)
    extra = json.loads(settings.llm_extra_body) if settings.llm_extra_body else {}
    if provider == "zai":
        return OpenAICompatClient(settings.zai_api_key, model, settings.zai_base_url, extra)
    if provider == "openai_compat":
        return OpenAICompatClient(settings.openai_compat_api_key, model, settings.openai_compat_base_url, extra)
    raise LLMError(f"unknown provider {provider}")
