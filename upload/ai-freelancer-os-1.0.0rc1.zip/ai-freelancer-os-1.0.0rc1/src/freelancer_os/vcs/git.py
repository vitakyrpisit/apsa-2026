"""Real git operations (subprocess) and a GitHub PR client (REST)."""
from __future__ import annotations

import asyncio
import base64
import os
import re
from pathlib import Path

import httpx

_GH_URL = re.compile(r"^https://github\.com/([A-Za-z0-9_.\-]+)/([A-Za-z0-9_.\-]+?)(?:\.git)?/?$")
EXCLUDES = [".deps/", ".home/", "__pycache__/", "*.pyc", ".pytest_cache/", ".venv/", "node_modules/", ".mypy_cache/", ".ruff_cache/"]


class GitError(RuntimeError):
    pass


def parse_github_url(url: str) -> tuple[str, str] | None:
    m = _GH_URL.match(url.strip())
    return (m.group(1), m.group(2)) if m else None


class Repo:
    def __init__(self, path: Path, *, token: str = "", author_name: str = "AI Freelancer OS", author_email: str = "agent@users.noreply.github.com"):
        self.path, self.token = Path(path), token
        self.author = (author_name, author_email)

    def _env(self) -> dict[str, str]:
        e = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "HOME": str(self.path.parent), "GIT_TERMINAL_PROMPT": "0",
             "GIT_CONFIG_NOSYSTEM": "1", "LANG": "C.UTF-8",
             "GIT_AUTHOR_NAME": self.author[0], "GIT_AUTHOR_EMAIL": self.author[1],
             "GIT_COMMITTER_NAME": self.author[0], "GIT_COMMITTER_EMAIL": self.author[1]}
        return e

    async def git(self, *args: str, cwd: Path | None = None, check: bool = True, auth: bool = False, timeout: int = 300) -> str:
        pre: list[str] = ["-c", "core.hooksPath=/dev/null", "-c", "commit.gpgsign=false", "-c", "protocol.file.allow=user"]
        if auth and self.token:
            basic = base64.b64encode(f"x-access-token:{self.token}".encode()).decode()
            pre += ["-c", f"http.https://github.com/.extraheader=AUTHORIZATION: basic {basic}"]
        proc = await asyncio.create_subprocess_exec("git", *pre, *args, cwd=str(cwd or self.path), env=self._env(),
                                                    stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        try:
            out, err = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        except asyncio.TimeoutError:
            proc.kill()
            raise GitError(f"git {args[0]} timed out")
        if check and proc.returncode != 0:
            msg = err.decode("utf-8", "replace")[:500]
            if self.token:
                msg = msg.replace(self.token, "***")
            raise GitError(f"git {' '.join(args[:2])} failed: {msg}")
        return out.decode("utf-8", "replace")

    @classmethod
    async def clone(cls, url: str, dest: Path, *, token: str = "", allow_local: bool = False, ref: str | None = None,
                    depth: int = 50, **kw) -> "Repo":
        is_gh = parse_github_url(url) is not None
        if not is_gh and not (allow_local and (Path(url).exists() or url.startswith("file://"))):
            raise GitError(f"refusing to clone non-GitHub URL: {url!r}")
        dest.parent.mkdir(parents=True, exist_ok=True)
        r = cls(dest, token=token, **kw)
        args = ["clone", "--quiet", "--no-tags"] + (["--depth", str(depth)] if is_gh else []) + (["--branch", ref] if ref else []) + [url, str(dest)]
        await r.git(*args, cwd=dest.parent, auth=is_gh)
        exclude = dest / ".git" / "info" / "exclude"
        exclude.parent.mkdir(parents=True, exist_ok=True)
        with open(exclude, "a") as f:
            f.write("\n".join(EXCLUDES) + "\n")
        return r

    async def head(self) -> str:
        return (await self.git("rev-parse", "HEAD")).strip()

    async def current_branch(self) -> str:
        return (await self.git("rev-parse", "--abbrev-ref", "HEAD")).strip()

    async def checkout_new_branch(self, name: str) -> None:
        if not re.fullmatch(r"[\w./\-]{1,100}", name):
            raise GitError("bad branch name")
        await self.git("checkout", "-q", "-b", name)

    async def diff_from(self, base_sha: str) -> str:
        """Full patch of working tree vs base including new files."""
        await self.git("add", "-A")
        return await self.git("diff", "--cached", "--binary", "--no-color", base_sha)

    async def changed_files(self, base_sha: str) -> list[str]:
        await self.git("add", "-A")
        return [l for l in (await self.git("diff", "--cached", "--name-only", base_sha)).splitlines() if l]

    async def apply_patch(self, patch: str) -> None:
        pf = self.path.parent / f".{self.path.name}.patch"
        pf.write_text(patch)
        try:
            await self.git("apply", "--check", "--whitespace=nowarn", str(pf))
            await self.git("apply", "--whitespace=nowarn", str(pf))
        finally:
            pf.unlink(missing_ok=True)

    async def commit_all(self, message: str) -> str:
        await self.git("add", "-A")
        await self.git("commit", "-q", "-m", message)
        return await self.head()

    async def push(self, remote_url: str, branch: str) -> None:
        await self.git("push", "--quiet", remote_url, f"HEAD:refs/heads/{branch}", auth=True)


class GitHubClient:
    """Minimal GitHub REST client: fork-if-needed, push branch to fork, open PR."""

    def __init__(self, token: str, transport: httpx.AsyncBaseTransport | None = None):
        if not token:
            raise GitError("GITHUB_TOKEN is not set")
        self._http = httpx.AsyncClient(base_url="https://api.github.com", timeout=30, transport=transport, headers={
            "Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28"})

    async def me(self) -> str:
        r = await self._http.get("/user")
        r.raise_for_status()
        return r.json()["login"]

    async def default_branch(self, owner: str, repo: str) -> str:
        r = await self._http.get(f"/repos/{owner}/{repo}")
        r.raise_for_status()
        return r.json()["default_branch"]

    async def ensure_fork(self, owner: str, repo: str) -> tuple[str, str]:
        me = await self.me()
        if me.lower() == owner.lower():
            return owner, repo
        r = await self._http.post(f"/repos/{owner}/{repo}/forks", json={})
        if r.status_code not in (200, 202):
            raise GitError(f"fork failed: {r.status_code} {r.text[:200]}")
        for _ in range(30):
            c = await self._http.get(f"/repos/{me}/{repo}")
            if c.status_code == 200:
                return me, repo
            await asyncio.sleep(2)
        raise GitError("fork not ready")

    async def open_pr(self, owner: str, repo: str, head_owner: str, branch: str, base: str, title: str, body: str) -> str:
        head = branch if head_owner.lower() == owner.lower() else f"{head_owner}:{branch}"
        r = await self._http.post(f"/repos/{owner}/{repo}/pulls", json={"title": title, "head": head, "base": base, "body": body, "maintainer_can_modify": True})
        if r.status_code not in (200, 201):
            raise GitError(f"PR failed: {r.status_code} {r.text[:300]}")
        return r.json()["html_url"]

    async def aclose(self):
        await self._http.aclose()
