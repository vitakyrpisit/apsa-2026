"""SQLite persistence (WAL). One process owns the agent; this is intentionally simple and durable."""
from __future__ import annotations

import json
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path
from typing import Any, Iterator

from freelancer_os.domain import Job, JobState, Score

SCHEMA = """
CREATE TABLE IF NOT EXISTS jobs(
  key TEXT PRIMARY KEY, marketplace TEXT NOT NULL, external_id TEXT NOT NULL,
  state TEXT NOT NULL, decision TEXT, job_json TEXT NOT NULL, score_json TEXT,
  error TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_jobs_state ON jobs(state);
CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY AUTOINCREMENT, job_key TEXT, ts TEXT NOT NULL, kind TEXT NOT NULL, data_json TEXT);
CREATE INDEX IF NOT EXISTS idx_events_job ON events(job_key);
CREATE TABLE IF NOT EXISTS ledger(
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, job_key TEXT, kind TEXT NOT NULL,
  amount TEXT NOT NULL, note TEXT);
CREATE INDEX IF NOT EXISTS idx_ledger_ts ON ledger(ts);
CREATE TABLE IF NOT EXISTS outcomes(
  id INTEGER PRIMARY KEY AUTOINCREMENT, job_key TEXT UNIQUE, ts TEXT NOT NULL, marketplace TEXT,
  skill_bucket TEXT, complexity INTEGER, pred_p_success REAL, pred_p_win REAL,
  won INTEGER, succeeded INTEGER, cost_usd TEXT, revenue_usd TEXT, hours REAL, paid INTEGER);
"""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class Database:
    def __init__(self, path: Path | str):
        self.path = str(path)
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(self.path, check_same_thread=False, isolation_level=None)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._conn.executescript(SCHEMA)

    @contextmanager
    def tx(self) -> Iterator[sqlite3.Connection]:
        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                yield self._conn
                self._conn.execute("COMMIT")
            except Exception:
                self._conn.execute("ROLLBACK")
                raise

    def q(self, sql: str, args: tuple = ()) -> list[sqlite3.Row]:
        with self._lock:
            return list(self._conn.execute(sql, args).fetchall())

    # ----------------------------------------------------------------- jobs
    def upsert_job(self, job: Job, state: JobState, score: Score | None = None, error: str | None = None) -> None:
        now = _now()
        with self.tx() as c:
            c.execute(
                """INSERT INTO jobs(key,marketplace,external_id,state,decision,job_json,score_json,error,created_at,updated_at)
                   VALUES(?,?,?,?,?,?,?,?,?,?)
                   ON CONFLICT(key) DO UPDATE SET state=excluded.state, decision=COALESCE(excluded.decision,decision),
                   job_json=excluded.job_json, score_json=COALESCE(excluded.score_json,score_json),
                   error=excluded.error, updated_at=excluded.updated_at""",
                (job.key, job.marketplace, job.external_id, state.value, score.decision.value if score else None,
                 job.model_dump_json(), score.model_dump_json() if score else None, error, now, now))

    def set_state(self, key: str, state: JobState, error: str | None = None) -> None:
        with self.tx() as c:
            c.execute("UPDATE jobs SET state=?, error=?, updated_at=? WHERE key=?", (state.value, error, _now(), key))

    def get_job(self, key: str) -> tuple[Job, JobState, Score | None] | None:
        rows = self.q("SELECT * FROM jobs WHERE key=?", (key,))
        if not rows:
            return None
        r = rows[0]
        return (Job.model_validate_json(r["job_json"]), JobState(r["state"]),
                Score.model_validate_json(r["score_json"]) if r["score_json"] else None)

    def list_jobs(self, state: JobState | None = None, limit: int = 100) -> list[dict[str, Any]]:
        rows = self.q("SELECT key,marketplace,state,decision,error,updated_at,job_json,score_json FROM jobs "
                      + ("WHERE state=? " if state else "") + "ORDER BY updated_at DESC LIMIT ?",
                      ((state.value, limit) if state else (limit,)))
        out = []
        for r in rows:
            j = json.loads(r["job_json"])
            s = json.loads(r["score_json"]) if r["score_json"] else None
            out.append({"key": r["key"], "marketplace": r["marketplace"], "state": r["state"], "decision": r["decision"],
                        "title": j.get("title"), "budget_usd": j.get("budget_usd"), "error": r["error"],
                        "updated_at": r["updated_at"], "expected_profit": s and s.get("expected_profit")})
        return out

    def count_state_done(self) -> int:
        """Jobs that reached delivery (used for the 'first N jobs need approval' rule)."""
        return self.count_state(JobState.DELIVERED, JobState.SETTLED)

    def count_state(self, *states: JobState) -> int:
        ph = ",".join("?" * len(states))
        return self.q(f"SELECT COUNT(*) n FROM jobs WHERE state IN ({ph})", tuple(s.value for s in states))[0]["n"]

    # --------------------------------------------------------------- events
    def event(self, job_key: str | None, kind: str, data: Any = None) -> None:
        with self.tx() as c:
            c.execute("INSERT INTO events(job_key,ts,kind,data_json) VALUES(?,?,?,?)",
                      (job_key, _now(), kind, json.dumps(data, default=str) if data is not None else None))

    def events(self, job_key: str) -> list[dict[str, Any]]:
        return [{"ts": r["ts"], "kind": r["kind"], "data": json.loads(r["data_json"]) if r["data_json"] else None}
                for r in self.q("SELECT * FROM events WHERE job_key=? ORDER BY id", (job_key,))]

    # --------------------------------------------------------------- ledger
    def ledger_add(self, kind: str, amount: Decimal, job_key: str | None = None, note: str = "") -> None:
        with self.tx() as c:
            c.execute("INSERT INTO ledger(ts,job_key,kind,amount,note) VALUES(?,?,?,?,?)",
                      (_now(), job_key, kind, str(amount), note))

    def ledger_sum(self, kinds: tuple[str, ...], since: datetime | None = None, job_key: str | None = None) -> Decimal:
        sql = f"SELECT amount FROM ledger WHERE kind IN ({','.join('?' * len(kinds))})"
        args: list[Any] = list(kinds)
        if since:
            sql += " AND ts>=?"; args.append(since.isoformat())
        if job_key:
            sql += " AND job_key=?"; args.append(job_key)
        return sum((Decimal(r["amount"]) for r in self.q(sql, tuple(args))), Decimal("0"))

    def spend_today(self) -> Decimal:
        start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
        return self.ledger_sum(("llm_cost", "sandbox_cost", "other_cost"), since=start)

    # ------------------------------------------------------------- outcomes
    def record_prediction(self, job_key: str, marketplace: str, bucket: str, complexity: int, p_success: float, p_win: float) -> None:
        with self.tx() as c:
            c.execute("""INSERT INTO outcomes(job_key,ts,marketplace,skill_bucket,complexity,pred_p_success,pred_p_win)
                         VALUES(?,?,?,?,?,?,?) ON CONFLICT(job_key) DO UPDATE SET pred_p_success=excluded.pred_p_success,
                         pred_p_win=excluded.pred_p_win""",
                      (job_key, _now(), marketplace, bucket, complexity, p_success, p_win))

    def update_outcome(self, job_key: str, **fields: Any) -> None:
        allowed = {"won", "succeeded", "cost_usd", "revenue_usd", "hours", "paid"}
        sets = {k: (str(v) if isinstance(v, Decimal) else v) for k, v in fields.items() if k in allowed}
        if not sets:
            return
        with self.tx() as c:
            c.execute(f"UPDATE outcomes SET {','.join(k + '=?' for k in sets)} WHERE job_key=?", (*sets.values(), job_key))

    def outcome_stats(self, *, marketplace: str | None = None, bucket: str | None = None) -> dict[str, Any]:
        sql, args = "SELECT * FROM outcomes WHERE 1=1", []
        if marketplace:
            sql += " AND marketplace=?"; args.append(marketplace)
        if bucket:
            sql += " AND skill_bucket=?"; args.append(bucket)
        rows = self.q(sql, tuple(args))
        won = [r for r in rows if r["won"] is not None]
        done = [r for r in rows if r["succeeded"] is not None]
        costs = sorted(Decimal(r["cost_usd"]) for r in rows if r["cost_usd"] is not None)
        hours = sorted(r["hours"] for r in rows if r["hours"] is not None)
        brier = None
        if done:
            brier = sum((r["pred_p_success"] - r["succeeded"]) ** 2 for r in done if r["pred_p_success"] is not None) / len(done)
        return {"n_won_known": len(won), "wins": sum(r["won"] for r in won),
                "n_done": len(done), "successes": sum(r["succeeded"] for r in done),
                "median_cost": costs[len(costs) // 2] if costs else None,
                "median_hours": hours[len(hours) // 2] if hours else None, "brier": brier}

    def paid_stats(self, marketplace: str) -> dict[str, int]:
        """Of the jobs we delivered (QA passed) on this marketplace, how many were actually paid?"""
        rows = self.q("SELECT paid FROM outcomes WHERE marketplace=? AND paid IS NOT NULL", (marketplace,))
        return {"n": len(rows), "paid": sum(r["paid"] for r in rows)}

    def event_ts(self, job_key: str, kind: str) -> str | None:
        rows = self.q("SELECT ts FROM events WHERE job_key=? AND kind=? ORDER BY id DESC LIMIT 1", (job_key, kind))
        return rows[0]["ts"] if rows else None

    def close(self) -> None:
        self._conn.close()
