"""Typed domain objects shared by every layer."""
from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Decision(str, Enum):
    REJECT = "REJECT"
    HUMAN_APPROVAL = "HUMAN_APPROVAL"
    CLAIM = "CLAIM"


class JobState(str, Enum):
    DISCOVERED = "DISCOVERED"
    REJECTED = "REJECTED"
    BLOCKED = "BLOCKED"                  # security firewall
    AWAITING_APPROVAL = "AWAITING_APPROVAL"
    APPROVED = "APPROVED"
    CLAIMED = "CLAIMED"
    WORKING = "WORKING"
    QA_FAILED = "QA_FAILED"
    READY_TO_DELIVER = "READY_TO_DELIVER"  # dry-run stops here
    DELIVERED = "DELIVERED"
    SETTLED = "SETTLED"
    FAILED = "FAILED"


class Job(BaseModel):
    marketplace: str
    external_id: str
    title: str
    description: str
    repo_url: str | None = None
    base_branch: str | None = None
    skills: list[str] = Field(default_factory=list)
    budget_usd: Decimal = Decimal("0")
    currency: str = "USDC"
    deadline_hours: float | None = None
    acceptance_criteria: list[str] = Field(default_factory=list)
    acceptance_tests: dict[str, str] = Field(default_factory=dict)  # path -> content, validator-owned tests
    client_rating: float | None = None
    funded: bool | None = None          # None = unknown (treated as NOT funded for escrow marketplaces)
    competition: int | None = None      # number of competing claimers/bids when known
    posted_at: datetime | None = None
    network: str | None = None            # e.g. eip155:8453 (Base mainnet)
    token: str | None = None
    requester_settled: int | None = None  # number of tasks the requester has paid out, when the marketplace exposes it
    age_hours: float | None = None
    raw: dict[str, Any] = Field(default_factory=dict)

    @property
    def key(self) -> str:
        return f"{self.marketplace}:{self.external_id}"


class Score(BaseModel):
    stage: str = "pre"                   # pre (before probe) | post (after repo probe)
    skill_match: float
    p_success: float
    p_win: float
    expected_revenue: Decimal
    expected_cost: Decimal
    expected_profit: Decimal
    expected_hours: float
    profit_per_hour: Decimal
    decision: Decision
    reasons: list[str] = Field(default_factory=list)
    features: dict[str, Any] = Field(default_factory=dict)


class Check(BaseModel):
    name: str
    passed: bool
    detail: str = ""
    severity: str = "fail"               # fail | warn


class CriterionResult(BaseModel):
    id: str
    text: str
    met: bool
    evidence: str = ""


class QAReport(BaseModel):
    passed: bool
    checks: list[Check] = Field(default_factory=list)
    criteria: list[CriterionResult] = Field(default_factory=list)
    llm_review: bool = False
    tests_after: dict[str, Any] = Field(default_factory=dict)
    summary: str = ""


class AgentResult(BaseModel):
    success: bool
    summary: str = ""
    steps: int = 0
    cost_usd: Decimal = Decimal("0")
    files_changed: list[str] = Field(default_factory=list)
    patch: str = ""
    base_sha: str = ""
    final_tests: dict[str, Any] = Field(default_factory=dict)
    aborted_reason: str = ""
    transcript: list[dict[str, Any]] = Field(default_factory=list)


class ClaimResult(BaseModel):
    ok: bool
    claim_id: str = ""
    reason: str = ""
    retryable: bool = False


class PaymentStatus(BaseModel):
    settled: bool
    amount_usd: Decimal | None = None
    tx_ref: str = ""
    state: str = ""
    raw: dict[str, Any] = Field(default_factory=dict)


class Delivery(BaseModel):
    summary: str
    patch: str
    commit_sha: str = ""
    pr_url: str = ""
    branch: str = ""
    qa: QAReport
