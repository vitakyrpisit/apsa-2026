"""Path-jailed workspace tools exposed to the coding agent. The agent can touch NOTHING else."""
from __future__ import annotations

import fnmatch
import re
from pathlib import Path

from freelancer_os.sandbox.runner import Sandbox, TestResult, run_tests

PROTECTED = [".git/*", ".github/*", ".gitlab-ci.yml", ".env", ".env.*", "*.pem", "*.key", "*secret*", ".deps/*", ".home/*"]
SKIP_DIRS = {".git", ".deps", ".home", "__pycache__", "node_modules", ".venv", ".pytest_cache", ".mypy_cache", ".ruff_cache"}
MAX_READ = 20_000
MAX_WRITE = 120_000


class ToolError(Exception):
    pass


class Workspace:
    def __init__(self, root: Path, sandbox: Sandbox):
        self.root = Path(root).resolve()
        self.sandbox = sandbox
        self.last_tests: TestResult | None = None

    def resolve(self, rel: str, *, write: bool = False) -> Path:
        if not isinstance(rel, str) or not rel or "\x00" in rel:
            raise ToolError("invalid path")
        if rel.startswith("/") or re.match(r"^[A-Za-z]:", rel):
            raise ToolError("absolute paths are not allowed")
        p = (self.root / rel).resolve()
        try:
            relp = p.relative_to(self.root).as_posix()
        except ValueError:
            raise ToolError("path escapes workspace")
        parts = relp.split("/")
        if parts[0] == ".git":
            raise ToolError("access to .git is not allowed")
        if write and any(fnmatch.fnmatch(relp.lower(), pat) for pat in PROTECTED):
            raise ToolError(f"path is protected: {relp}")
        return p

    # ----------------------------------------------------------- read tools
    def list_dir(self, path: str = ".") -> str:
        p = self.resolve(path if path not in ("", None) else ".")
        if not p.is_dir():
            raise ToolError("not a directory")
        items = []
        for c in sorted(p.iterdir(), key=lambda x: (not x.is_dir(), x.name)):
            if c.name in SKIP_DIRS:
                continue
            items.append(c.name + ("/" if c.is_dir() else f"  ({c.stat().st_size}b)"))
        return "\n".join(items[:200]) or "(empty)"

    def tree(self, max_files: int = 120) -> str:
        out: list[str] = []
        for p in sorted(self.root.rglob("*")):
            rel = p.relative_to(self.root)
            if any(part in SKIP_DIRS for part in rel.parts) or p.is_dir():
                continue
            out.append(rel.as_posix())
            if len(out) >= max_files:
                out.append("... (more files)")
                break
        return "\n".join(out)

    def read_file(self, path: str, start: int = 1, end: int | None = None) -> str:
        p = self.resolve(path)
        if not p.is_file():
            raise ToolError("file not found")
        data = p.read_bytes()
        if b"\x00" in data[:4096]:
            raise ToolError("binary file")
        lines = data.decode("utf-8", "replace").splitlines()
        start = max(1, int(start or 1))
        end = min(len(lines), int(end)) if end else len(lines)
        body = "\n".join(f"{i}: {l}" for i, l in enumerate(lines[start - 1:end], start))
        if len(body) > MAX_READ:
            body = body[:MAX_READ] + f"\n...[truncated; use start/end, file has {len(lines)} lines]"
        return body

    def search(self, pattern: str, path: str = ".") -> str:
        try:
            rx = re.compile(pattern)
        except re.error as e:
            raise ToolError(f"bad regex: {e}")
        base = self.resolve(path)
        hits: list[str] = []
        files = [base] if base.is_file() else sorted(base.rglob("*"))
        for f in files:
            if not f.is_file() or any(part in SKIP_DIRS for part in f.relative_to(self.root).parts) or f.stat().st_size > 400_000:
                continue
            try:
                text = f.read_text("utf-8")
            except (UnicodeDecodeError, OSError):
                continue
            for i, line in enumerate(text.splitlines(), 1):
                if rx.search(line):
                    hits.append(f"{f.relative_to(self.root).as_posix()}:{i}: {line.strip()[:160]}")
                    if len(hits) >= 60:
                        return "\n".join(hits) + "\n...[more matches truncated]"
        return "\n".join(hits) or "no matches"

    # ---------------------------------------------------------- write tools
    def write_file(self, path: str, content: str) -> str:
        if not isinstance(content, str):
            raise ToolError("content must be a string")
        if len(content.encode()) > MAX_WRITE:
            raise ToolError("file too large")
        p = self.resolve(path, write=True)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        return f"wrote {path} ({len(content)} chars)"

    def replace(self, path: str, old: str, new: str) -> str:
        p = self.resolve(path, write=True)
        if not p.is_file():
            raise ToolError("file not found")
        text = p.read_text("utf-8")
        n = text.count(old)
        if not old:
            raise ToolError("'old' must be non-empty")
        if n == 0:
            raise ToolError("'old' text not found (must match exactly, including whitespace)")
        if n > 1:
            raise ToolError(f"'old' text matches {n} places; include more context to make it unique")
        p.write_text(text.replace(old, new, 1), encoding="utf-8")
        return f"replaced 1 occurrence in {path}"

    def delete_file(self, path: str) -> str:
        p = self.resolve(path, write=True)
        if not p.is_file():
            raise ToolError("file not found")
        p.unlink()
        return f"deleted {path}"

    async def run_tests(self, target: str | None = None, full: bool = False) -> TestResult:
        try:
            res = await run_tests(self.sandbox, self.root, target=target, full=full)
        except ValueError as e:
            raise ToolError(str(e))
        self.last_tests = res
        return res
