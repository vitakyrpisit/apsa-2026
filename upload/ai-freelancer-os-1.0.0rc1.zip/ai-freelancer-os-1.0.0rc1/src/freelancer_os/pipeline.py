"""Orchestrator: DISCOVER -> SECURITY -> SCORE -> (APPROVAL) -> PROBE -> RESCORE -> CLAIM -> CODE -> QA -> DELIVER -> SETTLE -> LEARN.
Every transition is persisted, so the process can crash and resume without double-claiming or double-spending."""
from __future__ import annotations

import json
import re
from datetime import datetime, timezone
import shutil
import time
from decimal import Decimal
from typing import Callable

from freelancer_os.agents.coding_agent import CodingAgent
from freelancer_os.agents.qa_agent import QAAgent
from freelancer_os.agents.workspace import Workspace
from freelancer_os.config import Settings
from freelancer_os.domain import Decision, Delivery, Job, JobState, Score
from freelancer_os.llm.client import CostMeter, LLMClient, build_client
from freelancer_os.marketplaces.base import MarketplaceAdapter, MarketplaceError
from freelancer_os.opportunity import bandit
from freelancer_os.opportunity.engine import OpportunityEngine, skill_bucket
from freelancer_os.sandbox.runner import Sandbox, install_requirements, make_sandbox, run_tests
from freelancer_os.security.firewall import redact, scan
from freelancer_os.storage.db import Database
from freelancer_os.treasury.policy import SpendDenied, Treasury
from freelancer_os.vcs.git import GitHubClient, Repo, parse_github_url


def _safe(key: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]", "_", key)[:100]


class Pipeline:
    def __init__(self, settings: Settings, db: Database, adapters: dict[str, MarketplaceAdapter], *, llm: LLMClient | None = None,
                 qa_llm: LLMClient | None = None, sandbox: Sandbox | None = None, github: GitHubClient | None = None,
                 log: Callable[[str], None] = print):
        self.s, self.db, self.adapters, self.log = settings, db, adapters, log
        self.engine = OpportunityEngine(settings, db)
        self.treasury = Treasury(settings, db)
        self.sandbox = sandbox or make_sandbox(settings)
        self.llm, self.qa_llm, self.github = llm, qa_llm, github
        settings.ensure_dirs()

    # ------------------------------------------------------------------- LLMs
    def _agent_llm(self) -> LLMClient:
        if self.llm is None:
            self.llm = build_client(self.s.llm_provider, self.s.llm_model, self.s)
        if self.llm is None:
            raise RuntimeError("no LLM configured (LLM_PROVIDER=none): cannot do work")
        return self.llm

    def _qa_llm(self) -> LLMClient | None:
        if self.qa_llm is not None:
            return self.qa_llm
        prov = self.s.llm_provider if self.s.qa_llm_provider == "same" else self.s.qa_llm_provider
        model = self.s.qa_llm_model or self.s.llm_model
        if prov == "none":
            return None
        try:
            self.qa_llm = build_client(prov, model, self.s)
        except Exception as e:  # noqa: BLE001
            self.log(f"[qa] LLM unavailable: {e}")
            return None
        return self.qa_llm

    # --------------------------------------------------------------- discovery
    async def scan_marketplace(self, name: str, limit: int = 30) -> list[tuple[Job, Score]]:
        ad = self.adapters[name]
        jobs = await ad.discover(limit)
        out: list[tuple[Job, Score]] = []
        for job in jobs:
            if self.db.get_job(job.key):
                continue  # dedup: never re-score/re-claim a job we have seen
            sec = scan(job.title + "\n" + job.description + "\n" + "\n".join(job.acceptance_criteria))
            if sec.blocked:
                self.db.upsert_job(job, JobState.BLOCKED, error=sec.summary())
                self.db.event(job.key, "security_blocked", sec.summary())
                self.log(f"[scan] BLOCKED {job.key}: {sec.summary()}")
                continue
            score = self.engine.score(job, ad.capabilities)
            state = {Decision.REJECT: JobState.REJECTED, Decision.HUMAN_APPROVAL: JobState.AWAITING_APPROVAL, Decision.CLAIM: JobState.APPROVED}[score.decision]
            self.db.upsert_job(job, state, score)
            self.db.record_prediction(job.key, job.marketplace, skill_bucket(job, self.s), score.features.get("complexity", 3), score.p_success, score.p_win)
            self.db.event(job.key, "scored", score.model_dump(mode="json"))
            out.append((job, score))
            self.log(f"[scan] {job.key}: {score.decision.value} profit=${score.expected_profit} p_succ={score.p_success} p_win={score.p_win}")
        return out

    def approve(self, key: str) -> None:
        rec = self.db.get_job(key)
        if not rec or rec[1] != JobState.AWAITING_APPROVAL:
            raise ValueError(f"{key} is not awaiting approval")
        self.db.set_state(key, JobState.APPROVED)
        self.db.event(key, "human_approved")

    def reject(self, key: str) -> None:
        self.db.set_state(key, JobState.REJECTED, "rejected by human")
        self.db.event(key, "human_rejected")

    # --------------------------------------------------------------- execution
    async def execute(self, key: str) -> JobState:
        rec = self.db.get_job(key)
        if not rec:
            raise ValueError(f"unknown job {key}")
        job, state, score = rec
        if state != JobState.APPROVED:
            raise ValueError(f"{key} is in state {state.value}, expected APPROVED")
        ad = self.adapters[job.marketplace]
        ws_dir = self.s.workspaces_dir / _safe(key)
        art_dir = self.s.artifacts_dir / _safe(key)
        art_dir.mkdir(parents=True, exist_ok=True)
        if ws_dir.exists():
            shutil.rmtree(ws_dir)
        t0 = time.monotonic()
        meter = CostMeter(self.s.llm_price_in_per_mtok, self.s.llm_price_out_per_mtok, min(self.s.max_llm_cost_per_job_usd, self.s.max_job_spend_usd))
        try:
            self.treasury.assert_running()
            if not job.repo_url:
                return self._end(key, JobState.REJECTED, "no repository URL")
            if not self.treasury.can_spend(key, Decimal("0.05")):
                return self._end(key, JobState.REJECTED, "spend cap reached")

            # 1. PROBE the real repo before spending on the LLM or claiming
            repo = await Repo.clone(job.repo_url, ws_dir / "repo", token=self.s.github_token, allow_local=self.s.allow_local_repos,
                                    author_name=self.s.git_author_name, author_email=self.s.git_author_email)
            inst = await install_requirements(self.sandbox, repo.path)
            if inst is not None and not inst.ok:
                return self._end(key, JobState.REJECTED, f"dependency install failed: {inst.stderr[-200:]}")
            base_sha = await repo.head()
            base = await run_tests(self.sandbox, repo.path, full=True)
            testability = 1.0 if base.ran and (base.passed + base.failed) > 0 else 0.3
            repo_health = 0.9 if base.ran else 0.4
            post = self.engine.score(job, ad.capabilities, stage="post", testability=testability, repo_health=repo_health)
            self.db.upsert_job(job, JobState.APPROVED, post)
            self.db.event(key, "probe", {"baseline": base.brief(), "post_score": post.model_dump(mode="json")})
            if post.decision == Decision.REJECT:
                return self._end(key, JobState.REJECTED, "post-probe rescore: " + "; ".join(post.reasons[-3:]))

            # 2. CLAIM (skipped in dry-run)
            if self.s.dry_run:
                self.db.event(key, "dry_run_skip_claim")
            else:
                cr = await ad.claim(job)
                self.db.event(key, "claim", cr.model_dump())
                self.db.update_outcome(key, won=1 if cr.ok else 0)
                if not cr.ok:
                    return self._end(key, JobState.FAILED, f"claim failed: {cr.reason}")
                self.db.set_state(key, JobState.CLAIMED)

            # 3. CODE
            self.db.set_state(key, JobState.WORKING)
            agent = CodingAgent(self._agent_llm(), meter, max_steps=self.s.agent_max_steps, max_fix_rounds=self.s.agent_max_fix_rounds,
                                events=lambda k, d=None: self.db.event(key, k, d))
            result = await agent.run(job, Workspace(repo.path, self.sandbox), repo)
            self._account(key, meter, t0)
            (art_dir / "patch.diff").write_text(result.patch)
            (art_dir / "transcript.json").write_text(redact(json.dumps(result.transcript, indent=1)))
            self.db.event(key, "agent_result", {"success": result.success, "steps": result.steps, "cost": str(result.cost_usd),
                                                "files": result.files_changed, "abort": result.aborted_reason})
            if not result.success:
                self.db.update_outcome(key, succeeded=0, cost_usd=self.treasury.job_spend(key), hours=(time.monotonic() - t0) / 3600)
                return self._end(key, JobState.FAILED, result.aborted_reason or "agent could not make tests pass")

            # 4. INDEPENDENT QA (fresh clone, own test run, validator-owned tests)
            qa = QAAgent(self.sandbox, self._qa_llm(), max_patch_bytes=self.s.max_patch_bytes, work_root=self.s.workspaces_dir,
                         allow_local_repos=self.s.allow_local_repos, token=self.s.github_token)
            report = await qa.audit(job, repo_url=job.repo_url, base_sha=base_sha, patch=result.patch, baseline=base.brief())
            (art_dir / "qa.json").write_text(report.model_dump_json(indent=1))
            self.db.event(key, "qa", {"passed": report.passed, "llm_review": report.llm_review, "summary": report.summary,
                                      "failed_checks": [c.name for c in report.checks if not c.passed]})
            self._account(key, meter, t0, qa_only=True)
            if not report.passed:
                self.db.update_outcome(key, succeeded=0, cost_usd=self.treasury.job_spend(key), hours=(time.monotonic() - t0) / 3600)
                return self._end(key, JobState.QA_FAILED, report.summary)

            # 5. DELIVER
            commit_sha = ""
            branch = f"fos/{_safe(job.external_id)[:40]}"
            try:
                await repo.checkout_new_branch(branch)
                commit_sha = await repo.commit_all(f"{job.title[:60]}\n\nAutomated fix. Independent QA passed.")
            except Exception as e:  # noqa: BLE001
                self.db.event(key, "commit_warning", str(e)[:200])
            delivery = Delivery(summary=result.summary or job.title, patch=result.patch, commit_sha=commit_sha, branch=branch, qa=report)
            if self.s.dry_run:
                self.db.update_outcome(key, hours=(time.monotonic() - t0) / 3600, cost_usd=self.treasury.job_spend(key))
                return self._end(key, JobState.READY_TO_DELIVER, "dry-run: patch + QA ready, nothing was claimed or delivered")
            if self.s.mode == "live" and self.s.require_llm_qa_in_live and not report.llm_review:
                return self._end(key, JobState.READY_TO_DELIVER, "live delivery requires LLM QA review; configure QA LLM")
            delivery.pr_url = await self._publish(job, repo, branch)
            ref = await ad.deliver(job, delivery)
            self.db.event(key, "delivered", {"ref": ref, "pr": delivery.pr_url, "commit": commit_sha})
            self.db.update_outcome(key, cost_usd=self.treasury.job_spend(key), hours=(time.monotonic() - t0) / 3600)
            return self._end(key, JobState.DELIVERED, None)
        except SpendDenied as e:
            return self._end(key, JobState.FAILED, str(e))
        except Exception as e:  # noqa: BLE001
            self.log(f"[exec] {key} crashed: {type(e).__name__}: {e}")
            return self._end(key, JobState.FAILED, f"{type(e).__name__}: {redact(str(e))[:300]}")
        finally:
            if not self.s.keep_workspaces:
                shutil.rmtree(ws_dir, ignore_errors=True)

    def _account(self, key: str, meter: CostMeter, t0: float, qa_only: bool = False) -> None:
        already = self.db.ledger_sum(("llm_cost",), job_key=key)
        self.treasury.record_cost(key, "llm_cost", meter.cost_usd - already, f"{meter.calls} calls, {meter.input_tokens}in/{meter.output_tokens}out")
        sandbox_hours = Decimal(str((time.monotonic() - t0) / 3600))
        prev = self.db.ledger_sum(("sandbox_cost",), job_key=key)
        self.treasury.record_cost(key, "sandbox_cost", sandbox_hours * self.s.compute_cost_per_hour_usd - prev, "wall-clock compute")

    async def _publish(self, job: Job, repo: Repo, branch: str) -> str:
        gh = parse_github_url(job.repo_url or "")
        if not gh or self.github is None:
            return ""
        owner, name = gh
        base = await self.github.default_branch(owner, name)
        fowner, fname = await self.github.ensure_fork(owner, name)
        await repo.push(f"https://github.com/{fowner}/{fname}.git", branch)
        body = f"Automated fix for: {job.title}\n\nIndependently verified: tests re-run on a clean checkout with the patch applied."
        return await self.github.open_pr(owner, name, fowner, branch, base, job.title[:120], body)

    def _end(self, key: str, state: JobState, error: str | None) -> JobState:
        self.db.set_state(key, state, error)
        self.db.event(key, "state", {"state": state.value, "error": error})
        self.log(f"[job] {key} -> {state.value}" + (f" ({error})" if error else ""))
        return state

    # ------------------------------------------------------------------ settle
    async def settle(self) -> int:
        n = 0
        for row in self.db.list_jobs(JobState.DELIVERED):
            job, _, _ = self.db.get_job(row["key"])  # type: ignore[misc]
            ad = self.adapters.get(job.marketplace)
            if not ad:
                continue
            try:
                ps = await ad.payment_status(job)
            except MarketplaceError as e:
                self.log(f"[settle] {job.key}: {e}")
                continue
            if not ps.settled:
                ts = self.db.event_ts(job.key, "delivered")
                if ts and (datetime.now(timezone.utc) - datetime.fromisoformat(ts)).days >= self.s.payment_timeout_days:
                    self.db.update_outcome(job.key, succeeded=0, paid=0)
                    self.db.set_state(job.key, JobState.FAILED, f"no payment within {self.s.payment_timeout_days} days")
                    self.db.event(job.key, "payment_timeout")
                continue
            if ps.settled:
                net = ps.amount_usd if ps.amount_usd is not None else job.budget_usd * (Decimal(1) - ad.capabilities.platform_fee_rate)
                self.treasury.record_payment(job.key, net, ad.capabilities.platform_fee_rate, ps.tx_ref)
                self.db.update_outcome(job.key, succeeded=1, revenue_usd=net, paid=1)
                self.db.set_state(job.key, JobState.SETTLED)
                self.db.event(job.key, "settled", {"amount": str(net), "tx": ps.tx_ref, "estimated": ps.amount_usd is None})
                n += 1
        return n

    # ---------------------------------------------------------------- run loop
    async def run_once(self, *, work: bool = True) -> dict:
        summary = {"scanned": 0, "executed": 0, "settled": 0}
        for name in self.adapters:
            try:
                summary["scanned"] += len(await self.scan_marketplace(name))
            except MarketplaceError as e:
                self.log(f"[scan] {name}: {e}")
        if work:
            active = self.db.count_state(JobState.CLAIMED, JobState.WORKING)
            cands = []
            for row in self.db.list_jobs(JobState.APPROVED):
                rec = self.db.get_job(row["key"])
                if rec and rec[2] and rec[0].marketplace in self.adapters:
                    cands.append((rec[0], rec[2], self.adapters[rec[0].marketplace].capabilities.platform_fee_rate))
            for job, _, _ in bandit.rank(self.engine, cands):      # Thompson sampling: exploit proven lanes, explore uncertain ones
                if active >= self.s.max_concurrent_jobs or self.treasury.killed():
                    break
                await self.execute(job.key)
                summary["executed"] += 1
        summary["settled"] = await self.settle()
        return summary
