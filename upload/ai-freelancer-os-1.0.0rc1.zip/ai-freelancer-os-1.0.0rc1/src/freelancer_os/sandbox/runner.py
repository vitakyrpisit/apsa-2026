"""Real sandboxes. DockerSandbox is the production backend; LocalSandbox is for dev/tests only."""
from __future__ import annotations

import asyncio
import os
import re
import resource
import signal
import sys
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

MAX_OUT = 200_000


@dataclass
class RunResult:
    exit_code: int
    stdout: str
    stderr: str
    duration_s: float
    timed_out: bool = False

    @property
    def ok(self) -> bool:
        return self.exit_code == 0 and not self.timed_out


class Sandbox(Protocol):
    async def run(self, cmd: list[str], *, workdir: Path, network: bool = False, timeout: int | None = None,
                  env: dict[str, str] | None = None) -> RunResult: ...


def _clip(b: bytes) -> str:
    s = b.decode("utf-8", "replace")
    return s if len(s) <= MAX_OUT else s[:MAX_OUT // 2] + "\n...[truncated]...\n" + s[-MAX_OUT // 2:]


_SAFE_ENV_KEY = re.compile(r"^[A-Z_][A-Z0-9_]*$")


class DockerSandbox:
    """`docker run` with: no network by default, memory/cpu/pids limits, all caps dropped,
    no-new-privileges, non-root user, only the workspace mounted, scrubbed environment."""

    def __init__(self, image: str, cpus: float = 2.0, memory_mb: int = 4096, timeout_s: int = 900, docker_bin: str = "docker"):
        self.image, self.cpus, self.memory_mb, self.timeout_s, self.docker_bin = image, cpus, memory_mb, timeout_s, docker_bin

    def build_args(self, cmd: list[str], workdir: Path, network: bool, env: dict[str, str] | None, name: str) -> list[str]:
        uid, gid = (os.getuid(), os.getgid()) if hasattr(os, "getuid") else (1000, 1000)
        args = [self.docker_bin, "run", "--rm", "--name", name,
                "--network", "bridge" if network else "none",
                "--memory", f"{self.memory_mb}m", "--memory-swap", f"{self.memory_mb}m",
                "--cpus", str(self.cpus), "--pids-limit", "512",
                "--cap-drop", "ALL", "--security-opt", "no-new-privileges",
                "--user", f"{uid}:{gid}",
                "--tmpfs", "/tmp:rw,exec,size=1g",
                "-v", f"{Path(workdir).resolve()}:/workspace:rw", "-w", "/workspace",
                "-e", "HOME=/tmp", "-e", "PYTHONDONTWRITEBYTECODE=1", "-e", "PIP_DISABLE_PIP_VERSION_CHECK=1"]
        for k, v in (env or {}).items():
            if not _SAFE_ENV_KEY.match(k):
                raise ValueError(f"bad env key {k!r}")
            args += ["-e", f"{k}={v}"]
        return args + [self.image, *cmd]

    async def run(self, cmd, *, workdir, network=False, timeout=None, env=None) -> RunResult:
        name = f"fos-{uuid.uuid4().hex[:12]}"
        args = self.build_args(cmd, workdir, network, env, name)
        t0, timeout = time.monotonic(), timeout or self.timeout_s
        try:
            proc = await asyncio.create_subprocess_exec(*args, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        except FileNotFoundError:
            return RunResult(127, "", "docker binary not found", 0.0)
        try:
            out, err = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            return RunResult(proc.returncode or 0, _clip(out), _clip(err), time.monotonic() - t0)
        except asyncio.TimeoutError:
            kill = await asyncio.create_subprocess_exec(self.docker_bin, "kill", name, stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL)
            await kill.wait()
            try:
                proc.kill()
            except ProcessLookupError:
                pass
            return RunResult(124, "", f"timeout after {timeout}s", time.monotonic() - t0, timed_out=True)


class LocalSandbox:
    """Runs on the host with a scrubbed env, rlimits and process-group kill. NOT a security boundary:
    refuse in live mode unless explicitly allowed. Used by tests and offline evals."""

    def __init__(self, cpus: float = 2.0, memory_mb: int = 4096, timeout_s: int = 300, python: str | None = None):
        self.memory_mb, self.timeout_s, self.python = memory_mb, timeout_s, python or sys.executable

    def _limits(self):
        mem = self.memory_mb * 1024 * 1024
        def apply():
            os.setsid()
            try:
                resource.setrlimit(resource.RLIMIT_AS, (mem * 2, mem * 2))
                resource.setrlimit(resource.RLIMIT_NPROC, (512, 512))
            except (ValueError, OSError):
                pass
        return apply

    async def run(self, cmd, *, workdir, network=False, timeout=None, env=None) -> RunResult:
        cmd = [self.python if c == "python" else c for c in cmd]
        clean = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "HOME": str(Path(workdir) / ".home"),
                 "LANG": "C.UTF-8", "PYTHONDONTWRITEBYTECODE": "1", "PYTHONHASHSEED": "0", **(env or {})}
        (Path(workdir) / ".home").mkdir(exist_ok=True)
        t0, timeout = time.monotonic(), timeout or self.timeout_s
        proc = await asyncio.create_subprocess_exec(*cmd, cwd=str(workdir), env=clean, stdout=asyncio.subprocess.PIPE,
                                                    stderr=asyncio.subprocess.PIPE, preexec_fn=self._limits())
        try:
            out, err = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            return RunResult(proc.returncode or 0, _clip(out), _clip(err), time.monotonic() - t0)
        except asyncio.TimeoutError:
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            await proc.wait()
            return RunResult(124, "", f"timeout after {timeout}s", time.monotonic() - t0, timed_out=True)


def make_sandbox(settings) -> Sandbox:
    if settings.sandbox_backend == "docker":
        return DockerSandbox(settings.sandbox_image, settings.sandbox_cpus, settings.sandbox_memory_mb, settings.sandbox_timeout_s)
    if settings.mode == "live" and not settings.allow_unsafe_local_sandbox:
        raise RuntimeError("Local sandbox is not isolated; refusing in live mode (set ALLOW_UNSAFE_LOCAL_SANDBOX=true to override).")
    return LocalSandbox(settings.sandbox_cpus, settings.sandbox_memory_mb, settings.sandbox_timeout_s)


# ------------------------------------------------------------------ test runner
_SUMMARY = re.compile(r"=+\s*(?P<body>.*?)\s+in\s+[\d.]+s")
_COUNT = re.compile(r"(\d+)\s+(passed|failed|errors?|skipped|xfailed|xpassed|deselected|warnings?)")


@dataclass
class TestResult:
    ran: bool
    passed: int
    failed: int
    errors: int
    skipped: int
    exit_code: int
    timed_out: bool
    output: str

    @property
    def green(self) -> bool:
        return self.ran and self.exit_code == 0 and self.passed > 0 and self.failed == 0 and self.errors == 0 and not self.timed_out

    def brief(self) -> dict:
        return {"ran": self.ran, "passed": self.passed, "failed": self.failed, "errors": self.errors,
                "skipped": self.skipped, "exit_code": self.exit_code, "timed_out": self.timed_out, "green": self.green}


def parse_pytest(res: RunResult) -> TestResult:
    """Parse the REAL pytest summary line. Never trusts free text like '84 passed' elsewhere in output."""
    text = res.stdout + "\n" + res.stderr
    counts = {"passed": 0, "failed": 0, "error": 0, "skipped": 0}
    last = None
    for line in text.splitlines():
        m = _SUMMARY.search(line)
        if m:
            last = m.group("body")
    if last is None:
        for line in reversed(text.splitlines()):  # -q style: "3 passed in 0.02s"
            if re.search(r"\b(passed|failed|error)\b.*\bin\s+[\d.]+s", line):
                last = line
                break
    if last:
        for n, kind in _COUNT.findall(last):
            kind = "error" if kind.startswith("error") else kind
            if kind in counts:
                counts[kind] += int(n)
    ran = last is not None
    return TestResult(ran, counts["passed"], counts["failed"], counts["error"], counts["skipped"], res.exit_code, res.timed_out, text[-6000:])


TEST_CMD = ["python", "-m", "pytest", "-q", "-x", "--no-header", "-p", "no:cacheprovider", "-W", "ignore"]


async def run_tests(sandbox: Sandbox, workdir: Path, target: str | None = None, timeout: int | None = None, full: bool = False) -> TestResult:
    cmd = [c for c in TEST_CMD if not (full and c == "-x")]
    if target:
        if not re.fullmatch(r"[\w./:\-\[\]]+", target) or target.startswith("-") or ".." in target:
            raise ValueError("invalid test target")
        cmd.append(target)
    env = {}
    deps = Path(workdir) / ".deps"
    prefix = "/workspace" if isinstance(sandbox, DockerSandbox) else str(Path(workdir).resolve())
    env["PYTHONPATH"] = f"{prefix}/.deps:{prefix}:{prefix}/src" if deps.exists() else f"{prefix}:{prefix}/src"
    res = await sandbox.run(cmd, workdir=workdir, network=False, timeout=timeout, env=env)
    return parse_pytest(res)


async def install_requirements(sandbox: Sandbox, workdir: Path, timeout: int = 600) -> RunResult | None:
    """Network phase: install declared deps into ./.deps (the only phase with network access)."""
    req = Path(workdir) / "requirements.txt"
    if not req.exists():
        return None
    return await sandbox.run(["python", "-m", "pip", "install", "--no-input", "-q", "-r", "requirements.txt", "--target", ".deps"],
                             workdir=workdir, network=True, timeout=timeout)
