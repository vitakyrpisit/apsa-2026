"""Treasury: spend caps, kill switch, honest P&L. Only SETTLED, adapter-confirmed payments count as revenue."""
from __future__ import annotations

from decimal import Decimal
from typing import Any

from freelancer_os.config import Settings
from freelancer_os.storage.db import Database


class SpendDenied(RuntimeError):
    pass


class Treasury:
    def __init__(self, settings: Settings, db: Database):
        self.s, self.db = settings, db

    def killed(self) -> bool:
        return self.s.kill_switch_file.exists()

    def assert_running(self) -> None:
        if self.killed():
            raise SpendDenied(f"kill switch engaged ({self.s.kill_switch_file})")

    def job_spend(self, key: str) -> Decimal:
        return self.db.ledger_sum(("llm_cost", "sandbox_cost", "other_cost"), job_key=key)

    def can_spend(self, key: str, amount: Decimal) -> bool:
        return (not self.killed()
                and self.db.spend_today() + amount <= self.s.max_daily_spend_usd
                and self.job_spend(key) + amount <= self.s.max_job_spend_usd)

    def record_cost(self, key: str, kind: str, amount: Decimal, note: str = "") -> None:
        if amount > 0:
            self.db.ledger_add(kind, amount, key, note)

    def record_payment(self, key: str, gross: Decimal, fee_rate: Decimal, tx_ref: str) -> None:
        self.db.ledger_add("payment_in", gross, key, f"tx={tx_ref}")

    def pnl(self) -> dict[str, Any]:
        rev = self.db.ledger_sum(("payment_in",))
        cost = self.db.ledger_sum(("llm_cost", "sandbox_cost", "other_cost"))
        return {"revenue_confirmed_usd": str(rev), "costs_usd": str(cost), "net_usd": str(rev - cost),
                "spend_today_usd": str(self.db.spend_today()), "daily_cap_usd": str(self.s.max_daily_spend_usd),
                "note": "revenue counts only payments confirmed by the marketplace/on-chain reference"}
