"""Payout wallets: PUBLIC addresses only, with real checksum validation per chain.

The agent never holds a spending key. A wrong address means lost funds, so every address is validated
(EIP-55 checksum for EVM, base58check for TRON, bech32/bech32m for Bitcoin, 32-byte key for Solana)
and every network must be explicitly *confirmed by the operator* as able to receive deposits on that exact network
before the doctor reports READY (exchange deposit addresses often do NOT support every EVM chain).
"""
from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass

_B58 = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"


def _b58decode(s: str) -> bytes | None:
    n = 0
    for ch in s:
        i = _B58.find(ch)
        if i < 0:
            return None
        n = n * 58 + i
    raw = n.to_bytes((n.bit_length() + 7) // 8, "big")
    return b"\x00" * (len(s) - len(s.lstrip("1"))) + raw


# ------------------------------------------------------------------ keccak-256 (EIP-55 needs it; hashlib has only SHA3)
_RC = [0x0000000000000001, 0x0000000000008082, 0x800000000000808A, 0x8000000080008000, 0x000000000000808B, 0x0000000080000001,
       0x8000000080008081, 0x8000000000008009, 0x000000000000008A, 0x0000000000000088, 0x0000000080008009, 0x000000008000000A,
       0x000000008000808B, 0x800000000000008B, 0x8000000000008089, 0x8000000000008003, 0x8000000000008002, 0x8000000000000080,
       0x000000000000800A, 0x800000008000000A, 0x8000000080008081, 0x8000000000008080, 0x0000000080000001, 0x8000000080008008]
_ROT = [[0, 36, 3, 41, 18], [1, 44, 10, 45, 2], [62, 6, 43, 15, 61], [28, 55, 25, 21, 56], [27, 20, 39, 8, 14]]
_M = (1 << 64) - 1


def _rol(x: int, n: int) -> int:
    n %= 64
    return ((x << n) | (x >> (64 - n))) & _M if n else x


def _f1600(a: list[list[int]]) -> None:
    for rc in _RC:
        c = [a[x][0] ^ a[x][1] ^ a[x][2] ^ a[x][3] ^ a[x][4] for x in range(5)]
        d = [c[(x - 1) % 5] ^ _rol(c[(x + 1) % 5], 1) for x in range(5)]
        for x in range(5):
            for y in range(5):
                a[x][y] ^= d[x]
        b = [[0] * 5 for _ in range(5)]
        for x in range(5):
            for y in range(5):
                b[y][(2 * x + 3 * y) % 5] = _rol(a[x][y], _ROT[x][y])
        for x in range(5):
            for y in range(5):
                a[x][y] = b[x][y] ^ ((~b[(x + 1) % 5][y]) & b[(x + 2) % 5][y])
        a[0][0] ^= rc


def keccak256(data: bytes) -> bytes:
    rate = 136
    p = bytearray(data) + b"\x01"
    p += b"\x00" * ((-len(p)) % rate)
    p[-1] |= 0x80
    a = [[0] * 5 for _ in range(5)]
    for off in range(0, len(p), rate):
        for i in range(rate // 8):
            a[i % 5][i // 5] ^= int.from_bytes(p[off + 8 * i: off + 8 * i + 8], "little")
        _f1600(a)
    out = b"".join(a[i % 5][i // 5].to_bytes(8, "little") for i in range(4))
    return out[:32]


# ------------------------------------------------------------------------------------------------ validators
def validate_evm(addr: str) -> tuple[bool, str]:
    if not re.fullmatch(r"0x[0-9a-fA-F]{40}", addr or ""):
        return False, "not a 0x + 40 hex address"
    body = addr[2:]
    if body == body.lower() or body == body.upper():
        return True, "valid format (no checksum casing: cannot detect typos)"
    h = keccak256(body.lower().encode()).hex()
    ok = all((c.upper() if int(h[i], 16) >= 8 else c.lower()) == c for i, c in enumerate(body) if c.isalpha())
    return (True, "valid EIP-55 checksum") if ok else (False, "EIP-55 checksum mismatch: likely a typo")


def validate_solana(addr: str) -> tuple[bool, str]:
    raw = _b58decode(addr or "")
    return (True, "valid 32-byte ed25519 public key") if raw is not None and len(raw) == 32 else (False, "not a 32-byte base58 key")


def validate_tron(addr: str) -> tuple[bool, str]:
    raw = _b58decode(addr or "")
    if raw is None or len(raw) != 25 or raw[0] != 0x41:
        return False, "not a TRON base58check address (0x41 prefix, 25 bytes)"
    return (True, "valid base58check") if hashlib.sha256(hashlib.sha256(raw[:21]).digest()).digest()[:4] == raw[21:] else (False, "checksum mismatch")


_BECH = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"


def _polymod(values: list[int]) -> int:
    gen = [0x3B6A57B2, 0x26508E6D, 0x1EA119FA, 0x3D4233DD, 0x2A1462B3]
    chk = 1
    for v in values:
        b = chk >> 25
        chk = (chk & 0x1FFFFFF) << 5 ^ v
        for i in range(5):
            chk ^= gen[i] if (b >> i) & 1 else 0
    return chk


def validate_btc(addr: str) -> tuple[bool, str]:
    a = addr or ""
    if a.lower().startswith("bc1"):
        if a != a.lower() and a != a.upper():
            return False, "mixed-case bech32"
        a = a.lower()
        pos = a.rfind("1")
        hrp, data = a[:pos], a[pos + 1:]
        if pos < 1 or len(data) < 7 or any(c not in _BECH for c in data):
            return False, "bad bech32 characters/length"
        vals = [_BECH.index(c) for c in data]
        const = _polymod([ord(x) >> 5 for x in hrp] + [0] + [ord(x) & 31 for x in hrp] + vals)
        wv = vals[0]
        if wv == 0 and const == 1:
            return True, "valid bech32 (segwit v0)"
        if wv >= 1 and const == 0x2BC830A3:
            return True, "valid bech32m (taproot/v1+)"
        return False, "bech32 checksum mismatch"
    raw = _b58decode(a)
    if raw and len(raw) == 25 and raw[0] in (0x00, 0x05) and hashlib.sha256(hashlib.sha256(raw[:21]).digest()).digest()[:4] == raw[21:]:
        return True, "valid base58check (legacy/p2sh)"
    return False, "not a valid bitcoin address"


VALIDATORS = {"evm": validate_evm, "solana": validate_solana, "tron": validate_tron, "bitcoin": validate_btc}

# marketplace rail -> wallet family that receives it
RAIL_FAMILY = {"base": "evm", "ethereum": "evm", "arbitrum": "evm", "solana": "solana", "tron": "tron", "bitcoin": "bitcoin"}


@dataclass
class WalletCheck:
    network: str
    address: str
    valid: bool
    detail: str
    confirmed: bool


class Wallets:
    """Resolves which public address receives which rail and whether the operator confirmed it can accept it."""

    def __init__(self, evm: str = "", solana: str = "", tron: str = "", bitcoin: str = "", confirmed: set[str] | None = None):
        self.addr = {"evm": evm.strip(), "solana": solana.strip(), "tron": tron.strip(), "bitcoin": bitcoin.strip()}
        self.confirmed = {c.strip().lower() for c in (confirmed or set()) if c.strip()}

    @classmethod
    def from_settings(cls, s) -> "Wallets":
        return cls(s.wallet_evm, s.wallet_solana, s.wallet_tron, s.wallet_bitcoin, {x for x in s.wallet_confirmed_networks.split(",")})

    def check(self, network: str) -> WalletCheck:
        fam = RAIL_FAMILY.get(network.lower())
        if not fam:
            return WalletCheck(network, "", False, f"unknown network {network!r}", False)
        a = self.addr[fam]
        if not a:
            return WalletCheck(network, "", False, "no address configured", False)
        ok, detail = VALIDATORS[fam](a)
        return WalletCheck(network, a, ok, detail, network.lower() in self.confirmed)

    def address_for(self, network: str) -> str:
        """Address to hand to a marketplace; raises unless valid AND operator-confirmed for that network."""
        c = self.check(network)
        if not c.valid:
            raise ValueError(f"{network}: {c.detail}")
        if not c.confirmed:
            raise ValueError(f"{network}: operator has not confirmed this address can receive deposits on {network} (WALLET_CONFIRMED_NETWORKS)")
        return c.address

    def report(self) -> list[WalletCheck]:
        return [self.check(n) for n in ("base", "ethereum", "arbitrum", "solana", "tron", "bitcoin")]
