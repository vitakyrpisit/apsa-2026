"""Control API. Every route except /health requires `Authorization: Bearer <FOS_API_TOKEN>`. Reports REAL state only."""
from __future__ import annotations

import hmac
from typing import Any

from fastapi import Depends, FastAPI, Header, HTTPException

from freelancer_os import __version__
from freelancer_os.config import Settings
from freelancer_os.domain import Job, JobState
from freelancer_os.opportunity.engine import OpportunityEngine
from freelancer_os.pipeline import Pipeline
from freelancer_os.marketplaces.base import Capabilities
from decimal import Decimal


def create_app(settings: Settings, pipeline: Pipeline) -> FastAPI:
    if not settings.api_token or len(settings.api_token) < 16:
        raise RuntimeError("API_TOKEN must be set (>= 16 chars). Run `fos init` to generate one.")
    app = FastAPI(title="AI Freelancer OS", version=__version__)

    def auth(authorization: str = Header(default="")) -> None:
        tok = authorization.removeprefix("Bearer ").strip()
        if not hmac.compare_digest(tok.encode(), settings.api_token.encode()):
            raise HTTPException(401, "invalid token")

    @app.get("/health")
    async def health() -> dict[str, Any]:
        return {"status": "ok", "version": __version__}

    @app.get("/v1/status", dependencies=[Depends(auth)])
    async def status() -> dict[str, Any]:
        db = pipeline.db
        return {"mode": settings.mode, "dry_run": settings.dry_run, "kill_switch": pipeline.treasury.killed(),
                "marketplaces": list(pipeline.adapters), "pnl": pipeline.treasury.pnl(),
                "jobs": {s.value: db.count_state(s) for s in JobState}, "calibration": pipeline.engine.calibration_report()}

    @app.get("/v1/jobs", dependencies=[Depends(auth)])
    async def jobs(state: str | None = None, limit: int = 100) -> list[dict[str, Any]]:
        try:
            st = JobState(state) if state else None
        except ValueError:
            raise HTTPException(400, "unknown state")
        return pipeline.db.list_jobs(st, min(limit, 500))

    @app.get("/v1/jobs/{key:path}", dependencies=[Depends(auth)])
    async def job(key: str) -> dict[str, Any]:
        rec = pipeline.db.get_job(key)
        if not rec:
            raise HTTPException(404, "not found")
        j, st, sc = rec
        return {"state": st.value, "job": j.model_dump(mode="json", exclude={"raw", "acceptance_tests"}),
                "score": sc.model_dump(mode="json") if sc else None, "events": pipeline.db.events(key)}

    @app.post("/v1/approvals/{key:path}/approve", dependencies=[Depends(auth)])
    async def approve(key: str) -> dict[str, str]:
        try:
            pipeline.approve(key)
        except ValueError as e:
            raise HTTPException(409, str(e))
        return {"state": "APPROVED"}

    @app.post("/v1/approvals/{key:path}/reject", dependencies=[Depends(auth)])
    async def reject(key: str) -> dict[str, str]:
        pipeline.reject(key)
        return {"state": "REJECTED"}

    @app.get("/v1/pnl", dependencies=[Depends(auth)])
    async def pnl() -> dict[str, Any]:
        return pipeline.treasury.pnl()

    @app.post("/v1/score", dependencies=[Depends(auth)])
    async def score(job: Job, marketplace_fee: float = 0.10, win_model: str = "exclusive_claim") -> dict[str, Any]:
        """Score an arbitrary posting with the same engine used by the pipeline (no hard-coded outputs)."""
        caps = Capabilities(win_model, Decimal(str(marketplace_fee)), "n/a", requires_funding=False)  # type: ignore[arg-type]
        return OpportunityEngine(settings, pipeline.db).score(job, caps).model_dump(mode="json")

    @app.post("/v1/kill", dependencies=[Depends(auth)])
    async def kill() -> dict[str, str]:
        settings.kill_switch_file.parent.mkdir(parents=True, exist_ok=True)
        settings.kill_switch_file.write_text("killed via API")
        return {"kill_switch": "engaged"}

    return app
