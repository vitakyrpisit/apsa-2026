"""`fos` command line."""
from __future__ import annotations

import argparse
import asyncio
import json
import secrets
import shutil
import subprocess
import sys
from pathlib import Path

from freelancer_os import __version__
from freelancer_os.config import Settings, load_settings
from freelancer_os.domain import Job, JobState
from freelancer_os.marketplaces.registry import build_adapters
from freelancer_os.pipeline import Pipeline
from freelancer_os.opportunity.health import CircuitBreaker
from freelancer_os.storage.db import Database
from freelancer_os.treasury.wallets import Wallets


def bootstrap_secrets(s: Settings) -> None:
    """CI runners have no persistent disk: materialise the agent identity from a secret, 0600, once."""
    if s.basedagents_keypair_json and not s.basedagents_keypair_path.exists():
        import os
        s.basedagents_keypair_path.parent.mkdir(parents=True, exist_ok=True)
        fd = os.open(s.basedagents_keypair_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            f.write(s.basedagents_keypair_json)


def _pipeline(s: Settings) -> Pipeline:
    s.ensure_dirs()
    bootstrap_secrets(s)
    return Pipeline(s, Database(s.db_path), build_adapters(s))


def cmd_init(s: Settings, a) -> int:
    s.ensure_dirs()
    env = Path(".env")
    if not env.exists():
        tmpl = Path(".env.example")
        text = tmpl.read_text() if tmpl.exists() else ""
        env.write_text(text.replace("API_TOKEN=change-me-to-a-long-random-string", f"API_TOKEN={secrets.token_urlsafe(32)}"))
        print("created .env (edit it: LLM key, wallet address, marketplaces). Mode is mock + dry-run by default.")
    else:
        print(".env already exists")
    print(f"data dir: {s.data_dir.resolve()}")
    return 0


async def _doctor(s: Settings, live: bool) -> int:
    rows: list[tuple[str, bool, str, bool]] = []  # name, ok, detail, required
    add = lambda n, ok, d="", req=True: rows.append((n, ok, d, req))
    add("python >= 3.11", sys.version_info >= (3, 11), sys.version.split()[0])
    add("git installed", shutil.which("git") is not None, shutil.which("git") or "missing")
    add("mode", True, f"{s.mode}, dry_run={s.dry_run}", False)
    if s.sandbox_backend == "docker":
        d = shutil.which("docker")
        add("docker installed", d is not None, d or "missing: install Docker or use SANDBOX_BACKEND=local for dev only")
        if d:
            r = subprocess.run(["docker", "image", "inspect", s.sandbox_image], capture_output=True)
            add("sandbox image built", r.returncode == 0, s.sandbox_image if r.returncode == 0 else "run: make sandbox-image")
            if r.returncode == 0:
                from freelancer_os.sandbox.runner import DockerSandbox
                import tempfile
                with tempfile.TemporaryDirectory() as td:
                    res = await DockerSandbox(s.sandbox_image, timeout_s=60).run(["python", "-c", "import socket,sys\ntry:\n socket.create_connection(('1.1.1.1',53),2);print('NET')\nexcept OSError:\n print('NO_NET')"], workdir=Path(td))
                add("sandbox runs & has NO network", res.ok and "NO_NET" in res.stdout, res.stdout.strip() or res.stderr[:150])
    else:
        add("local sandbox (dev only)", s.mode != "live" or s.allow_unsafe_local_sandbox, "NOT isolated: never use with untrusted live jobs")
    if s.llm_provider != "none":
        keys = {"anthropic": s.anthropic_api_key, "gemini": s.gemini_api_key, "zai": s.zai_api_key, "openai_compat": s.openai_compat_api_key}
        key = keys[s.llm_provider]
        add(f"{s.llm_provider} API key set", bool(key), "set" if key else "missing")
    else:
        add("LLM configured", False, "LLM_PROVIDER=none: agent cannot do work", s.mode == "live")
    w = Wallets.from_settings(s)
    needed = {"base"} if s.mode == "live" else set()
    for c in w.report():
        add(f"wallet {c.network}", c.valid or not c.address, (c.address[:12] + "…  " if c.address else "") + c.detail + ("" if c.confirmed or not c.address else "  [NOT confirmed to receive on this network]"), False)
    for n in needed:
        c = w.check(n)
        add(f"payout wallet usable on {n}", c.valid and c.confirmed, c.detail if not c.confirmed else "valid + confirmed")
    add("GITHUB_TOKEN (needed to open PRs)", bool(s.github_token), "set" if s.github_token else "missing", s.mode == "live")
    add("API token set", len(s.api_token) >= 16, "ok" if len(s.api_token) >= 16 else "run `fos init`", False)
    add("spend caps sane", s.max_job_spend_usd <= s.max_daily_spend_usd, f"job ${s.max_job_spend_usd} / day ${s.max_daily_spend_usd}")
    if live:
        for name, ad in build_adapters(s).items():
            for n, ok, d in await ad.doctor():
                add(n, ok, d)
            await ad.aclose()
    bad = False
    for n, ok, d, req in rows:
        print(f"[{'OK ' if ok else ('FAIL' if req else 'warn')}] {n}: {d}")
        bad |= (not ok and req)
    print("\nREADY" if not bad else "\nNOT READY: fix the FAIL items above")
    return 1 if bad else 0


def cmd_register(s: Settings, a) -> int:
    if a.marketplace != "basedagents":
        print("Only `basedagents` has an automated registration flow. TaskBounty/AgentGigs: sign up in their dashboards (see docs/MARKETPLACES.md).")
        return 2
    from basedagents import register_or_load
    s.ensure_dirs()
    manifest = json.loads(Path(a.manifest).read_text())
    agent_id = register_or_load(name=manifest["name"], description=manifest["description"], capabilities=manifest.get("capabilities", []),
                                protocols=manifest.get("protocols", ["https"]), tags=manifest.get("tags"), keypair_path=s.basedagents_keypair_path,
                                api_url=s.basedagents_api_url, contact_endpoint=manifest.get("contact_endpoint") or None)
    print(f"registered/loaded agent: {agent_id}\nkeypair: {s.basedagents_keypair_path} (back it up, it IS the agent identity)\n"
          "NEXT: set the payout wallet on your BasedAgents agent profile (bounty claims fail with 409 wallet_required otherwise).")
    return 0


async def _run(s: Settings, a) -> int:
    p = _pipeline(s)
    try:
        if a.cmd == "scan":
            for name in p.adapters:
                await p.scan_marketplace(name, a.limit)
        elif a.cmd == "run-once":
            print(json.dumps(await p.run_once(work=not a.no_work)))
        elif a.cmd == "jobs":
            for j in p.db.list_jobs(JobState(a.state) if a.state else None, a.limit):
                print(f"{j['state']:<18} {j['key']:<40} ${j['budget_usd']}  profit={j['expected_profit']}  {j['title'][:50]}")
        elif a.cmd == "show":
            rec = p.db.get_job(a.key)
            if not rec:
                print("not found"); return 1
            print(json.dumps({"state": rec[1].value, "score": rec[2].model_dump(mode="json") if rec[2] else None, "events": p.db.events(a.key)}, indent=1, default=str))
        elif a.cmd == "approve":
            p.approve(a.key)
        elif a.cmd == "reject":
            p.reject(a.key)
        elif a.cmd == "execute":
            print((await p.execute(a.key)).value)
        elif a.cmd == "settle":
            print(f"settled: {await p.settle()}")
        elif a.cmd == "wallets":
            for c in Wallets.from_settings(s).report():
                print(f"{c.network:<9} {'VALID  ' if c.valid else 'INVALID'} {'confirmed' if c.confirmed else 'UNCONFIRMED':<12} {c.address or '-'}  ({c.detail})")
            print("\nSet WALLET_CONFIRMED_NETWORKS only after you have verified each network can receive deposits at that address.")
        elif a.cmd == "wallet-message":
            ba = p.adapters.get("basedagents")
            if ba is None:
                print("enable basedagents in ENABLED_MARKETPLACES first"); return 1
            addr = a.address or s.wallet_evm
            print(ba.wallet_bind_message(ba.keypair().agent_id, addr, a.network))
            print("\n--- Sign the text ABOVE with the wallet that owns", addr, "(personal_sign / 'Sign message' in MetaMask, Rabby, Ledger Live...).", file=sys.stderr)
            print("--- Save the message to a file, then: fos wallet-bind --message-file msg.txt --signature 0x...   (valid 15 min)", file=sys.stderr)
        elif a.cmd == "wallet-bind":
            ba = p.adapters.get("basedagents")
            msg = Path(a.message_file).read_text().rstrip("\n")
            print(json.dumps(await ba.set_wallet(a.address or s.wallet_evm, a.network, msg, a.signature), indent=1, default=str))
        elif a.cmd == "breaker":
            b = CircuitBreaker(s, p.db).status()
            print(f"breaker {'OPEN' if b.open else 'closed'}: n={b.n} success_rate={b.success_rate:.2f} lower_bound={b.lower_bound:.2f} net_30d=${b.net_30d_usd}  {b.reason}")
        elif a.cmd == "pnl":
            print(json.dumps(p.treasury.pnl(), indent=1)); print(json.dumps(p.engine.calibration_report(), indent=1))
        elif a.cmd == "score":
            job = Job.model_validate_json(Path(a.file).read_text())
            ad = p.adapters.get(job.marketplace) or next(iter(p.adapters.values()))
            print(p.engine.score(job, ad.capabilities).model_dump_json(indent=1))
        elif a.cmd == "worker":
            print(f"worker started (mode={s.mode}, dry_run={s.dry_run}, every {a.interval}s). touch {s.kill_switch_file} to stop work.")
            while True:
                if p.treasury.killed():
                    print("kill switch engaged; idle")
                else:
                    try:
                        print(json.dumps(await p.run_once(work=True)))
                    except Exception as e:  # noqa: BLE001
                        print(f"cycle error: {type(e).__name__}: {e}")
                await asyncio.sleep(a.interval)
        elif a.cmd == "serve":
            import uvicorn
            from freelancer_os.api.app import create_app
            uvicorn.run(create_app(s, p), host=s.api_host, port=s.api_port)
    finally:
        for ad in p.adapters.values():
            await ad.aclose()
    return 0


async def _eval(s: Settings, a) -> int:
    from freelancer_os.evals.golden import TASKS, run_all
    tasks = [t for t in TASKS if not a.only or t.name in a.only]
    if a.llm:
        tasks = [t for t in tasks if t.script is not None and not t.name.startswith("trap_")] + [t for t in tasks if t.name.startswith("trap_")]
        base = s.model_copy(update={"mode": "mock", "dry_run": True, "allow_local_repos": True, "enabled_marketplaces": "mock"})
        results = await run_all(tasks, scripted=False, base_settings=base)
        for r in results:
            print(f"{'PASS' if r.ok else 'FAIL'}  {r.name}: expected {r.expected}, got {r.got}  {r.detail[:100]}")
        real = [r for r in results if not r.name.startswith("trap_")]
        print(f"\nREAL-LLM pass@1 on capability tasks: {sum(r.ok for r in real)}/{len(real)}  (negative controls with no script are only meaningful scripted)")
        return 0
    results = await run_all(tasks, scripted=True)
    for r in results:
        print(f"{'PASS' if r.ok else 'FAIL'}  {r.name}: expected {r.expected}, got {r.got}  {r.detail[:90]}")
    ok = all(r.ok for r in results)
    print(f"\n{sum(r.ok for r in results)}/{len(results)} golden checks passed (scripted: validates plumbing + cheating detection, not LLM skill)")
    return 0 if ok else 1


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="fos", description=f"AI Freelancer OS {__version__}")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("init")
    d = sub.add_parser("doctor"); d.add_argument("--live", action="store_true", help="also call marketplace APIs")
    r = sub.add_parser("register"); r.add_argument("marketplace"); r.add_argument("--manifest", default="config/agent.manifest.json")
    sc = sub.add_parser("scan"); sc.add_argument("--limit", type=int, default=30)
    ro = sub.add_parser("run-once"); ro.add_argument("--no-work", action="store_true")
    j = sub.add_parser("jobs"); j.add_argument("--state"); j.add_argument("--limit", type=int, default=50)
    for n in ("show", "approve", "reject", "execute"):
        x = sub.add_parser(n); x.add_argument("key")
    sub.add_parser("settle"); sub.add_parser("pnl"); sub.add_parser("wallets"); sub.add_parser("breaker")
    wm = sub.add_parser("wallet-message"); wm.add_argument("--address"); wm.add_argument("--network", default="eip155:8453")
    wb = sub.add_parser("wallet-bind"); wb.add_argument("--address"); wb.add_argument("--network", default="eip155:8453")
    wb.add_argument("--message-file", required=True); wb.add_argument("--signature", required=True)
    s_ = sub.add_parser("score"); s_.add_argument("file")
    w = sub.add_parser("worker"); w.add_argument("--interval", type=int, default=300)
    sub.add_parser("serve")
    e = sub.add_parser("eval"); e.add_argument("--llm", action="store_true", help="use the configured real LLM (costs money)"); e.add_argument("--only", nargs="*")
    sub.add_parser("kill"); sub.add_parser("resume")
    a = ap.parse_args(argv)
    s = load_settings()
    if a.cmd == "init":
        return cmd_init(s, a)
    if a.cmd == "register":
        return cmd_register(s, a)
    if a.cmd == "kill":
        s.kill_switch_file.parent.mkdir(parents=True, exist_ok=True); s.kill_switch_file.write_text("killed by CLI"); print("kill switch engaged"); return 0
    if a.cmd == "resume":
        s.kill_switch_file.unlink(missing_ok=True); print("kill switch cleared"); return 0
    if a.cmd == "doctor":
        return asyncio.run(_doctor(s, a.live))
    if a.cmd == "eval":
        return asyncio.run(_eval(s, a))
    return asyncio.run(_run(s, a))


if __name__ == "__main__":
    raise SystemExit(main())
