import json
from decimal import Decimal
import pytest
from freelancer_os.domain import JobState, Job
from freelancer_os.evals.golden import TASKS, run_task, eval_settings, build_repo
from freelancer_os.llm.client import ScriptedLLM
from freelancer_os.marketplaces.mock import MockMarketplace
from freelancer_os.pipeline import Pipeline
from freelancer_os.storage.db import Database


@pytest.mark.parametrize("task", TASKS, ids=lambda t: t.name)
async def test_golden_tasks(task):
    r = await run_task(task)
    assert r.ok, f"{r.name}: expected {r.expected} got {r.got} ({r.detail})"


async def _setup(tmp_path, task=TASKS[0], **settings_kw):
    s = eval_settings(tmp_path / "data", **settings_kw)
    repo = build_repo(task, tmp_path / "src")
    job = Job(marketplace="mock", external_id=task.name, title=task.title, description=task.description, repo_url=str(repo), skills=task.skills,
              budget_usd=Decimal("40"), acceptance_criteria=task.criteria, acceptance_tests=task.hidden_tests, funded=True, deadline_hours=48)
    mp = MockMarketplace([job])
    db = Database(":memory:")
    llm = ScriptedLLM([json.dumps(x) for x in task.script])
    return s, db, mp, Pipeline(s, db, {"mock": mp}, llm=llm, log=lambda m: None), job


async def test_dry_run_never_claims_or_delivers(tmp_path):
    s, db, mp, pipe, job = await _setup(tmp_path)
    assert s.dry_run
    await pipe.run_once()
    assert mp.claimed == {} and mp.deliveries == {}
    assert db.get_job(job.key)[1] == JobState.READY_TO_DELIVER
    assert (s.artifacts_dir / "mock_pagination_fix" / "patch.diff").read_text().strip()


async def test_full_cycle_claim_deliver_settle_and_learn(tmp_path):
    s, db, mp, pipe, job = await _setup(tmp_path, dry_run=False)
    await pipe.run_once()
    assert job.external_id in mp.claimed and job.external_id in mp.deliveries
    assert db.get_job(job.key)[1] in (JobState.DELIVERED, JobState.SETTLED)
    assert db.get_job(job.key)[1] == JobState.SETTLED
    pnl = pipe.treasury.pnl()
    assert Decimal(pnl["revenue_confirmed_usd"]) == Decimal("36.00")     # 40 minus 10% fee, confirmed by marketplace
    st = db.outcome_stats()
    assert st["wins"] == 1 and st["successes"] == 1
    assert db.ledger_sum(("sandbox_cost",)) >= 0


async def test_kill_switch_stops_work(tmp_path):
    s, db, mp, pipe, job = await _setup(tmp_path, dry_run=False)
    s.kill_switch_file.parent.mkdir(parents=True, exist_ok=True)
    s.kill_switch_file.write_text("x")
    await pipe.run_once()
    assert mp.claimed == {}


async def test_duplicate_jobs_not_rescored_or_reclaimed(tmp_path):
    s, db, mp, pipe, job = await _setup(tmp_path)
    assert len(await pipe.scan_marketplace("mock")) == 1
    assert len(await pipe.scan_marketplace("mock")) == 0


async def test_human_approval_gate(tmp_path):
    s, db, mp, pipe, job = await _setup(tmp_path, human_approval_threshold_usd=Decimal("10"))
    await pipe.scan_marketplace("mock")
    assert db.get_job(job.key)[1] == JobState.AWAITING_APPROVAL
    with pytest.raises(ValueError):
        await pipe.execute(job.key)                       # cannot execute without approval
    pipe.approve(job.key)
    assert (await pipe.execute(job.key)) == JobState.READY_TO_DELIVER


async def test_claim_failure_is_recorded_not_worked(tmp_path):
    s, db, mp, pipe, job = await _setup(tmp_path, dry_run=False)
    await pipe.scan_marketplace("mock")
    mp.claimed[job.external_id] = "someone-else"      # another agent wins the race after we scored it
    state = await pipe.execute(job.key)
    assert state == JobState.FAILED and "claim failed" in db.q("SELECT error FROM jobs")[0]["error"]
    assert pipe.llm.calls == []                            # no LLM money spent on a lost race


async def test_live_requires_llm_qa_review_before_delivery(tmp_path):
    s, db, mp, pipe, job = await _setup(tmp_path, dry_run=False, first_n_jobs_require_approval=0)
    s = s.model_copy(update={"mode": "live"})
    pipe.s = s
    await pipe.scan_marketplace("mock")
    state = await pipe.execute(job.key)
    assert state == JobState.READY_TO_DELIVER and mp.deliveries == {}


async def test_agent_budget_exhaustion_aborts(tmp_path):
    s, db, mp, pipe, job = await _setup(tmp_path, max_llm_cost_per_job_usd=Decimal("0.0000001"))
    await pipe.scan_marketplace("mock")
    state = await pipe.execute(job.key)
    assert state == JobState.FAILED and "budget" in db.q("SELECT error FROM jobs")[0]["error"]
