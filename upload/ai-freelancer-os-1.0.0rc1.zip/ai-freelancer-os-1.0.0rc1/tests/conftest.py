import pytest
from decimal import Decimal
from freelancer_os.config import Settings
from freelancer_os.domain import Job
from freelancer_os.storage.db import Database


@pytest.fixture
def settings(tmp_path):
    return Settings(mode="mock", dry_run=True, data_dir=tmp_path / "data", sandbox_backend="local", allow_local_repos=True,
                    llm_provider="none", qa_llm_provider="none", enabled_marketplaces="mock", kill_switch_file=tmp_path / "data" / "KILL")


@pytest.fixture
def db():
    d = Database(":memory:")
    yield d
    d.close()


def make_job(**kw) -> Job:
    base = dict(marketplace="mock", external_id="j1", title="Fix pagination bug in pager module", skills=["python", "pytest"],
                description="paginate() fails with an AssertionError in tests/test_pager.py; expected [0,1,2] but got [3,4,5]. Steps to reproduce: run pytest.",
                repo_url="https://github.com/o/r", budget_usd=Decimal("60"), acceptance_criteria=["AC1: fixed", "AC2: tests added"], funded=True, deadline_hours=48)
    base.update(kw)
    return Job(**base)
