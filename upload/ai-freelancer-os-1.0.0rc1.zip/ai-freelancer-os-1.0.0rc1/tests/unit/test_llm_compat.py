import json
import httpx
import pytest
from freelancer_os.llm.client import LLMError, OpenAICompatClient, build_client
from freelancer_os.marketplaces.basedagents import BasedAgentsAdapter
from decimal import Decimal


async def test_openai_compat_request_and_parsing():
    seen = {}

    def h(req: httpx.Request):
        seen["url"], seen["auth"], seen["body"] = str(req.url), req.headers["authorization"], json.loads(req.content)
        return httpx.Response(200, json={"choices": [{"message": {"content": '{"ok":1}', "reasoning_content": "secret chain of thought"}}],
                                         "usage": {"prompt_tokens": 11, "completion_tokens": 7}, "model": "glm-5.1"})
    c = OpenAICompatClient("k", "glm-5.1", "https://api.z.ai/api/paas/v4", {"thinking": {"type": "disabled"}}, transport=httpx.MockTransport(h))
    r = await c.complete("sys", [{"role": "user", "content": "hi"}], max_tokens=50)
    assert r.text == '{"ok":1}' and (r.input_tokens, r.output_tokens) == (11, 7)
    assert seen["url"] == "https://api.z.ai/api/paas/v4/chat/completions" and seen["auth"] == "Bearer k"
    assert seen["body"]["messages"][0] == {"role": "system", "content": "sys"} and seen["body"]["thinking"] == {"type": "disabled"}


async def test_openai_compat_errors_and_https_only():
    c = OpenAICompatClient("k", "m", "https://x.example/v1", transport=httpx.MockTransport(lambda r: httpx.Response(401, text="bad key")))
    with pytest.raises(LLMError, match="401"):
        await c.complete("s", [{"role": "user", "content": "x"}])
    with pytest.raises(LLMError):
        OpenAICompatClient("k", "m", "http://evil.example/v1")
    with pytest.raises(LLMError):
        OpenAICompatClient("", "m", "https://x.example/v1")


def test_build_client_zai(settings):
    s = settings.model_copy(update={"zai_api_key": "z", "llm_extra_body": '{"thinking":{"type":"enabled"}}'})
    c = build_client("zai", "glm-5.1", s)
    assert c.base_url == "https://api.z.ai/api/paas/v4" and c.extra == {"thinking": {"type": "enabled"}}


def test_wallet_bind_message_format_matches_registry_spec():
    from datetime import datetime, timezone
    m = BasedAgentsAdapter.wallet_bind_message("ag_X", "0xABCDEF0123456789abcdef0123456789ABCDEF01", "eip155:8453",
                                               issued=datetime(2026, 10, 8, 12, 0, 0, tzinfo=timezone.utc), nonce="deadbeefdeadbeef")
    assert m.splitlines()[:6] == ["BasedAgents payout wallet", "Agent: ag_X", "Wallet: 0xabcdef0123456789abcdef0123456789abcdef01",
                                  "Network: eip155:8453", "Issued: 2026-10-08T12:00:00Z", "Nonce: deadbeefdeadbeef"]
    assert m.endswith("It moves no funds.")


async def test_set_wallet_sends_signed_patch_with_proof():
    from basedagents.keypair import generate
    seen = {}

    def h(req: httpx.Request):
        seen["m"], seen["p"], seen["b"], seen["a"] = req.method, req.url.path, json.loads(req.content), req.headers["authorization"]
        return httpx.Response(200, json={"wallet_verified": True})
    kp = generate()
    a = BasedAgentsAdapter("https://api.basedagents.ai", "/x", Decimal("0.1"), transport=httpx.MockTransport(h), keypair=kp)
    addr = "0x829f877daAb94D766BB2b8511ad486C40f2C2BDA"
    await a.set_wallet(addr, "eip155:8453", "msg", "0xsig")
    assert seen["m"] == "PATCH" and seen["p"] == f"/v1/agents/{kp.agent_id}/wallet" and seen["a"].startswith("AgentSig ")
    assert seen["b"] == {"wallet_address": addr, "wallet_network": "eip155:8453", "wallet_proof": {"message": "msg", "signature": "0xsig"}}
    with pytest.raises(Exception):
        await a.set_wallet("not-an-address", "eip155:8453", "m", "s")
