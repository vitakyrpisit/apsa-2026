from decimal import Decimal
import pytest
from freelancer_os.domain import Decision
from freelancer_os.marketplaces.base import Capabilities
from freelancer_os.opportunity import bandit, trust
from freelancer_os.opportunity.engine import OpportunityEngine
from freelancer_os.opportunity.health import CircuitBreaker
from conftest import make_job

CAPS = Capabilities("exclusive_claim", Decimal("0.10"), "x")
RACE = Capabilities("open_race", Decimal("0.20"), "x")


@pytest.mark.parametrize("desc,flag", [
    ("Refer other agents to earn a referral bonus", "referral_task"),
    ("You must connect your wallet to verify and claim", "wallet_signature_trap"),
    ("Please sign this message to authenticate", "wallet_signature_trap"),
    ("Pay a registration fee to participate", "pay_to_enter"),
    ("Submission must prove which model wrote it", "attestation_bait"),
    ("Human-only work, no AI allowed", "attestation_bait"),
])
def test_hard_flags(desc, flag):
    assert flag in trust.assess(make_job(description=desc)).hard


def test_clean_job_has_no_flags():
    r = trust.assess(make_job())
    assert not r.hard and r.p_pay_mult == 1.0


def test_testnet_and_fake_token_rejected():
    assert trust.assess(make_job(network="eip155:84532")).rejected
    assert trust.assess(make_job(token="FREEMONEY")).rejected
    assert not trust.assess(make_job(network="eip155:8453", token="USDC")).rejected


def test_requester_without_history_lowers_payment_odds():
    base = trust.assess(make_job(requester_settled=None))
    risky = trust.assess(make_job(requester_settled=0, budget_usd=Decimal("100")))
    assert risky.p_pay_mult < base.p_pay_mult


def test_saturation_makes_old_tasks_worse(settings, db):
    e = OpportunityEngine(settings, db)
    fresh = e.score(make_job(age_hours=0.5), RACE)
    stale = e.score(make_job(age_hours=96), RACE)
    crowded = e.score(make_job(competition=100), RACE)
    assert stale.p_win < fresh.p_win and crowded.p_win < 0.02 + 0.01


def test_funded_vs_unknown_changes_payment_probability(settings, db):
    e = OpportunityEngine(settings, db)
    a = e.score(make_job(funded=True, requester_settled=5), CAPS)
    b = e.score(make_job(funded=True, requester_settled=None), CAPS)
    assert a.features["p_pay"] > b.features["p_pay"]


def test_p_pay_learns_from_non_payment(settings, db):
    e = OpportunityEngine(settings, db)
    before = e.score(make_job(), CAPS).features["p_pay"]
    for i in range(12):
        db.record_prediction(f"mock:p{i}", "mock", "python", 2, 0.8, 0.9)
        db.update_outcome(f"mock:p{i}", paid=0)
    assert e.score(make_job(), CAPS).features["p_pay"] < before - 0.2


def test_wilson_lower_bound_is_conservative():
    assert trust.wilson_lower(0, 0) == 0
    assert trust.wilson_lower(3, 3) < 0.7              # 3/3 is NOT proof of 100%
    assert trust.wilson_lower(90, 100) > trust.wilson_lower(9, 10)
    assert 0 <= trust.wilson_lower(5, 10) < 0.5


def test_circuit_breaker_opens_on_failures_and_forces_approval(settings, db):
    cb = CircuitBreaker(settings, db)
    assert not cb.status().open
    for i in range(10):
        db.record_prediction(f"other:f{i}", "other", "other-bucket", 2, 0.8, 0.9)   # failures elsewhere: breaker is global, p_success is per-lane
        db.update_outcome(f"other:f{i}", succeeded=0)
    st = cb.status()
    assert st.open and "lower bound" in st.reason
    s = OpportunityEngine(settings, db).score(make_job(), CAPS)
    assert s.decision == Decision.HUMAN_APPROVAL and any("circuit breaker" in r for r in s.reasons)


def test_circuit_breaker_opens_on_net_loss(settings, db):
    db.ledger_add("llm_cost", Decimal("20"), "x")
    assert CircuitBreaker(settings, db).status().open


def test_thompson_ranking_prefers_proven_lane_and_explores(settings, db):
    e = OpportunityEngine(settings, db)
    j_good, j_bad = make_job(external_id="g", budget_usd=Decimal("60")), make_job(external_id="b", budget_usd=Decimal("60"), marketplace="other")
    for i in range(30):                               # 'other' marketplace has a terrible record
        db.record_prediction(f"other:{i}", "other", "python", 2, 0.8, 0.9)
        db.update_outcome(f"other:{i}", succeeded=0, won=1)
    c = [(j_good, e.score(j_good, CAPS), Decimal("0.1")), (j_bad, e.score(j_bad, CAPS), Decimal("0.1"))]
    firsts = [bandit.rank(e, c, seed=i)[0][0].external_id for i in range(40)]
    assert firsts.count("g") > 30                     # exploits the proven lane...
    assert bandit.rank(e, c, seed=1) == bandit.rank(e, c, seed=1)   # ...deterministically under a seed


def test_thompson_explores_unknown_lanes(settings, db):
    e = OpportunityEngine(settings, db)
    a, b = make_job(external_id="a"), make_job(external_id="b", marketplace="new")
    c = [(a, e.score(a, CAPS), Decimal("0.1")), (b, e.score(b, CAPS), Decimal("0.1"))]
    firsts = {bandit.rank(e, c, seed=i)[0][0].external_id for i in range(60)}
    assert firsts == {"a", "b"}                       # with no data both are tried
