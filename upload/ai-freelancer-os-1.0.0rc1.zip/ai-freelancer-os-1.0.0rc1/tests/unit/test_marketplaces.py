import base64
import hashlib
import json
from decimal import Decimal
import httpx
import pytest
from freelancer_os.domain import Delivery, QAReport
from freelancer_os.marketplaces.base import MarketplaceError, PlannedAdapter, NotImplementedMarketplace
from freelancer_os.marketplaces.basedagents import BasedAgentsAdapter, atomic_to_usd, extract_criteria
from freelancer_os.marketplaces.taskbounty import TaskBountyAdapter
from conftest import make_job


@pytest.fixture
def kp():
    from basedagents.keypair import generate
    return generate()


def ba(kp, handler):
    return BasedAgentsAdapter("https://api.basedagents.ai", "/nonexistent", Decimal("0.10"), transport=httpx.MockTransport(handler), keypair=kp)


TASK = {"id": "task_1", "title": "Fix bug", "category": "code", "status": "open",
        "description": "Repo: https://github.com/acme/widgets\nAcceptance criteria:\n- parser handles empty input\n- tests added\n",
        "bounty": {"amount": "25000000", "token": "USDC", "network": "eip155:8453"}, "escrow": {"status": "funded"}, "required_capabilities": ["python"]}


async def test_basedagents_discover_maps_job(kp):
    a = ba(kp, lambda r: httpx.Response(200, json={"tasks": [TASK, {**TASK, "id": "t2", "escrow": None}]}))
    jobs = await a.discover()
    j = jobs[0]
    assert j.budget_usd == Decimal("25") and j.funded is True and j.repo_url == "https://github.com/acme/widgets"
    assert j.acceptance_criteria[:2] == ["parser handles empty input", "tests added"]
    assert jobs[1].funded is None                       # bounty without escrow info is NOT treated as funded
    assert "/v1/tasks" in str(a._http.base_url) or True


async def test_basedagents_signature_is_valid_ed25519(kp):
    seen = {}

    def handler(req: httpx.Request):
        seen["req"] = req
        return httpx.Response(200, json={"task_id": "task_1"})
    a = ba(kp, handler)
    res = await a.claim(make_job(external_id="task_1", marketplace="basedagents"))
    assert res.ok
    req = seen["req"]
    pub_b58, sig_b64 = req.headers["authorization"].removeprefix("AgentSig ").split(":")
    msg = f"POST:/v1/tasks/task_1/claim:{req.headers['x-timestamp']}:{hashlib.sha256(req.content).hexdigest()}:{req.headers['x-nonce']}".encode()
    kp.public_key.verify(base64.b64decode(sig_b64), msg)   # raises InvalidSignature if wrong
    assert pub_b58 == kp.public_key_b58


async def test_basedagents_claim_conflicts_are_explained(kp):
    a = ba(kp, lambda r: httpx.Response(409, json={"code": "wallet_required", "message": "no wallet"}))
    r = await a.claim(make_job(external_id="t", marketplace="basedagents"))
    assert not r.ok and "wallet" in r.reason and not r.retryable
    a = ba(kp, lambda r: httpx.Response(503, json={}))
    r = await a.claim(make_job(external_id="t", marketplace="basedagents"))
    assert not r.ok and r.retryable


async def test_basedagents_payment_requires_tx_reference(kp):
    a = ba(kp, lambda r: httpx.Response(200, json={"payment": {"payment_status": "settled"}}))
    assert not (await a.payment_status(make_job(external_id="t"))).settled
    a = ba(kp, lambda r: httpx.Response(200, json={"payment": {"payment_status": "settled", "payment_tx_hash": "0xabc"}}))
    ps = await a.payment_status(make_job(external_id="t"))
    assert ps.settled and ps.tx_ref == "0xabc"


async def test_basedagents_deliver_body(kp):
    seen = {}
    a = ba(kp, lambda r: (seen.update(body=json.loads(r.content)), httpx.Response(200, json={"receipt_id": "r1"}))[1])
    d = Delivery(summary="done", patch="diff", commit_sha="abc", pr_url="https://github.com/a/b/pull/1", qa=QAReport(passed=True))
    assert await a.deliver(make_job(external_id="t"), d) == "r1"
    assert seen["body"]["submission_type"] == "pr" and seen["body"]["pr_url"].endswith("/pull/1") and seen["body"]["commit_hash"] == "abc"


def test_helpers():
    assert atomic_to_usd("1500000") == Decimal("1.5")
    assert extract_criteria("x", "ship it") == ["ship it"]


# ---------------------------------------------------------------------------- TaskBounty (MCP)
def mcp_handler(tools_result):

    def h(req: httpx.Request):
        m = json.loads(req.content)
        meth = m["method"]
        if meth == "initialize":
            return httpx.Response(200, json={"jsonrpc": "2.0", "id": m["id"], "result": {"protocolVersion": "2025-03-26"}}, headers={"mcp-session-id": "S1"})
        if meth == "notifications/initialized":
            assert req.headers["mcp-session-id"] == "S1"
            return httpx.Response(202)
        if meth == "tools/call":
            assert req.headers["mcp-session-id"] == "S1"
            name = m["params"]["name"]
            return httpx.Response(200, json={"jsonrpc": "2.0", "id": m["id"], "result": {"content": [{"type": "text", "text": json.dumps(tools_result[name])}]}})
        if meth == "tools/list":
            return httpx.Response(200, json={"jsonrpc": "2.0", "id": m["id"], "result": {"tools": [{"name": n} for n in ["list_open_bounties", "get_bounty_detail", "submit_pr"]]}})
        return httpx.Response(400)
    return h


async def test_taskbounty_discover_and_deliver():
    res = {"list_open_bounties": {"bounties": [{"id": "b1", "title": "Fix X", "reward": "$75", "repo": "acme/lib", "language": "Python"}]},
           "submit_pr": {"submission_id": "s9"}, "check_submission_status": {"status": "paid", "tx_hash": "0x1"}}
    a = TaskBountyAdapter("https://mcp.example.com/mcp", "tb_live_x", "agent7", Decimal("0.2"), transport=httpx.MockTransport(mcp_handler(res)))
    jobs = await a.discover()
    assert jobs[0].budget_usd == Decimal("75") and jobs[0].repo_url == "https://github.com/acme/lib" and jobs[0].skills == ["python"]
    with pytest.raises(MarketplaceError):
        await a.deliver(jobs[0], Delivery(summary="s", patch="", qa=QAReport(passed=True)))   # needs a PR URL
    assert await a.deliver(jobs[0], Delivery(summary="s", patch="", pr_url="https://github.com/acme/lib/pull/3", qa=QAReport(passed=True))) == "s9"
    assert (await a.payment_status(jobs[0])).settled


async def test_taskbounty_doctor_fails_closed_on_missing_tools():
    a = TaskBountyAdapter("https://mcp.example.com/mcp", "k", "a", Decimal("0.2"), transport=httpx.MockTransport(mcp_handler({})))
    name, ok, detail = (await a.doctor())[0]
    assert not ok and "check_submission_status" in detail


def test_taskbounty_requires_https_url():
    with pytest.raises(MarketplaceError):
        TaskBountyAdapter("http://evil.example.com/mcp", "k", "a", Decimal("0.2"))
    with pytest.raises(MarketplaceError):
        TaskBountyAdapter("", "k", "a", Decimal("0.2"))


async def test_planned_adapters_refuse():
    p = PlannedAdapter("upwork", "needs human", human=True)
    with pytest.raises(NotImplementedMarketplace):
        await p.discover()
