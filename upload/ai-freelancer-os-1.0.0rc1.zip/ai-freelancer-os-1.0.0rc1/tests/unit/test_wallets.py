import pytest
from freelancer_os.treasury.wallets import (Wallets, keccak256, validate_btc, validate_evm, validate_solana, validate_tron)

ETH = "0x829f877daAb94D766BB2b8511ad486C40f2C2BDA"
SOL = "EyTxSdVtku7QtbwgntLvUwyxMvraJyAxoPoZ8ALdG6qL"
TRX = "TVVhpdHEg1ZgvPjJNSe2P28bhUDE4m85ZX"
BTC = "bc1qaedy7cmqujxlmkezlxlytkrecv0ufku970tk9c"


def test_keccak_known_vectors():
    assert keccak256(b"").hex() == "c5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470"
    assert keccak256(b"abc").hex() == "4e03657aea45a94fc7d47ba826c8d667c0d1e6e33a64a036ec44f58fa12d6c45"


def test_operator_addresses_are_valid():
    assert validate_evm(ETH) == (True, "valid EIP-55 checksum")
    assert validate_solana(SOL)[0] and validate_tron(TRX)[0] and validate_btc(BTC)[0]


def test_typos_are_detected():
    assert not validate_evm(ETH[:-1] + "B")[0]                       # EIP-55 catches a single-character typo
    assert not validate_evm(ETH.replace("daAb", "daab"))[0]
    assert not validate_tron(TRX[:-1] + "Z")[0]
    assert not validate_btc(BTC[:-1] + "d")[0]
    assert not validate_solana(SOL[:-3])[0] and not validate_evm("0x1234")[0]


def test_known_good_external_vectors():
    assert validate_btc("bc1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4")[0]          # BIP-173 example
    assert validate_btc("1BvBMSEYstWetqTFn5Au4m4GFg7xJaNVN2")[0]                  # legacy
    assert validate_tron("TLa2f6VPqDgRE67v1736s7bJ8Ray5wYjU7")[0]


def test_wallet_must_be_confirmed_per_network():
    w = Wallets(evm=ETH, solana=SOL, confirmed={"solana"})
    with pytest.raises(ValueError, match="not confirmed"):
        w.address_for("base")                                          # valid address, but operator has not confirmed Base deposits
    assert w.address_for("solana") == SOL
    assert Wallets(evm=ETH, confirmed={"base", "arbitrum"}).address_for("arbitrum") == ETH
    with pytest.raises(ValueError):
        Wallets(evm="0xBAD", confirmed={"base"}).address_for("base")
    with pytest.raises(ValueError):
        w.address_for("dogecoin")
