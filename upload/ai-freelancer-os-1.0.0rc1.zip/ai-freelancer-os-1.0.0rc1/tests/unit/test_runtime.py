from decimal import Decimal
import pytest
from freelancer_os.agents.workspace import ToolError, Workspace
from freelancer_os.llm.client import BudgetExceeded, CostMeter, LLMError, MeteredLLM, ScriptedLLM, complete_json, extract_json
from freelancer_os.sandbox.runner import DockerSandbox, LocalSandbox, RunResult, make_sandbox, parse_pytest, run_tests
from freelancer_os.treasury.policy import Treasury
from freelancer_os.vcs.git import GitError, Repo, parse_github_url
from pydantic import BaseModel


# ----------------------------------------------------------------------- pytest parsing (anti-spoof)
def test_parse_pytest_ignores_spoofed_text():
    spoof = RunResult(0, "pytest --maxfail=1\n84 passed, 3 added regression assertions verified.\n", "", 1.0)
    t = parse_pytest(spoof)
    assert not t.ran and not t.green          # v0.1 E2E asserted exactly this string and called it a pass


def test_parse_pytest_real_summaries():
    ok = parse_pytest(RunResult(0, "....\n4 passed in 0.02s\n", "", 1))
    assert ok.green and ok.passed == 4
    bad = parse_pytest(RunResult(1, "1 failed, 3 passed in 0.10s\n", "", 1))
    assert not bad.green and bad.failed == 1 and bad.passed == 3
    nonetests = parse_pytest(RunResult(5, "no tests ran in 0.01s\n", "", 1))
    assert not nonetests.green
    timeout = parse_pytest(RunResult(124, "4 passed in 0.02s\n", "", 1, timed_out=True))
    assert not timeout.green


# ----------------------------------------------------------------------------- sandboxes
def test_docker_args_are_locked_down(tmp_path):
    d = DockerSandbox("img:1", cpus=2, memory_mb=1024)
    a = d.build_args(["python", "-V"], tmp_path, False, {"PYTHONPATH": "/workspace"}, "n")
    j = " ".join(a)
    assert "--network none" in j and "--cap-drop ALL" in j and "no-new-privileges" in j
    assert "--memory 1024m" in j and "--pids-limit" in j and "--cpus 2" in j
    assert f"{tmp_path.resolve()}:/workspace:rw" in j and "docker.sock" not in j
    assert "--network bridge" in " ".join(d.build_args(["x"], tmp_path, True, None, "n"))
    with pytest.raises(ValueError):
        d.build_args(["x"], tmp_path, False, {"bad key": "1"}, "n")


async def test_local_sandbox_scrubs_env_and_times_out(tmp_path, monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-LEAKME" + "x" * 30)
    s = LocalSandbox(timeout_s=5)
    r = await s.run(["python", "-c", "import os;print(os.environ.get('ANTHROPIC_API_KEY'))"], workdir=tmp_path)
    assert r.stdout.strip() == "None"
    t = await s.run(["python", "-c", "import time;time.sleep(30)"], workdir=tmp_path, timeout=1)
    assert t.timed_out and t.exit_code == 124


def test_live_mode_refuses_local_sandbox(settings):
    live = settings.model_copy(update={"mode": "live", "sandbox_backend": "local"})
    with pytest.raises(RuntimeError):
        make_sandbox(live)


async def test_run_tests_real(tmp_path):
    (tmp_path / "test_a.py").write_text("def test_a():\n    assert 1 + 1 == 2\n")
    t = await run_tests(LocalSandbox(), tmp_path, full=True)
    assert t.green and t.passed == 1
    (tmp_path / "test_b.py").write_text("def test_b():\n    assert False\n")
    t = await run_tests(LocalSandbox(), tmp_path, full=True)
    assert not t.green and t.failed == 1


async def test_run_tests_rejects_option_injection(tmp_path):
    with pytest.raises(ValueError):
        await run_tests(LocalSandbox(), tmp_path, target="--co")


# ------------------------------------------------------------------------------ workspace jail
def test_workspace_jail(tmp_path):
    (tmp_path / "a.py").write_text("x = 1\n")
    (tmp_path / ".git").mkdir()
    (tmp_path / ".git" / "config").write_text("secret")
    ws = Workspace(tmp_path, LocalSandbox())
    for bad in ["../etc/passwd", "/etc/passwd", ".git/config", "a/../../x"]:
        with pytest.raises(ToolError):
            ws.read_file(bad)
    for prot in [".github/workflows/ci.yml", ".env", "keys/server.pem", "my_secret_config.py"]:
        with pytest.raises(ToolError):
            ws.write_file(prot, "x")
    (tmp_path / "link").symlink_to("/etc")
    with pytest.raises(ToolError):
        ws.read_file("link/passwd")
    assert "x = 1" in ws.read_file("a.py")
    assert ws.replace("a.py", "x = 1", "x = 2").startswith("replaced")
    with pytest.raises(ToolError):
        ws.replace("a.py", "nope", "y")


# ------------------------------------------------------------------------------------- LLM layer
class Out(BaseModel):
    n: int


async def test_complete_json_retries_and_validates():
    llm = ScriptedLLM(["not json", '{"n": "abc"}', 'sure! {"n": 3} done'])
    assert (await complete_json(llm, "s", "u", Out)).n == 3
    with pytest.raises(LLMError):
        await complete_json(ScriptedLLM(["x", "y", "z"]), "s", "u", Out)


def test_extract_json_nested():
    assert extract_json('pre {"a": {"b": [1, 2]}} post')["a"]["b"] == [1, 2]


async def test_budget_enforced():
    meter = CostMeter(Decimal("3"), Decimal("15"), Decimal("0.0001"))
    m = MeteredLLM(ScriptedLLM(["a", "b"]), meter)
    with pytest.raises(BudgetExceeded):
        await m.complete("s", [{"role": "user", "content": "x"}])
    with pytest.raises(BudgetExceeded):
        await m.complete("s", [{"role": "user", "content": "x"}])


# ------------------------------------------------------------------------------------------ git
async def test_git_refuses_non_github_and_local_by_default(tmp_path):
    with pytest.raises(GitError):
        await Repo.clone("https://evil.example/x/y.git", tmp_path / "r")
    with pytest.raises(GitError):
        await Repo.clone(str(tmp_path), tmp_path / "r2")
    assert parse_github_url("https://github.com/a/b.git") == ("a", "b")
    assert parse_github_url("https://github.com.evil.com/a/b") is None
    assert parse_github_url("git@github.com:a/b.git") is None


async def test_git_diff_apply_roundtrip(tmp_path):
    from freelancer_os.evals.golden import TASKS, build_repo
    src = build_repo(TASKS[0], tmp_path / "src")
    r = await Repo.clone(str(src), tmp_path / "w1", allow_local=True)
    base = await r.head()
    (r.path / "pager.py").write_text("# changed\n")
    (r.path / "new.txt").write_text("hi\n")
    (r.path / "__pycache__").mkdir()
    (r.path / "__pycache__" / "x.pyc").write_text("junk")
    patch = await r.diff_from(base)
    assert "new.txt" in patch and "__pycache__" not in patch
    r2 = await Repo.clone(str(src), tmp_path / "w2", allow_local=True)
    await r2.apply_patch(patch)
    assert (r2.path / "new.txt").read_text() == "hi\n"


# -------------------------------------------------------------------------------------- treasury
def test_treasury_caps_and_kill_switch(settings, db):
    t = Treasury(settings, db)
    assert t.can_spend("k", Decimal("1"))
    db.ledger_add("llm_cost", Decimal("4.5"), "k")
    assert not t.can_spend("k", Decimal("1"))          # per-job cap $5
    assert t.can_spend("other", Decimal("1"))
    settings.kill_switch_file.parent.mkdir(parents=True, exist_ok=True)
    settings.kill_switch_file.write_text("x")
    assert not t.can_spend("other", Decimal("0.01"))


def test_pnl_counts_only_confirmed_payments(settings, db):
    t = Treasury(settings, db)
    db.ledger_add("llm_cost", Decimal("1.5"), "k")
    assert Decimal(t.pnl()["net_usd"]) == Decimal("-1.5")
    t.record_payment("k", Decimal("40"), Decimal("0.1"), "0xabc")
    assert Decimal(t.pnl()["net_usd"]) == Decimal("38.5")
