import pytest
from fastapi.testclient import TestClient
from freelancer_os.api.app import create_app
from freelancer_os.marketplaces.mock import MockMarketplace
from freelancer_os.pipeline import Pipeline
from freelancer_os.storage.db import Database
from conftest import make_job

TOKEN = "t" * 32


@pytest.fixture
def client(settings):
    s = settings.model_copy(update={"api_token": TOKEN})
    pipe = Pipeline(s, Database(":memory:"), {"mock": MockMarketplace()}, log=lambda m: None)
    return TestClient(create_app(s, pipe))


def test_auth_required(client):
    assert client.get("/health").status_code == 200
    for path in ["/v1/status", "/v1/jobs", "/v1/pnl"]:
        assert client.get(path).status_code == 401
        assert client.get(path, headers={"Authorization": "Bearer wrong"}).status_code == 401
    assert client.get("/v1/status", headers={"Authorization": f"Bearer {TOKEN}"}).status_code == 200


def test_status_reports_real_zeros_not_fake_balances(client):
    d = client.get("/v1/status", headers={"Authorization": f"Bearer {TOKEN}"}).json()
    assert d["pnl"]["revenue_confirmed_usd"] == "0" and d["pnl"]["net_usd"] == "0"
    assert "treasury_balance_usd" not in d and "autonomy_level" not in d


def test_score_endpoint_uses_engine(client):
    h = {"Authorization": f"Bearer {TOKEN}"}
    a = client.post("/v1/score", headers=h, json=make_job().model_dump(mode="json")).json()
    b = client.post("/v1/score", headers=h, json=make_job(skills=["rust"]).model_dump(mode="json")).json()
    assert a["decision"] != "REJECT" and b["decision"] == "REJECT"


def test_weak_token_refused(settings):
    with pytest.raises(RuntimeError):
        create_app(settings.model_copy(update={"api_token": "short"}), None)  # type: ignore[arg-type]
