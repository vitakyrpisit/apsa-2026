from freelancer_os.agents.qa_agent import deterministic_checks, split_patch


def names(checks, failed_only=True):
    return {c.name for c in checks if (not c.passed if failed_only else True)}


SRC = "diff --git a/pager.py b/pager.py\n--- a/pager.py\n+++ b/pager.py\n@@ -1 +1 @@\n-old\n+new\n"


def test_clean_patch_passes():
    assert not (names(deterministic_checks(SRC, 10_000)) - {"suspicious_added_code"})


def test_empty_patch_fails():
    assert "patch_not_empty" in names(deterministic_checks("", 1000))


def test_oversized_patch_fails():
    assert "patch_size" in names(deterministic_checks(SRC, 10))


def test_secret_in_diff_fails():
    p = SRC + "+KEY = 'sk-ant-api03-" + "A" * 30 + "'\n"
    assert "no_secrets_in_diff" in names(deterministic_checks(p, 10_000))


def test_protected_file_touch_fails():
    p = "diff --git a/.github/workflows/ci.yml b/.github/workflows/ci.yml\n--- a/.github/workflows/ci.yml\n+++ b/.github/workflows/ci.yml\n@@ -1 +1 @@\n-a\n+b\n"
    assert "no_protected_files" in names(deterministic_checks(p, 10_000))


def test_deleted_test_fails():
    p = "diff --git a/tests/test_a.py b/tests/test_a.py\ndeleted file mode 100644\n--- a/tests/test_a.py\n+++ /dev/null\n@@ -1 +0,0 @@\n-def test_a(): assert 1\n"
    assert "no_deleted_tests" in names(deterministic_checks(p, 10_000))


def test_weakened_tests_fail():
    p = ("diff --git a/tests/test_a.py b/tests/test_a.py\n--- a/tests/test_a.py\n+++ b/tests/test_a.py\n@@ -1,2 +1,2 @@\n"
         "-    assert f(1) == 2\n-    assert f(2) == 3\n+    assert True\n")
    assert "tests_not_weakened" in names(deterministic_checks(p, 10_000))
    p2 = "diff --git a/tests/test_a.py b/tests/test_a.py\n--- a/tests/test_a.py\n+++ b/tests/test_a.py\n@@ -1 +1,2 @@\n+@pytest.mark.skip\n+def test_x(): pass\n"
    assert "tests_not_weakened" in names(deterministic_checks(p2, 10_000))


def test_adding_tests_is_fine():
    p = "diff --git a/tests/test_new.py b/tests/test_new.py\nnew file mode 100644\n--- /dev/null\n+++ b/tests/test_new.py\n@@ -0,0 +1,2 @@\n+def test_n():\n+    assert 1 == 1\n"
    n = names(deterministic_checks(p + SRC, 10_000))
    assert "tests_not_weakened" not in n and "no_deleted_tests" not in n


def test_test_only_change_warns_no_source_change():
    p = "diff --git a/tests/test_new.py b/tests/test_new.py\nnew file mode 100644\n--- /dev/null\n+++ b/tests/test_new.py\n@@ -0,0 +1 @@\n+def test_n(): assert 2 > 1\n"
    c = {x.name: x for x in deterministic_checks(p, 10_000)}
    assert not c["source_code_changed"].passed and c["source_code_changed"].severity == "warn"


def test_split_patch_counts():
    f = split_patch(SRC)
    assert f["pager.py"]["added"] == ["new"] and f["pager.py"]["removed"] == ["old"]
